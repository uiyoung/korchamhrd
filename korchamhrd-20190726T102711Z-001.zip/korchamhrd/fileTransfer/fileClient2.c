#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <termios.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <stdio_ext.h>

#define BUF_SIZE 30
#define NAMESIZE 20

#define GREEN1 printf("%c[32m", 27);
#define DEF1 printf("%c[0m", 27);
#define YELLOW1 printf("%c[33m", 27);
#define RED1 printf("%c[1;31m", 27);

typedef struct _Player
{
    char name[NAMESIZE];
    int timeRecord;
    int score;
    int distance;
} Player;

typedef struct _RankData
{
    char name[NAMESIZE];
    int score;
    int timeRecord;
    int distance;
    char date[20];
} RankData;

void error_handling(char *message);
void RecieveRanking();
void SaveRanking(Player p);
void PrintRanking(int sortby);
void QuickSort(RankData* rd, int left, int right, int sortby);
void Swap(RankData* rd, int a, int b);
int getch();

int main(int argc, char *argv[])
{
    int choice = 0;

    while(1)
    {
        system("clear");
        puts("[1]랭킹 [2]종료");
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
                RecieveRanking();
                PrintRanking(1);
                break;
            case 2:
                return 0;
                break;
            default:
                break;
        }
    }

    return 0;
}

void PrintRanking(int sortby)
{
    int idx = 0;
    int arrLength = 20;  // 초기 RankData배열 크기
    RankData* rd = (RankData*)malloc(sizeof(RankData)*arrLength);
    FILE* fp = fopen("ranking.txt", "r");

    if(fp == NULL)
    {
        puts("file open error");
        exit(1);
    }

    while(!feof(fp))
    {
        if(idx >= arrLength)
        {
            // 재할당
            arrLength+=5;
            rd = (RankData*)realloc(rd, sizeof(RankData)*arrLength);
        }

        // RankData 구조체에 저장
        fscanf(fp, "%s %d %d %d %s\n", rd[idx].name, &rd[idx].timeRecord, &rd[idx].score, &rd[idx].distance, rd[idx].date);
        idx++;
    }

    // quick sort
    QuickSort(rd, 0, idx-1, sortby);

    int maxLine = idx >= 20 ? 20 : idx;  // 출력할 라인 수

    __fpurge(stdin);    // buffer clear
    system("clear");

    RED1
        printf("    |**********************██████╗  █████╗ ███╗   ██╗██╗  ██╗*******************| \n");
        printf("    [                      ██╔══██╗██╔══██╗████╗  ██║██║ ██╔╝                  .]\n");
        printf("    [ *      *    .      * ██████╔╝███████║██╔██╗ ██║█████╔╝ *     *      .     ]\n");
        printf("    [    .            .    ██╔══██╗██╔══██║██║╚██╗██║██╔═██╗    .       .       ]\n");
        printf("    [                      ██║  ██║██║  ██║██║ ╚████║██║  ██╗                 * ]\n");
        printf("    '**********************╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝*******************'\n");
        puts("RANK\tname\t\ttime\t\tscore\t\tdistance\tdate");
    DEF1

    for(int i=0;i<maxLine;i++)
    {
        printf("%2d\t%s\t\t%d\t\t%d\t\t%d\t\t%s\n", i+1, rd[i].name, rd[i].timeRecord, rd[i].score, rd[i].distance, rd[i].date);
    }

    putchar('\n');
    puts("         [1]시간 순 정렬         [2]점수 순 정렬       [3]거리 순 정렬     ");
    YELLOW1
        printf("\n");
        printf("\n");
        puts("                              < 이전 메뉴로[enter]              ");
    DEF1

    int key = getch();
    if(key == '1')
        PrintRanking(1);
    else if(key == '2')
        PrintRanking(2);
    else if(key == '3')
        PrintRanking(3);
    else if(key == '\n')
        return;

    free(rd);
    fclose(fp);
}

void QuickSort(RankData* rd, int left, int right, int sortby)
{
    int pivot = left;
    int j = pivot;

    // 데이터가 2개 이상일때 정렬 실행
    if(left<right)
    {
        for(int i=left+1;i<=right;i++)
        {
            switch(sortby)
            {
                case 1: // 시간 순 정렬
                    if(rd[i].timeRecord > rd[pivot].timeRecord)
                    {
                        j++;
                        Swap(rd, i, j);
                    }
                    break;
                case 2: // 점수 순 정렬
                    if(rd[i].score> rd[pivot].score)
                    {
                        j++;
                        Swap(rd, i, j);
                    }
                    break;
                case 3: // 거리 순 정렬
                    if(rd[i].distance> rd[pivot].distance)
                    {
                        j++;
                        Swap(rd, i, j);
                    }
                    break;
            }
        }
        Swap(rd, left, j);

        pivot = j;
        QuickSort(rd, left, pivot-1, sortby);
        QuickSort(rd, pivot+1, right, sortby);
    }
}

void Swap(RankData* rd, int a, int b)
{
    RankData temp = rd[a];
    rd[a] = rd[b];
    rd[b] = temp;
}

int getch(void)
{
    int ch;
    struct termios buf;
    struct termios save;

    tcgetattr(0,&save);
    buf=save;
    buf.c_lflag&=~(ICANON|ECHO);
    buf.c_cc[VMIN]=1;
    buf.c_cc[VTIME]=0;
    tcsetattr(0,TCSAFLUSH,&buf);
    ch=getchar();
    tcsetattr(0,TCSAFLUSH,&save);

    return ch;
}


void RecieveRanking()
{
    int sd;
    FILE* fp;

    char buf[BUF_SIZE];
    int read_cnt;
    struct sockaddr_in serv_adr;

    char serv_port[4];

    printf("port>>");
    scanf("%s", serv_port);

    // 수신한 데이터를 저장할 파일 오픈
    fp = fopen("ranking.txt", "w"); 

    // 서버 접속을 위한 소켓 생성
    sd = socket(PF_INET, SOCK_STREAM, 0);
    if (sd == -1)
        error_handling("socket() error");

    memset(&serv_adr, 0, sizeof(serv_adr));
    serv_adr.sin_family = AF_INET;
    //serv_adr.sin_addr.s_addr = inet_addr(argv[1]);
    //serv_adr.sin_port = htons(atoi(argv[2]));
    serv_adr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serv_adr.sin_port = htons(atoi(serv_port));

    if (connect(sd, (struct sockaddr*)&serv_adr, sizeof(serv_adr)) == -1)
        error_handling("connect() error");

    // EOF가 전송될 때 까지 데이터를 수신받아 파일에 저장
    while ((read_cnt = read(sd, buf, BUF_SIZE)) != 0) 
        fwrite((void*)buf, 1, read_cnt, fp);

    puts("Received file data");

    // 서버에 감사 메세지 전달
    write(sd, "Thank You", 10);

    fclose(fp);
    close(sd);
}

void error_handling(char* message)
{
    fputs(message, stderr);
    fputc('\n', stderr);
    exit(1);
}
