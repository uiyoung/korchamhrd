#include<iostream>
#include<string>

using namespace std;

string ReplaceAll(string &str, const string from, string to)
{
    size_t startPos = 0;	// string ó������ �˻�

    while((startPos = str.find(from, startPos)) != string::npos)	// from�� ã�� �� ���� ������ 
    {
        str.replace(startPos, from.length(),to);
        startPos += to.length();	// �˻���ġ ���� 
        //break;
    }

    return str;
}

int main() 
{
    string str; 
    string from;
    string to;

    cout << "str:";
    getline(cin, str); 
    cout << "from:";
    getline(cin, from);
    cout << "to:";
    getline(cin, to);

    cout << ReplaceAll(str, from, to) <<endl;

    return 0;
}
