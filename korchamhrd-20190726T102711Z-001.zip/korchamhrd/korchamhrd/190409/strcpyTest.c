#include <stdio.h>
#include <string.h>

int main()
{
    char str[80]="abcdefghijklmnop";
    strcpy(str, "apple");

    for(int i=0;i<sizeof(str)/sizeof(char);i++)
        printf("%c", str[i]);

    putchar('\n');

    printf("%c", str[5]);

    return 0;
}

