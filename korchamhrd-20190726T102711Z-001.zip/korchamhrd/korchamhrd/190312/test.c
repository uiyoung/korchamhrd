#include <stdio.h>

int main()
{
    int a;
    printf(">>");
    int b = scanf("%d", &a);
    int c = scanf("%d", &a);

    printf("b:%d c:%d", b, c);

    return 0;

}
