#include <stdio.h>

int main()
{
    float total = 0.0f;
    float input = 0.0f;
    int count = 0;

    for( ; input >= 0.0; )
    {
        total += input;
        printf("양의 실수입력 >>");
        scanf("%f", &input);
        count++;
    }

    printf("지금까지의 평균 : %f\n", total/count);

    return 0;
}
