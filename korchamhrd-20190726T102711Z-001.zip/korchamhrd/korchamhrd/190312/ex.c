#include <stdio.h>

int main()
{
    int i;
    while(i<15)
    {
        printf("%d\n", ++i);
    }

    return 0;
}
