#include <stdio.h>

int main()
{
    int i;
    int j;

    for( ; ; )
    {
        printf("단 입력(숫자 이외 입력시 종료)>>");
        
        if(!scanf("%d", &j))
            break;

        for(i = 1; i <= 9 ; i++)
           printf("%d*%d=%d\n", j, i, j*i);
    }

    return 0;
}
