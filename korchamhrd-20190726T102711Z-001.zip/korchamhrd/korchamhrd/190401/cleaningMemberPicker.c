#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>

typedef struct _student
{
    int number;
    char name[20];
    int gender; //여자:0, 남자:1
    int isPicked;   // 선택안됨 : 0, 선택됨:1
} Student;

void PickOnlyGirls(Student s[], const int girlsNum[], int size, int num);
void PickOnlyBoys(Student s[], int size, int num);
void PickAny(Student s[], int size, int num);

int main()
{
    srand(time(NULL));
    const char *names[25] = {"강진광", "고선주", "김경훈", "김규완", "김길환", "김다정", "김주현", "김태완", "김현서", "문선철", "박소희", "박예은", "박종화", "서의영", "심민선", "양승호", "오금성", "오유진", "오지구", "윤미정", "윤호영", "이효동", "장진혁", "정의인", "조민권"};
    const int girlsNum[] = {6, 7, 9, 11, 12, 18, 20}; //여학생 번호

    // initialize Students
    Student students[25];
    for(int i=0;i<sizeof(students)/sizeof(Student);i++)
    {
        students[i].number = i+1;
        strcpy(students[i].name, names[i]);
        students[i].gender = 1;
        students[i].isPicked = 0;
    }
    for(int i=0;i<sizeof(girlsNum)/sizeof(int);i++)
    {
        students[girlsNum[i]-1].gender = 0;    //여학생 성별 0으로 초기화
    }
    students[21].isPicked = 1;  // 22번 학생 제외

    puts("여자 화장실");
    puts("───────────────");
    PickOnlyGirls(students, girlsNum, sizeof(girlsNum)/sizeof(int), 2);
    putchar('\n');
    puts("남자 화장실");
    puts("───────────────");
    PickOnlyBoys(students, sizeof(students)/sizeof(Student), 2);
    putchar('\n');
    puts("남자 화장실 쓰레기");
    puts("───────────────");
    PickOnlyBoys(students, sizeof(students)/sizeof(Student), 1);
    putchar('\n');
    puts("교수실");
    puts("───────────────");
    PickAny(students, sizeof(students)/sizeof(Student), 5);
    putchar('\n');
    puts("교실");
    puts("───────────────");
    PickAny(students, sizeof(students)/sizeof(Student), 5);
    putchar('\n');
    puts("복도");
    puts("───────────────");
    PickAny(students, sizeof(students)/sizeof(Student), 3);
    putchar('\n');
    puts("계단");
    puts("───────────────");
    PickAny(students, sizeof(students)/sizeof(Student), 2);
    putchar('\n');
    puts("쓰레기");
    puts("───────────────");
    PickAny(students, sizeof(students)/sizeof(Student), 4);

    return 0;
}

void PickOnlyGirls(Student s[], const int girlsNum[], int size, int num)
{
    for(int i=0;i<num;i++)
    {
        int pick = rand()%size;

        if(s[girlsNum[pick]-1].isPicked == 1)
        {
            i--;
            continue;
        }

        s[girlsNum[pick]-1].isPicked = 1;
        printf("%2d번 %s\n", s[girlsNum[pick]-1].number, s[girlsNum[pick]-1].name);
  //      sleep(1);
    }
}

void PickOnlyBoys(Student s[], int size, int num)
{
    for(int i=0;i<num;i++)
    {
        int pick=rand()%size;

        if(s[pick].gender==0||s[pick].isPicked==1)
        {
            i--;
            continue;
        }

        s[pick].isPicked = 1;
        printf("%2d번 %s\n", s[pick].number, s[pick].name);
        sleep(1);
    }
}

void PickAny(Student s[], int size, int num)
{
    for(int i=0;i<num;i++)
    {
        int pick = rand()%size;

        if(s[pick].isPicked==1)
        {
            i--;
            continue;
        }

        s[pick].isPicked = 1;
        printf("%2d번 %s\n", s[pick].number, s[pick].name);
        sleep(1);
    }
}
