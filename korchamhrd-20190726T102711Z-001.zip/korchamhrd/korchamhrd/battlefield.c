#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <termios.h>    // 키 값을 입력받기 위해 사용되는 헤더파일
#include <string.h>

#define Red printf("%c[1;31m", 27);
#define Def printf("%c[0m", 27);
#define Blue printf("%c[1;34m", 27);
#define GREEN printf("%c[1;32m", 27);
#define YELLOW printf("%c[1;33m", 27);
#define PURPLE printf("%c[1;35m", 27);
#define GRAY printf("\x1b[30m"); // 회색 출력
#define RESET printf("\x1b[0m"); // 흰색 출력

void line(void);
int getch(void);
void Move(int random[][20][20], char location[][20][20], int *key, int *posY, int *posX, int *stage);	// 이동 값 반영 함수
int UI(char arr[][20][20], int stage);
void Enter(void);
void Print_status(char Field[100], int *behavior, int *money);	// 스테이터스 출력 함수
void Initialize(char location[][20][20], int random[][20][20], int *posY, int *posX);


int main(void)
{
    char location[2][20][20];			// 미니맵에 존재하는 *,ㅁ,O변수
    int posY, posX;					// 좌표를 나타낼 변수
    int random[5][20][20]={0};			// 이벤트좌표 배열
    int key;				        // 키보드 위치 인식 변수
    int stage=0;					// 1층 시작
    int item[7]={5,0,0,0,0,0,1};			//아이템 변수
    int behavior=1000;                                // 행동력 변수
    int money=1000;                                 // 돈 변수
    int end=0;					// 이벤트 종료 변수
    char Field[100]={"Battle Field"};
    char enter;					//버퍼용 변수
    srand(time(NULL));

    Initialize(location, random, &posY, &posX);

    while(1)
    {
        system("clear");
        UI(location, stage);
        Print_status(Field,&behavior,&money);
        key=getch();    // 키보드 방향키 감지

        if(key=='A'||key=='B'||key=='C'||key=='D')
        {
            Move(random, location, &key, &posY, &posX, &stage);
        }
    }

    return 0;
}

void Initialize(char location[][20][20], int random[][20][20], int *posY, int *posX)
{
    // 1, 2 스테이지 배경 공백으로 초기화
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<20;j++)
        {
            for(int k=0;k<20;k++)
            {
                location[i][j][k] = ' ';
            }
        }
    }

    for(int j=0;j<2;j++)
    {
        for(int i=1;i<9;)				// 이벤트스테이지(1층)
        {
            int random1=rand()%9;
            int random2=rand()%9;

            if(random[j][random1][random2] == 0) 
            {
                random[j][random1][random2] = i;
                i++;
            }
        }
    }			

    // 플레이어의 리스폰 위치 (랜덤)
    *posY=rand()%5;
    *posX=rand()%5;
    location[0][*posY][*posX]='@';
}

void Print_status(char Field[100], int *behavior, int *money)
{
    printf("\t┌───────────────────────────────────────────────────┐\n");
    printf("\t              행동력:%d  돈:%d원\n│\t\t\t%s\n│",*behavior,*money,Field);
    printf("\t└───────────────────────────────────────────────────┘\n");
}

void Move(int random[][20][20], char location[][20][20], int *key, int *posY, int *posX, int *stage)	// 이동 값 반영 함수
{
    char enter;

    // 지나간길 점 남기기
    if(random[*stage][*posY][*posX]==0 || random[*stage][*posY][*posX]==20)
        location[*stage][*posY][*posX]='.';

    if(*key=='A')   //위
        *posY-=1;
    else if( *key=='D') //왼쪽
        *posX-=1;
    else if( *key=='C') //오른쪽
        *posX+=1;
    else if( *key=='B') // 아래
        *posY+=1;

    if(*posY<0 || *posX<0 || *posY>19 || *posX>19)
    {
        //line();
        //printf("더이상 갈 수 없는 장소 입니다.\n엔터 입력\n");	
        if(*posY<0)
            *posY=0;
        if(*posX<0)
            *posX=0;
        if(*posY>19)
            *posY=19;
        if(*posX>19)
            *posX=19;
        //line();
        //enter = getchar();
    }

    if(random[*stage][*posY][*posX]==0 || random[*stage][*posY][*posX]==4)
        location[*stage][*posY][*posX]='@';

    if(random[*stage][*posY][*posX]>=1&&random[*stage][*posY][*posX]<=8)	// 이벤트 발생 조건
    {
        system("clear");
        printf("전투 발생\n 엔터 입력 진행");
        while(getchar() != '\n');  // 버퍼 클리어
    }
}
void line(void)							// 라인
{
    printf("===================================================================================================\n\n");
}

int UI(char arr[][20][20], int stage)				// 미니맵 구현
{	
    if (stage==0)
        Blue

    printf("\t┌────────────────────────────────────────────────────────────────────────────────────────────────────┐\n");
    for(int a=2; a<62; a++)				
    {
        printf("\t│");
        for(int b=0; b<20; b++)
        {
            if(a%3==0)
                printf("  %c  ", arr[stage][(a/3)-1][b]);
            else 
                printf("  %c  ", ' ');
        }
        printf("│");
        printf("\n");
    }
    printf("\t└────────────────────────────────────────────────────────────────────────────────────────────────────┘\n");
    Def
}

int getch(void)					// 키보드 이동키 함수
{
    int ch;
    struct termios buf;
    struct termios save;

    tcgetattr(0,&save);
    buf=save;
    buf.c_lflag&=~(ICANON|ECHO);
    buf.c_cc[VMIN]=1;
    buf.c_cc[VTIME]=0;
    tcsetattr(0,TCSAFLUSH,&buf);
    ch=getchar();
    tcsetattr(0,TCSAFLUSH,&save);

    return ch;
}
