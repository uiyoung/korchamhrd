#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

int main()
{
    srand(time(NULL));
    const int MAX_FLOOR = 15; // 건물 층 수
    int currentFloor;
    int i, choice;
    int wantingFloorA, wantingFloorB, wantingFloorC;
    int isAGotOff, isBGotOff, isCGotOff; //A,B,C 내렸는지 정보 저장(0:안내림, 1:내림)
    int max;

    //initialize
    wantingFloorA = rand()%15+1;
    wantingFloorB = rand()%15+1;
    wantingFloorC = rand()%15+1;
    isAGotOff = 0;
    isBGotOff = 0;
    isCGotOff = 0;

    printf("A:저는 %d층에서 내려주세요\n", wantingFloorA);
    printf("B:저는 %d층에서 내려주세요\n", wantingFloorB);
    printf("C:저는 %d층에서 내려주세요\n", wantingFloorC);

    // finding max of a,b,c
    max = wantingFloorA;
    if(wantingFloorB > max)
        max = wantingFloorB;
    if(wantingFloorC > max)
        max = wantingFloorC;

    while(currentFloor<max)
    {
        printf("가고싶은 층을 입력하세요(1~%d층 [0]그만)\n", MAX_FLOOR);
        printf(">>");
        scanf("%d", &choice);

        if(choice==0)
        {
            printf("종료합니다.\n");
            break;
        }
        if(choice>MAX_FLOOR)
        {
            printf("최대 층수는 %d층 입니다.\n", MAX_FLOOR);
            continue;
        }

        printf("이동 중...\n");
        sleep(1);
        currentFloor = choice;
        printf("%d층에 도착했습니다.\n", currentFloor);
        printf("문이 열렸습니다.\n");
        putchar('\n');

        if(currentFloor == wantingFloorA)
        {
            isAGotOff = 1;
            printf("A가 내렸습니다.\n");
        }
        if(currentFloor == wantingFloorB)
        {
            isBGotOff = 1;
            printf("B가 내렸습니다.\n");
        }
        if(currentFloor == wantingFloorC)
        {
            isCGotOff = 1;
            printf("C가 내렸습니다.\n");
        }

        for(i=3;i>0;i--)
        {
            printf("%d초 후 에 문이 닫힙니다.\n", i);
            sleep(1);
            printf("버튼을 누를까? ([0]아니오 [1]네)\n");
            printf(">>");
            scanf("%d", &choice);

            if(choice==0)
                continue;

            printf("[0]열림 [1]닫힘 >>");
            scanf("%d", &choice);
            
            if(choice==0)
                i=4;
            else if(choice==1)
                i=0;
        }
        printf("문이 닫혔습니다.\n");
    }

    putchar('\n');

    if(!isAGotOff)
        printf("A가 못내려서 화가 났다!\n");
    if(!isBGotOff)
        printf("B가 못내려서 화가 났다!\n");
    if(!isCGotOff)
        printf("C가 못내려서 화가 났다!\n");

    return 0;
}
