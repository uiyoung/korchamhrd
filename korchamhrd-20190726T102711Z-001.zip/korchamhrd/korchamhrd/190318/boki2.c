#include <stdio.h>

int main()
{
    int i, j;

    for(i=0;i<8;i++)
    {
        for(j=0;j<8;j++)
        {
            printf("%s", j<i ? " " : "*");
        }
        for(j=0;j<8;j++)
        {
            printf("%s", j<7-i ? " " : "*");
        }
        printf("\n");
    }

    for(i=0;i<8;i++)
    {
        for(j=0;j<8;j++)
        {
            printf("%s", j<8-i ? "*" : " ");
        }
        for(j=0;j<i+1;j++)
        {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}

