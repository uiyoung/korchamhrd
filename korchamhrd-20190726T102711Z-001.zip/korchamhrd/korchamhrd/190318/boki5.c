#include <stdio.h>

int main()
{
    int num, i;
    int position = 0;

    while(1)
    {
        printf("-10~10 까지의 정수 입력>>");
        scanf("%d", &num);
        
        if(num==0 || num<-10 || num>10)
            break;

        position += num;
        for(i=0;i<position;i++)
        {
            printf("%s", " ");
        }

        printf("*\n");
    }
    
    printf("종료\n");

    return 0;
}
