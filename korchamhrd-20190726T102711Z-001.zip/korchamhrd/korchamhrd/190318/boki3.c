#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int random;
    int counter=1;
    int input;

    srand(time(NULL));
    random = rand()%30+1;

    while(1)
    {
        printf("1~30숫자 입력>>");
        scanf("%d", &input);

        if(random == input)
        {
            printf("%d회 만에 맞혔습니다.\n", counter);
            break;
        }
        else if(random > input)
            printf("%d보다 큽니다.\n", input);
        else 
            printf("%d보다 작습니다.\n", input);

        counter++;
    }

    return 0;
}
