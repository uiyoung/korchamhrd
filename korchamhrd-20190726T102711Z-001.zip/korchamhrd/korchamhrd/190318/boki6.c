#include <stdio.h>

int main()
{
    const double PRINCIPAL = 10000000;
    const double INTEREST = 0.07;
    double result = PRINCIPAL;
    int i;

    for(i=0; ;i++)
    {
        result += result * INTEREST;
        if(result >= PRINCIPAL * 2)
        {
            printf("%d년 저금결과 : %.0lf원\n", i, result);
            break;
        }
    }

    return 0;
}
