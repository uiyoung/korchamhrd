#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int numbers[] = {500, 999, 4500};
    int input1, input2;

    while(1)
    {
        printf("1. 500맞히기\n");
        printf("2. 999맞히기\n");
        printf("3. 4500맞히기\n>>");
        scanf("%d", &input1);
        
        printf("입력>>");
        scanf("%d", &input2);

        if(input2==numbers[input1-1])
        {
            printf("종료\n");
            return 0;
        }
        else
            printf("%d\n", numbers[input1-1]-input2);
    }

    return 0;
}

