#include <stdio.h>

int main()
{
    int i, j, num;
    int input;

    printf("숫자 입력>>");
    scanf("%d", &input);

    for(i=0;i<input;i++)
    {
        num = i;
        for(j=0;j<input;j++)
        {
            if(num>input-1)
                num=0;

            printf("%d", ++num);
        }
        printf("\n");
    }

    printf("\n");

    for(i=0;i<input;i++)
    {
        num = i;
        for(j=0;j<input;j++)
        {
            printf("%d", ++num);
        }
        printf("\n");
    }

    return 0;
}
