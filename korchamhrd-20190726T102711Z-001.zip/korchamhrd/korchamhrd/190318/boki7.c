#include <stdio.h>

int main()
{
    int input;
    int i, j;
    int num = -1;

    printf("자연수 n입력>>");
    scanf("%d", &input);

    for(i=0;i<input;i++)
    {
        for(j=0;j<input;j++)
        {
            if(num>=9)
                num=-1;

            printf("%d ", num+=2);
        }
        printf("\n");
    }
    
    return 0;
}
