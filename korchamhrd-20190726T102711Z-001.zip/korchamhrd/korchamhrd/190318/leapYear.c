#include <stdio.h>

int main()
{
    int year;
    
    while(1)
    {
        printf("연도 입력(종료:0)>>");
        scanf("%d", &year);

        if(year==0)
            break;

        if(year<0)
            printf("%d년은 기원전입니다.\n", year);
        else if(year%4==0 && year%100!=0 || year%400==0)
            printf("%d년은 윤년입니다.\n", year);
        else
            printf("%d년은 평년입니다.\n", year);
    }

    printf("종료합니다\n");

    return 0;
}
