#include <stdio.h>

int main()
{
    int spentTime;
    int i, counter;
    const double HOUR_HAND = 0.5; // 1분동안 움직이는 시침의 각도
    const double MIN_HAND = 6; // 1분동안 움직이는 분침의 각도

    printf("해당 시간이 흐르는 동안 시계바늘이 몇번 겹치는지 계산하는 프로그램입니다.\n");
    printf("원하는 시간을 분단위로 입력해주세요>>");
    scanf("%d", &spentTime);

    for(int i=1;i<=spentTime;i++)
    {
        double degreeOfHourHand = HOUR_HAND*i-360*(i/720);
        double degreeOfMinHand = MIN_HAND*i-360*(i/60);

        if(degreeOfHourHand == degreeOfMinHand || (degreeOfHourHand > degreeOfMinHand && degreeOfHourHand+HOUR_HAND< degreeOfMinHand+MIN_HAND))
        {
            printf("시계가 출발해 %d분 째에 시계바늘이 서로 겹쳐졌습니다.\n", i);
            counter++;
        }
   }

    printf("%d분의 시간이 흐를 동안 시계바늘은 총 %d번 겹쳐졌습니다.\n", spentTime, counter);
    return 0;
}
