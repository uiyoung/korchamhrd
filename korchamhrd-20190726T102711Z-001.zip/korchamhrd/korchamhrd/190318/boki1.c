#include <stdio.h>

int main()
{
    int i, j;

    for(i=0;i<5;i++)
    {
        for(j=0;j<i+5;j++)
        {
            printf("%s", j<4-i ? " " : "*");
        }
        for(j=0;j<-2*i+9;j++)
        {
            printf(" ");
        }
        for(j=0;j<2*i+1;j++)
        {
            printf("*");
        }
        printf("\n");
    }

    printf("\n");

    for(i=0;i<5;i++)
    {
        printf("     ");
        for(j=0;j<9-i;j++)
        {
            printf("%s", j<i ? " " : "*");
        }
        printf("\n");
    }

    return 0;
} 
