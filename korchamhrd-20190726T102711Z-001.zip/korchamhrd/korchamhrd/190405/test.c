#include <stdio.h>

int main()
{
    int arr[5][100];
    int damage = 330;

    int row = damage/100;
    int col = damage%100;

    //init
    for(int i=0;i<5;i++)
        for(int j=0;j<100;j++)
            arr[i][j]=4;

    // fire
    for(int i=4;i>4-row;i--)
    {
        for(int j=99;j>=0;j--)
        {
            arr[i][j]=0;
        }
    }
    for(int i=99;i>=99-col;i--)
    {
        arr[4-row][i]=0;
    }

    //print
    for(int i=0;i<5;i++)
    {
        for(int j=0;j<100;j++)
        {
            printf("%d", arr[i][j]);
        }
        putchar('\n');
    }

    return 0;
}
