#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

void InitForest(int (*forest)[100], int rowSize, int colSize);
void ChangeArrValues(int (*forest)[100], int rowSize, int colSize, int *pTotalFires);
int Fire(int *pTotalFires, int min, int max);
int Recover(int *pTotalFires, int probability, int min, int max);
void PrintForest(int (*forest)[100], int rowSize, int colSize);
void CheckEnding(int (*forest)[100]);
void PrintMessage(char** messages, int changeAmount, int *pTotalFires, int index, int isDamaged);
void PrintMenu(const char** skillNames, int turnGauge, const int coolTimes[]);

int main()
{
    int forest[5][100];
    char *messages[7] = { "불이야!!", "물호스 사용", "소화전 사용", "소방차 사용", "소방헬기 사용", "메테오 소환", "국군장병과 마을주민의 나무심기운동"}; 
    const char *skillNames[5] = {"물호스", "소화전", "소방차", "소방헬기", "메테오"};
    const int skillSuccessRates[] = {90, 70, 50, 30};
    const int minRecoverAmounts[] = {1, 10 ,10, 100};
    const int maxRecoverAmounts[] = {4, 80, 150, 500};
    const int skillCoolTimes[] = {0, 2, 3, 5, 7};
    int rowSize = sizeof(forest)/sizeof(forest[0]);
    int colSize = sizeof(forest[0])/sizeof(int);
    int choice = 1;
    int skillChoice = 0;
    int totalFires = 0;
    int turnCounter = 0; 
    int turnGauge = 0; 
    int changeAmount = 0;   //나무변화량 
    int choiceAgainFlag = 0;
    srand(time(NULL));

    // initialize forest
    InitForest(forest, rowSize, colSize);
    system("clear");
    puts("식목일 특집 회장님 별장을 지키자!");
    PrintForest(forest, rowSize, colSize);
    printf("[1]시작하기 [0]나가기>>");
    scanf("%d", &choice);
    turnCounter++;
    turnGauge++;

    while(choice!=0)
    {
        int probability = rand()%100+1;

        if(choiceAgainFlag == 0)
        {
            if(probability<=70)
            {
                changeAmount = Fire(&totalFires, 1, 500);   
                ChangeArrValues(forest, rowSize, colSize, &totalFires);

                // flicker 3times
                for(int i=0;i<3;i++)
                {
                    system("clear");
                    putchar('\n');
                    PrintForest(forest, rowSize, colSize);
                    sleep(1);
                    system("clear");
                    PrintMessage(messages, changeAmount, &totalFires, 0, 1);
                    PrintForest(forest, rowSize, colSize);
                    sleep(1);
                }
            }
            else
            {
                changeAmount = Recover(&totalFires, 50, 1, 200);
                if(changeAmount!=0)
                    ChangeArrValues(forest, rowSize, colSize, &totalFires);

                // flicker 3times
                for(int i=0;i<3;i++)
                {
                    system("clear");
                    putchar('\n');
                    PrintForest(forest, rowSize, colSize);
                    sleep(1);
                    system("clear");
                    PrintMessage(messages, changeAmount, &totalFires, 6, 0);
                    PrintForest(forest, rowSize, colSize);
                    sleep(1);

                }
            }
            CheckEnding(forest);
        }

        //print menu
        PrintMenu(skillNames, turnGauge, skillCoolTimes);
        scanf("%d", &skillChoice);

        if(skillChoice<1 || skillChoice>5)
        {
            puts("올바른 선택지를 골라주세요.");
            sleep(1);
            choiceAgainFlag = 1;
            system("clear");
            putchar('\n');
            PrintForest(forest, rowSize, colSize);
            continue;
        }

        if(turnGauge < skillCoolTimes[skillChoice-1])
        {
            puts("아직 사용 할 수 없습니다.");
            sleep(1);
            choiceAgainFlag = 1;
            system("clear");
            putchar('\n');
            PrintForest(forest, rowSize, colSize);
            continue;
        }

        if(skillChoice == 5)
        {
            probability = rand()%100+1;
            choiceAgainFlag = 0;
            if(probability<=5) 
            {
                puts("meteor ending");
                exit(1);
            }
            else
            {
                puts("faield to summon meteor");    
                choiceAgainFlag = 1;
                turnGauge -= skillCoolTimes[skillChoice-1];
                continue;
            }
        }

        changeAmount = Recover(&totalFires, skillSuccessRates[skillChoice-1], minRecoverAmounts[skillChoice-1], maxRecoverAmounts[skillChoice-1]);
        turnGauge -= skillCoolTimes[skillChoice-1];
        choiceAgainFlag = 0;
        if(changeAmount!=0)
            ChangeArrValues(forest, rowSize, colSize, &totalFires);

        // flicker 2times
        for(int i=0;i<2;i++)
        {
            system("clear");
            putchar('\n');
            PrintForest(forest, rowSize, colSize);
            sleep(1);
            system("clear");
            PrintMessage(messages, changeAmount, &totalFires, skillChoice, 0);
            PrintForest(forest, rowSize, colSize);
            sleep(1);
        }

        printf("[1]다음 턴 [0]그만하기>>");

        scanf("%d", &choice);

        turnCounter++;
        turnGauge++;
    }   

    return 0;
}

void PrintMessage(char** messages, int changeAmount, int *totalFires, int index, int isDamaged)
{
    printf("%s", messages[index]);

    if(*totalFires == 0)
    {
        puts("(모든 나무가 회복되었습니다.)");
        return;
    }

    if(changeAmount == 0)
    {
        printf(" 실패!\n");
        return;
    }

    printf("(%d %s)\n", changeAmount, isDamaged ? "damaged" : "recovered");
}

void PrintMenu(const char** skillNames, const int turnGauge, const int coolTimes[])
{
    for(int i=0;i<5;i++)
        printf("[%d]%s 사용(%d/%d)\n", i+1, skillNames[i], turnGauge, coolTimes[i]);

    printf(">>");
}

void PrintForest(int (*forest)[100], int rowSize, int colSize)
{
    puts("┌─────┐");
    puts("│villa│");
    puts("└─────┘");
    puts("────────────────────────────────────────────────────────────────────────────────────────────────────");
    for(int i=0;i<rowSize;i++)
    {
        for(int j=0;j<colSize;j++)
        {
            if(forest[i][j]==4)
                printf("*");
            else
                printf(" ");
        }
        putchar('\n');
    }
    puts("────────────────────────────────────────────────────────────────────────────────────────────────────");
}

void InitForest(int (*forest)[100], int rowSize, int colSize)
{
    for(int i=0;i<rowSize;i++)
        for(int j=0;j<colSize;j++)
            forest[i][j]=4;
}

int Fire(int *pTotalFires, int min, int max)
{
    int damage = rand()%(max+1-min)+min;
    *pTotalFires += damage;

    if(*pTotalFires>500)
        *pTotalFires = 500;

    return damage;
} 

int Recover(int *pTotalFires, int probability, int min, int max)
{
    int successParam = rand()%100+1;

    if(successParam > probability)
        return 0;

    int recoverAmount = rand()%(max+1-min)+min;
    *pTotalFires -= recoverAmount;

    if(*pTotalFires<0)
        *pTotalFires = 0;

    return recoverAmount;
}

// change value of forest array by totalFires (4:tree, 0:fire)
void ChangeArrValues(int (*forest)[100], int rowSize, int colSize, int *pTotalFires)
{
    int firedRow = (*pTotalFires)/colSize;
    int firedCol = (*pTotalFires)%colSize;

    // initialize forests
    InitForest(forest, rowSize, colSize);

    // delete fired rows
    for(int i=rowSize-1;i>rowSize-1-firedRow;i--)
    {
        for(int j=colSize-1;j>=0;j--)
        {
            forest[i][j]=0;
        }
    }
    // delete remained fired cols
    for(int i=colSize-1;i>colSize-1-firedCol;i--)
    {
        forest[rowSize-1-firedRow][i] = 0;
    }
}

void CheckEnding(int (*forest)[100])
{
    if(forest[0][0]==0)
    {
        puts("모두 불에 타버렸습니다.");
        exit(1);
    }
}

