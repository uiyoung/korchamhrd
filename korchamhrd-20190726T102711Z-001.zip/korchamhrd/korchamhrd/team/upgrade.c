#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

void PrintUpgradeStatus(int gold, int *atk, int def, int atkLev, int defLev);
void PrintUpgradeMenu(int atkLev, int defLev);
int Upgrade(int *gold, int *level);
int GetUpgradePrice(int level);
void PrintSword(int level);
void PrintShield(int level);

int main()
{
    int choice = 1;
    int atk[] = {100, 300}; // 공격력
    int def = 1;    // 방어력
    int gold = 500000;
    int atkLev = 0; // 현재 공격강화레벨
    int defLev = 0; // 현재 방어강화레벨
    int changeValue; // 강화에 의한 변화치
    srand(time(NULL));

    while(choice!=0)
    {
        PrintUpgradeStatus(gold, atk, def, atkLev, defLev);
        PrintUpgradeMenu(atkLev, defLev);
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
                changeValue = Upgrade(&gold, &atkLev);
                atk[0] += changeValue;
                atk[1] += changeValue;
                printf("공격력 : %d~%d\n", atk[0], atk[1]);
                break;
            case 2:
                def += Upgrade(&gold, &defLev);
                printf("방어력: %d\n", def);
                break;
            case 0:
                printf("강화를 종료합니다.\n");
                break;
            default:
                printf("올바른 선택지를 골라주세요\n");
                break;
        }
    }
    return 0;
}

void PrintUpgradeStatus(int gold, int *atk, int def, int atkLev, int defLev)
{
    system("clear");
    printf("골드 : %d\n", gold);
    puts("──────────────────────────────────────────────────────────────────────");
    printf("공격력(+%d강) : %d~%d\n", atkLev, atk[0], atk[1]);
    PrintSword(atkLev);
    puts("──────────────────────────────────────────────────────────────────────");
    printf("방어력(+%d강) : %d\n", defLev, def);
    PrintShield(defLev);
    puts("──────────────────────────────────────────────────────────────────────");
    puts("공격력 또는 방어력을 강화 할 수 있습니다.");
    puts("1~3강 실패시 패널티x, 4강~7강 실패시 1강 하락, 8강~10강 실패시 0~5강으로 하락");
    puts("──────────────────────────────────────────────────────────────────────");
}

void PrintUpgradeMenu(int atkLev, int defLev)
{
    printf("[1]공격력 강화(%d골드)\n", GetUpgradePrice(atkLev));
    printf("[2]방어력 강화(%d골드)\n", GetUpgradePrice(defLev));
    puts("[0]나가기");
    printf(">>");
}

int GetUpgradePrice(int level)
{
    int price = 200;  // 초기 강화비용

    for(int i=0;i<level;i++)   // 강화비용 강화레벨당 10%씩 증가
        price *= 1.1;

    return price;
}

int Upgrade(int *gold, int *level)
{
    int upgradeGaps[] = {10, 10, 20, 20, 30, 30, 40, 50, 60, 100};  // 강화레벨별 증가폭
    int successRate = (int)(100-(100*0.1*(*level)));   // 성공확률 강화레벨당 10%씩 감소
    if(*gold<= GetUpgradePrice(*level))
    {
        puts("골드가 부족하여 강화를 할 수 없습니다.");
        sleep(1);
        return 0;
    }

    if(*level>=10)
    {
        puts("더 이상 강화 할 수 없습니다.");
        sleep(1);
        return 0;
    }

    // 골드 소모
    *gold -= GetUpgradePrice(*level);
    printf("골드 %d를 소모했습니다.\n", GetUpgradePrice(*level));
    sleep(1);

    int probability = rand()%100+1;

    /* 강화 성공 */
    if(probability <= successRate)
    {
        *level+=1;
        printf("+%d강 성공!\n", *level);
        sleep(1);

        return upgradeGaps[*level-1];
    }

    /* 강화 실패 */
    else
    {
        int newLev = 0; // 강화 실패 후 강화레벨
        int gaps = 0;

        puts("강화가 실패하였습니다.");
        sleep(1);

        // 강화레벨 3이하시 변동x
        if(*level<=3)
            return 0;

        // 5~8강 실패시 1강 감소
        if(*level>=4 && *level<=7)
            newLev = *level-1;

        // 9강~10강 실패시 0~5강으로 하락
        if(*level>=8)
            newLev = rand()&6;

        for(int i=*level-1;i>=newLev;i--)
            gaps -= upgradeGaps[i];

        *level = newLev;

        return gaps;
    }
}

void PrintSword(int level)
{
    if(level<3)
    {
        printf("   / \n");
        printf("=={==========-\n");
        printf("   \\\n");
    }
    else if(level>=3 && level<=4)
    {
        printf("      /| ________________\n");
        printf("O|===|* >________________>\n");
        printf("      \\|\n");
    }
    else if(level>=5 && level<=6)
    {
        printf("         />_________________________________\n");
        printf("[########[]_________________________________>\n");
        printf("         \\>\n");
    }
    else if(level>=7 && level<=9)
    {
        printf("              />\n");
        printf(" (           //-------------------------------------(\n");
        printf("(*)OXOXOXOXO(*>======================================\\\n");
        printf(" (           \\\\---------------------------------------)\n");
        printf("              \\>\n");
    }

    else if(level>=10)
    {
        printf("                              .___.\n");
        printf("          /)               ,-^     ^-.\n");
        printf("         //               /           \\\n");
        printf(".-------| |--------------/  __     __  \\-------------------.__\n");
        printf("|WMWMWMW| |>>>>>>>>>>>>> | />>\\   />>\\ |>>>>>>>>>>>>>>>>>>>>>>:>\n");
        printf("`-------| |--------------| \\__/   \\__/ |-------------------'^^\n");
        printf("         \\\\               \\    /|\\    /\n");
        printf("          \\)               \\   \\_/   /\n");
        printf("                            |       |\n");
        printf("                            |+H+H+H+|\n");
        printf("                            \\       /\n");
        printf("                             ^-----^\n");
    }
}
void PrintShield(int level)
{
    switch(level)
    {
        case 0:
        case 1:
        case 2:
            printf("  |`-._/\\_.-`|\n");
            printf("  |    ||    |\n");
            printf("  |___o()o___|\n");
            printf("  |__((<>))__|\n");
            printf("  \\   o\\/o   /\n");
            printf("   \\   ||   /\n");
            printf("    \\  ||  /\n");
            printf("     '.||.'\n");
            printf("       ``\n");
            break;
        case 3:
        case 4:
            printf("    _..._\n");
            printf(".-'_.---._'-.\n");
            printf("||####|(__)||\n");
            printf("((####|(**)))\n");
            printf(" '\\###|_''/'\n");
            printf("  \\\\()|##//\n");
            printf("   \\\\ |#//\n");
            printf("    .\\_/.\n");
            printf("     L.J\n");
            printf("      \"\n");
            break;
        case 5:
        case 6:
            printf("  |\\ _..--.._ /|\n");
            printf("  |############|\n");
            printf("   )##########(\n");
            printf("._/##.'//\\\\'.##\\_.\n");
            printf(" .__)#((()))#(__.\n");
            printf("  \\##'.\\\\//.'##/\n");
            printf("   \\####\\/####/\n");
            printf("   /,.######.,\\\n");
            printf("  (  \\##__##/  )\n");
            printf("      \"(\\/)\"\n");
            printf("        )(\n");
            break;
        case 7:
        case 8:
        case 9:
            printf(" _________________________ \n");
            printf("|<><><>     |  |    <><><>|\n");
            printf("|<>         |  |        <>|\n");
            printf("|           |  |          |\n");
            printf("|  (______ <\\-/> ______)  |\n");
            printf("|  /_.-=-.\\| \" |/.-=-._\\  | \n");
            printf("|   /_    \\(o_o)/    _\\   |\n");
            printf("|    /_  /\\/ ^ \\/\\  _\\    |\n");
            printf("|      \\/ | / \\ | \\/      |\n");
            printf("|_______ /((( )))\\ _______|\n");
            printf("|      __\\ \\___/ /__      |\n");
            printf("|--- (((---'   '---))) ---|\n");
            printf("|           |  |          |\n");
            printf("|           |  |          |\n");
            printf(":           |  |          :     \n");
            printf(" \\<>        |  |       <>/    \n") ;
            printf("  \\<>       |  |      <>/       \n");
            printf("   \\<>      |  |     <>/       \n");
            printf("    `\\<>    |  |   <>/'         \n");
            printf("      `\\<>  |  |  <>/'         \n");
            printf("        `\\<>|  |<>/'         \n");
            printf("          `-.  .-`           \n");
            printf("            '--'\n");
            break;
        case 10:
            printf("          {}         \n");
            printf("        .::::.       \n");
            printf("    @\\\\/W\\/\\/W\\//@   \n");
            printf("     \\\\/^\\/\\/^\\//    \n");
            printf("      \\_O_{}_O_/     \n");
            printf(" ____________________ \n");
            printf("|<><><>  |  |  <><><>|\n");
            printf("|<>      |  |      <>|\n");
            printf("|<>      |  |      <>|\n");
            printf("|<>   .--------.   <>|\n");
            printf("|     |   ()   |     |\n");
            printf("|_____| (O\\/O) |_____|\n");
            printf("|     \\   /\\   /     |\n");
            printf("|------\\  \\/  /------|\n");
            printf("|       '.__.'       |\n");
            printf("|        |  |        |\n");
            printf(":        |  |        :\n");
            printf(" \\       |  |       /\n");
            printf("  \\<>    |  |    <>/\n");
            printf("   \\<>   |  |   <>/\n");
            printf("    `\\<> |  | <>/'\n");
            printf("      `-.|__|.-`\n");
            break;
    }
}
