#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<unistd.h>
#include<termios.h>
#include <string.h>

#define Red printf("%c[1;31m", 27);
#define Def printf("%c[0m", 27);
#define Blue printf("%c[1;34m", 27);
#define GREEN printf("%c[1;32m", 27);
#define YELLOW printf("%c[1;33m", 27);
#define PURPLE printf("%c[1;35m", 27);
#define GRAY printf("\x1b[30m"); // 회색 출력
#define RESET printf("\x1b[0m"); // 흰색 출력
void line(void);						
//메인 함수
void Initialize(char location[][10][10], int random[][10][10], int *num1, int *num2);
int UI(char arr[][10][10], int stage);
void Print_status(int hp, int atk[], int def, int gold, int item[], int stage);
void Moving(int random[][10][10], char location[][10][10], int *Key, int *num1, int *num2, int *stage);
int Event_1(int *hp, int *gold, int atk[], int *def, int item[], int *stage, int num1, int num2, char location[][10][10]);
void Event_2(int *gold, char location[][10][10], int stage, int num1, int num2);
void Event_3(int *gold, int *hp, int *def, int atk[], int item[], char location[][10][10], int stage, int num1, int num2);
int Event_4(int *hp, int *gold, int atk[], int *def, int item[], int *stage, int num1, int num2, int random[][10][10]);
int Event_5(int *gold, int *hp, int item[], int stage, int num1, int num2, char location[][10][10] );
int Event_6(int *hp, int stage, int num1, int num2, char location[][10][10]);
void Event_7(int *gold, int atk[], int *def, int *atkLev, int *defLev, int *changeValue, int stage, int num1, int num2, char location[][10][10]);
int Event_8(int *hp, int *gold, int item[], int stage, int num1, int num2, char location[][10][10]);
//홀짝도박 함수
void Print(int g_gamble);					
int  Gambling(int *gold);
void EvenAndOdd(int *End,int bet,int *gold,int c_count);
int getch(void);
// 상점 함수
void store(int *gold, int item[], int *hp, int *def, int atk[2]);
//전투 공용 함수
void player_itf(int mode, int Potion_chk);
void gotoxy(int x,int y);
void delay_ms(int num);
//전투 잡몹 함수
void Print_LG_Battle_status(int *hp, int *gold, int *atk, int *def, char Mname[][100], int *Matk, int *MHp, int *Turn, int *M_pick, int Potion_chk);
void Battle_LG_Player_Attack(int *hp, int *gold, int *atk, int *def, char Mname[][100], int Matk[], int MHp[], int *Turn, int *M_pick, int *Potion_chk);
void Print_Battle_Itemlist(int *item);
void soldier1_itf(int mode);
void soldier2_itf(int mode);
void soldier3_itf(int mode);
void soldier4_itf(int mode);
int Battle_LG_Monster_Attack(int *hp, int *gold, int *atk, int *def, char Mname[][100], int Matk[], int MHp[], int *Turn, int *M_pick, int *Def_chk, int Potion_chk);
int Battle_Low_Grade (int *hp, int *gold, int atk[], int *def, int item[], int *stage);
int Battle_LG_Input();
int Battle_LG_Itemuse(int *Hp, int *item, int *Potion_chk, int *stage);
//전투 중간보스, 최종보스 함수
void Print_HG_Battle_status(int *hp, int *gold, int *Atk, int *def, char Mname[][100], int *MAtk, int *MHp, int *Turn, int *M_pick,int *stage, int Potion_chk);
void Battle_HG_Player_Attack(int *hp, int *gold, int *Atk, int *def, char Mname[][100], int MAtk[], int MHp[], int *Turn, int *M_pick, int *Potion_chk,int *stage);
void md_boss_itf(int mode,int *stage);
void boss_itf(int mode);
int Battle_High_Grade(int *hp,int *gold,int Atk[],int *def,int item[],int *stage,int monster);
int Battle_HG_Monster_Attack(int *hp, int *gold, int *Atk, int *def, char Mname[][100], int MAtk[], int MHp[], int *Turn, int *M_pick, int *Def_chk, int Potion_chk);
int Battle_HG_Itemuse(int *Hp, int *item, int *Potion_chk, int *stage,int monster);
// 슬롯머신 함수
int sm_main(int *gold, int *hp, int item[7]);				
void sm_effect(int *hp, int *gold);
void sm_enter(void);
// 함정 기억력테스트 파트
int Trap(int *hp,int item[],int *gold);	
int Trap_Square(int matrix,int matrix2,int matrix3,int matrix4,int matrix5,int *stage); // 30x100 사각형안에 랜덤한 곳에 특수 문자를 생성
void Trap_Intro(void);	// 함정 인트로
void Trap_Print_Clear_Requirements(int *stage);	// 함정 클리어 조건 출력
int Trap_escape(void);	// 함정 탈출
int Trap_Answer(char Symbols_Value[],char Symbols[],int *stage);	// 정답 맞추기
int Trap_Stage(int *stage);	// 트랩의 스테이지를 분할
void Enter(void);

// 공격력/방어력 강화 함수
void PrintUpgradeStatus(int gold, int *atk, int def, int atkLev, int defLev);
void PrintUpgradeMenu(int atkLev, int defLev);
int Upgrade(int *gold, int *level);
int GetUpgradePrice(int level);
void PrintSword(int level);
void PrintShield(int level);

//병원 함수
int HP_result(int hp_res, int count); //게임결과에 따른 hp결과
int game(void); //게임을 표현할 함수
int restart(int cho); //플레이를 다시할지 의사 물어보는 함수
int hospital(int *hp);  //조민권 파트 스타
void mercy(void);

int main(void)
{
	char location[2][10][10];			// 미니맵에 존재하는 *,ㅁ,O변수
	int hp=1000, def=50, gold=1000;			// 진혁의 기본 정보 변수
	int atk[2]={100,300};				// 진혁의 공격력 변수 (최소, 최대)
	int num1,num2;					// 좌표를 나타낼 변수
	int random[2][10][10]={0};			// 이벤트좌표 배열
	int Key;				        // 키보드 위치 인식 변수
	int stage=0;					// 1층 시작
	int sniffling=0; 				//게임 끝
	int item[7]={5,0,0,0,0,0,1};			//아이템 변수
	int end=1;					// 이벤트 종료 변수
	int atkLev = 0; 				// 현재 공격강화레벨
	int defLev = 0; 				// 현재 방어강화레벨
	int changeValue; 				// 강화에 의한 변화치
	char enter;					//버퍼용 변수
	
	srand(time(NULL));
	Initialize(location, random, &num1, &num2); // 초기화 함수
	
	while(1)
	{
		usleep(1000);
		system("clear");
		Def
		UI(location, stage);
		Print_status(hp, atk, def, gold, item, stage);
		Key=getch();						// 키보드 방향키 감지
		if(Key=='A'||Key=='D'||Key=='C'||Key=='B')			
		{
			Moving(random, location, &Key, &num1, &num2, &stage);		// 키보드 방향키 입력된 결과를 맵 배열에 반영하는 함수
			
			switch( random[stage][num1][num2] )
			{
				case 1:
					end = Event_1(&hp, &gold, atk, &def, item, &stage, num1, num2, location);	// 중간보스, 최종보스 함수
				break;
				case 2:
					Event_2(&gold,location, stage, num1, num2);				// 홀짝게임 함수
				break;
				case 3:
					Event_3(&gold, &hp, &def, atk, item, location, stage, num1, num2);		// 상점 함수
				break;
				case 4:
					end = Event_4(&hp, &gold, atk, &def, item, &stage, num1, num2, random);		// 일반 몬스터 함수
				break;
				case 5:
					end = Event_5(&gold, &hp, item, stage, num1, num2, location);			// 슬롯머신 게임 함수
				break;
				case 6:
					end = Event_6(&hp, stage, num1, num2, location);				// 병원 함수
				break;
				case 7:
					Event_7(&gold, atk, &def, &atkLev, &defLev, &changeValue, stage, num1, num2, location);  // 강화상점 함수
				break;
				case 8:
					Event_8(&hp, &gold, item, stage, num1, num2, location);				// 기억력 테스트 게임 함수
				break;
			}	
			if(end == 0) return 0;					
		}
	}
	return 0;
}
void Initialize(char location[][10][10], int random[][10][10], int *num1, int *num2)
{
	int random1, random2;			        // 랜덤값 저장 변수
		
	for(int i=0;i<10;i++)				// 1,2 스테이지 배경 초기화
	{
		for(int j=0;j<10;j++)
		{
			location[0][i][j]=' ';
			location[1][i][j]=' ';
		}
	}
	
	for(int j =0; j<=1; j++)
	{
		for(int i =1;  i<9;)				// 이벤트스테이지(1층)
		{
			random1=rand()%9;
			random2=rand()%9;
			if(random[j][random1][random2] == 0) 
			{
				random[j][random1][random2] = i;
				i++;
			}
		}
	}			
	// 진혁이의 리스폰 위치 (랜덤)
	*num1=rand()%10;
	*num2=rand()%10;
	location[0][*num1][*num2]='O';
}
void Print_status(int hp, int atk[], int def, int gold, int item[], int stage)	// 스테이터스 출력 함수
{
	line();
	printf("    hp = %5d\t   최소공격력 = %5d\t  최대공격력 = %5d\t방어력 = %5d\t 골드 = %d\n    힐링 포션 = %d개\t화속성 포션 = %d개   \t수속성 포션 = %d개\t빛속성 포션 = %d개\n    탈출권 = %d개\n\n",hp,atk[0],atk[1],def,gold,item[0],item[1],item[2],item[3],item[6]); 		// 인터페이스 구현
	printf("\t\t%d층 -%s\n\n",stage+1, stage==0 ? "Water field" : "FIre field");
	line();
	printf("\t진혁는 미탐색 지역을 탐색한다.\n\t(위 - ↑, 왼쪽 - ←, 오른쪽 - →, 아래쪽 - ↓)\n");
}
void Moving(int random[][10][10], char location[][10][10], int *Key, int *num1, int *num2, int *stage)	// 이동 값 반영 함수
{
	char enter;
					
	if(random[*stage][*num1][*num2]==0 || random[*stage][*num1][*num2]==4)
	{
		location[*stage][*num1][*num2]='.';
	}
	if(*Key=='A') *num1-=1;
	else if( *Key=='D') *num2-=1;
	else if( *Key=='C') *num2+=1;
	else if( *Key=='B') *num1+=1;
	if(*num1<0 ||*num2<0 || *num1>9||*num2>9)
	{
		line();
		printf("더이상 갈 수 없는 장소 입니다.\n엔터 입력\n");	
		if(*num1<0) *num1=0;
		if(*num2<0) *num2=0;
		if(*num1>9) *num1=9;
		if(*num2>9) *num2=9;
		line();
		enter = getchar();
	}
	if( random[*stage][*num1][*num2]==0 || random[*stage][*num1][*num2]==4 )
	{
		location[*stage][*num1][*num2]='O';
	}
	if( random[*stage][*num1][*num2]>=1&&random[*stage][*num1][*num2]<=8 )	// 이벤트 발생 조건
	{
		system("clear");
		printf("이벤트 발생\n 엔터 입력 진행");
		while(getchar() != '\n');  // 버퍼 클리어
	}
}
int Event_1(int *hp, int *gold, int atk[], int *def, int item[], int *stage, int num1, int num2, char location[][10][10])	// 중간보스, 최종보스 함수
{
	int bettle_end;
	int choice;
	
	bettle_end=Battle_High_Grade(hp, gold, atk, def, item, stage, 1);
	if(bettle_end==1)
	{
		line();
		printf("진혁이는 몬스터를 성공적으로 잡았습니다!\n\n");
		line();
		sleep(1);
		if(*stage == 0)
		{
			printf("포탈 발견!\n\n1. 2층으로 이동한다.\n2. 싫어 가지 않을꺼야.\n>>");
			scanf("%d", &choice);
			if(choice==1)
			{
				location[0][num1][num2]='@';
				location[1][num1][num2]='O';
				*stage=1;
			}
			else if(choice==2)
			{
				printf("진혁이는 시공의 폭풍 속으로 빨려들어가서 사망하였습니다.\n\n");
				return 0;
			}
		}
		else if ( *stage == 1)
		{
			printf("포탈 발견!\n\n1. 1층으로 이동한다.\n2. 싫어 가지 않을꺼야.\n3. 최종 보스 에게로 이동.\n>>");
			scanf("%d", &choice);
			if(choice==1)
			{
				location[1][num1][num2]='@';
				location[0][num1][num2]='O';
				*stage=0;
			}
			else if(choice==2)
			{
				printf("진혁이는 시공의 폭풍 속으로 빨려들어가서 사망하였습니다.\n\n");
				return 0;
			}
			else if(choice==3)
			{
				bettle_end=Battle_High_Grade(hp, gold, atk, def, item, stage, 2);
				if(bettle_end==1)
				{
					line();
					printf("진혁이는 마왕킹복이를 쓰러뜨려서 2019iot반의 평화를 가져왔습니다.\n\n---happy ending---\n\n");
					line();
					sleep(1);
					return 0;
				}
				else if(bettle_end==0)
				{
					printf("마왕에게 진 진혁이는 마왕의 넓은 마음으로 살아서 나오지만 입구에 있는 마왕의 자동차를 타고 집으로 돌아가 버려서 마왕은 집에 가지못하게 되었습니다.\n\n");
					return 0;
				}
			}
		}
	}
	else if(bettle_end==0)
	{
		line();
		printf("진혁이는 몬스터에게 격렬하게 저항하였으나 먹혔습니다.\n\n");
		line();
		sleep(1);
		return 0;
	}
}
void Event_2(int *gold, char location[][10][10], int stage, int num1, int num2)	// 홀짝게임 함수
{
	if(*gold==0)
	{
		line();
		printf("가지고있는 돈이 없어서 퇴출당합니다!\n\n");
		line();
		sleep(1);
		location[stage][num1][num2]='X';
		return;
	}
	Gambling(gold);//gameover 에 end return 받아옴,gold포인터로 받음
	if(*gold<0)
	{
		*gold=0;
	}
	location[stage][num1][num2]='X';
}
void Event_3(int *gold, int *hp, int *def, int atk[], int item[], char location[][10][10], int stage, int num1, int num2)	// 상점 함수
{
	if(*gold<=0)
	{
		line();
		printf("가지고있는 돈이 없어서 퇴출당합니다!\n\n");
		line();
		sleep(1);
	}
	store(gold, item, hp, def, atk); // choice
	location[stage][num1][num2]='$';
}

int Event_4(int *hp, int *gold, int atk[], int *def, int item[], int *stage, int num1, int num2, int random[][10][10])	// 일반몬스터 함
{
	int bettle_end;
	int random1, random2;
	bettle_end=Battle_Low_Grade(hp, gold, atk, def, item, stage);
	if(*hp<=0)
	{
		sleep(1);
		line();
		printf("진혁는 힘겨운 시련을 견디지 못하고 사망하였습니다\n\t---THE END---");
		line();
		sleep(1);
	}
	random[*stage][num1][num2] = 0;
	for(;;)
	{
		random1=rand()%10;
		random2=rand()%10;
		if(random[*stage][random1][random2] == 0) 
		{
			random[*stage][random1][random2] = 4;
			break;
		}
	}
}
int Event_5(int *gold, int *hp, int item[], int stage, int num1, int num2, char location[][10][10] ) // 슬롯머신 함
{
	location[stage][num1][num2]='X';
	if( !sm_main(gold, hp, item) || *hp<=0)
	{
		Def
		return 0;
	}
}
int Event_6(int *hp, int stage, int num1, int num2, char location[][10][10])	// 병원 함
{
	mercy();   //오프닝 메르시
	sleep(2);
	hospital(hp); //어떠한 좌표에 도달할 시 야매로 병원입장.
	location[stage][num1][num2]='X';
	if(*hp<=0)
	{	
		line();
		printf("당신은 피가 모두 소모되어 메르시의 은총을 받을 수 없습니다.\n\n피가없으면? 죽습니다.\n\n");
		line();
		sleep(1);
		return 0;
	}
}
void Event_7(int *gold, int atk[], int *def, int *atkLev, int *defLev, int *changeValue, int stage, int num1, int num2, char location[][10][10])	// 강화 함수
{
	int choice=1;
	while(choice!=0)
	{
		PrintUpgradeStatus(*gold, atk, *def, *atkLev, *defLev);	
		PrintUpgradeMenu(*atkLev, *defLev);	
		scanf("%d", &choice);
		switch(choice)
		{
			case 1:
			*changeValue = Upgrade(gold, atkLev);	
			atk[0] += *changeValue;	
			atk[1] += *changeValue;	
			printf("공격력 : %d~%d\n", atk[0], atk[1]);	
			break;
			case 2:
			*def += Upgrade(gold, defLev);	
			printf("방어력: %d\n", *def);	
			break;
			case 0:
			printf("강화를 종료합니다.\n");	
			break;
			default:
			printf("올바른 선택지를 골라주세요\n");	
			break;
		}
	}
	location[stage][num1][num2]='+';
}
int Event_8(int *hp, int *gold, int item[], int stage, int num1, int num2, char location[][10][10])	// 기억력 테스트 함
{
	int end = Trap(hp,item,gold);
	if(end==0)
	{
		line();
		printf("탈출권을 사용하였습니다. [남은 탈출권 %d개]\n\n", item[6]);
		line();
		sleep(1);
	}
	if(end==1)
	{
		line();
		printf("클리어");
		line();
		sleep(1);
	}
	if(end>=2&& end<=4)
	{
		line();
		printf("%d스테이지를 클리어하지 못하였습니다. 패널티가 주어집니다.\n\n", end+1);
		line();
		sleep(1);
	}
	if(hp<=0)
	{
		return 0;
	}
	Def;
	location[stage][num1][num2]='X';	
}
void line(void)							// 라인
{
	printf("===================================================================================================\n\n");
}

int UI(char arr[][10][10], int stage)				// 미니맵 구현
{	
	int a,b;
	if(stage==0)Blue
	else if (stage ==1) Red
	printf("\t======================================================\n");
	for(a=2; a<32; a++)				
	{
		printf("\t||");
		for(b=0; b<10; b++)
		{
			if(a%3==0)printf("  %c  ", arr[stage][(a/3)-1][b]);
			else printf("  %c  ", ' ');
		}
		printf("||");
		printf("\n");
	}
	printf("\t======================================================\n");
	Def
}
int getch(void)					// 키보드 이동키 함수
{
	int ch;
	struct termios buf;
	struct termios save;
	
	tcgetattr(0,&save);
	buf=save;
	buf.c_lflag&=~(ICANON|ECHO);
	buf.c_cc[VMIN]=1;
	buf.c_cc[VTIME]=0;
	tcsetattr(0,TCSAFLUSH,&buf);
	ch=getchar();
	tcsetattr(0,TCSAFLUSH,&save);
	
	return ch;
}

int  Gambling(int *gold) 	//홀짝 배팅금액 설정함수
{
	int slect;		//선택 변수
	int betting;		//배팅
	int end=0;
	int count=1;
	int con;
	while(1)
	{
		system("clear");
		printf("현재 소지금은 %d 입니다. \n판돈을 걸어주세요\n",*gold);
		printf("배팅 금액 >>");
		scanf("%d",&betting);
		con=getch();		//엔터만 입력시 값: 10
		printf("\n");
		if(con!=10) 		//문자 입력시 재입력
		{
			printf("잘못된 값을 입력 하였습니다.\n다시 금액을 적어주세요.\n");
			sleep(1);
			continue;
		}
		if(betting==0)		//0원 입력시 재입력
		{
			printf("판돈은 0원을 걸수 없습니다.\n디시 금액을 적어주세요.\n");
			sleep(1);
		}
		else if(betting>*gold)	//소지금 초과시 재입력
		{
			printf("판돈은 소지금을 넘을 수 없습니다.\n디시 금액을 적어주세요.\n");
			sleep(1);

		}
		else break;
		
	}

	while(1)
	{
		system("clear");
		printf("%d 라운드 배팅 금액 : %d\n",count,betting);
		EvenAndOdd(&end,betting,gold,count);//홀짝 선택,홀로그램 ,게임결과,골드변화,포인터 게임종료유무
		sleep(2);
		if(end==1)break;//게임 패 했을때 종료.
		count++;
		if(count==4)break;//3회 성공시 종료.
		printf("다음 라운드에 도전하시겠습니까?\n");
		printf("1.도전  2.중단\n   =>>");
		scanf("%d",&slect);
		if(slect==2)
		{
			end=1;
			break;
		}
	}
	
	return end;
}

void EvenAndOdd(int *End,int bet,int *gold,int c_count)
{
	int slect;
	int gamble;

	printf("홀짝을 선택 해주세요\n");
	printf("1.홀  2.짝\n");
	printf("당신의 선택은 ?>>"); 
	scanf("%d",&slect);
	for(int i=0;i<70;i++)		//빠르게 홀로그램 출력
	{
		system("clear");
		gamble=rand()%10+1;
		Print(gamble);
		usleep(50000);
	}
	for(int i=0;i<5;i++)		//조금느리게
	{
		system("clear");
		gamble=rand()%10+1;
		Print(gamble);
		usleep(300000);
	}
	for(int i=0;i<3;i++)		//느리게
	{
		system("clear");
		gamble=rand()%10+1;
		Print(gamble);
		usleep(500000);
	}
	for(int i=0;i<3;i++)		//많이 느리게
	{
		system("clear");
		gamble=rand()%10+1;
		Print(gamble);
		sleep(1);
	}
	for(int i=0;i<2;i++)		//홀로그램 끝
	{
		system("clear");
		gamble=rand()%10+1;
		Print(gamble);
		sleep(2);
	}
	gamble=rand()%10+1;		//홀짝 결정
	system("clear");
	printf("빠밤~~~\n");
	Print(gamble);			//홀로그램  출력
	if(gamble%2==0)			//짝수일때
	{
		if(slect==1)		//홀수 선택
		{
			printf("%d이 나왔습니다. 아쉽네요 짝입니다.\n",gamble);
			*End=1;	
		}
		else			//짝수선택
		{
			printf("%d이 나왔습니다.축하합니다 짝입니다.\n",gamble);
		}
	}
	else				//홀수일때
	{
		if(slect==1)		//홀수선택
		{
			printf("%d이 나왔습니다.축하합니다 홀입니다.\n",gamble);
		}
		else			//짝수선택
		{
			printf("%d이 나왔습니다.아쉽네요 홀입니다.\n",gamble);
			*End=1;
		}
	}
	if(c_count==1)			//1라운드 선택결과
	{
		if(*End==1)		//졌을때
		{
			*gold-=bet*3;
			printf("당신은 %d 골드를 잃었습니다.\n",bet*3);
		}
		else			//이겼을때
		{
			*gold+=bet*2;
			printf("당신은 %d 골드를 얻었습니다.\n",bet*2);
		}
	}
	if(c_count==2)			//2라운드 선택결과
	{
		if(*End==1)		//졌을때
		{
			*gold-=bet*2;
			*gold-=bet*10;
			printf("당신은 %d 골드를 잃었습니다.\n",bet*10);
		}
		else			//이겼을때
		{
			*gold+=bet*8;
			*gold-=bet*2;
			printf("당신은 %d 골드를 얻었습니다.\n",bet*8);
		}
	}
	if(c_count==3)			//3라운드 선택결과
	{
		if(*End==1)		//졌을때
		{
			*gold-=bet*8;
			*gold-=bet*20;
			printf("당신은 %d 골드를 잃었습니다.\n",bet*20);
		}
		else			//이겼을때
		{
			*gold+=bet*16;
			*gold-=bet*8;
			printf("당신은 %d 골드를 얻었습니다.\n",bet*16);
		}
	}

}

void Print(int g_gamble)		//홀로그램 출력
{
	switch(g_gamble)
	{
		case 1:
			printf("\t┌────────┐\n");
			printf("\t│      O │\n");
			printf("\t│      O │\n");
			printf("\t│      O │\n");
			printf("\t│      O │\n");
			printf("\t│      O │\n");
			printf("\t└────────┘\n");
			break;
		case 2:
			printf("\t┌────────┐\n");
			printf("\t│   OOOO │\n");
			printf("\t│      O │\n");
			printf("\t│   OOOO │\n");
			printf("\t│   O    │\n");
			printf("\t│   OOOO │\n");
			printf("\t└────────┘\n");
			break;
		case 3:
			printf("\t┌────────┐\n");
			printf("\t│   OOOO │\n");
			printf("\t│      O │\n");
			printf("\t│   OOOO │\n");
			printf("\t│      O │\n");
			printf("\t│   OOOO │\n");
			printf("\t└────────┘\n");
			break;
		case 4:
			printf("\t┌────────┐\n");
			printf("\t│   O O  │\n");
			printf("\t│   O O  │\n");
			printf("\t│   OOOO │\n");
			printf("\t│     O  │\n");
			printf("\t│     O  │\n");
			printf("\t└────────┘\n");
			break;
		case 5:
			printf("\t┌────────┐\n");
			printf("\t│   OOOO │\n");
			printf("\t│   O    │\n");
			printf("\t│   OOOO │\n");
			printf("\t│      O │\n");
			printf("\t│   OOOO │\n");
			printf("\t└────────┘\n");
			break;
		case 6:
			printf("\t┌────────┐\n");
			printf("\t│   O    │\n");
			printf("\t│   O    │\n");
			printf("\t│   OOOO │\n");
			printf("\t│   O  O │\n");
			printf("\t│   OOOO │\n");
			printf("\t└────────┘\n");
			break;
		case 7:
			printf("\t┌────────┐\n");
			printf("\t│   OOOO │\n");
			printf("\t│      O │\n");
			printf("\t│      O │\n");
			printf("\t│      O │\n");
			printf("\t│      O │\n");
			printf("\t└────────┘\n");
			break;
		case 8:
			printf("\t┌────────┐\n");
			printf("\t│   OOOO │\n");
			printf("\t│   O  O │\n");
			printf("\t│   OOOO │\n");
			printf("\t│   O  O │\n");
			printf("\t│   OOOO │\n");
			printf("\t└────────┘\n");
			break;
		case 9:
			printf("\t┌────────┐\n");
			printf("\t│   OOOO │\n");
			printf("\t│   O  O │\n");
			printf("\t│   OOOO │\n");
			printf("\t│      O │\n");
			printf("\t│      O │\n");
			printf("\t└────────┘\n");
			break;
		case 10:
			printf("\t┌────────┐\n");
			printf("\t│ O OOOO │\n");
			printf("\t│ O O  O │\n");
			printf("\t│ O O  O │\n");
			printf("\t│ O O  O │\n");
			printf("\t│ O OOOO │\n");
			printf("\t└────────┘\n");
			break;
	}
}

void store(int *gold, int item[], int *hp, int *def, int atk[2])		// 상점 함수
{
        int choice;
        int escape=rand()%100+1;
        for(int a=0;a<2;)
        {
        system("clear");
        line();
        printf("\t필요한게 있으면 골라보게나!\n힐링포션을 제외한 모든 품목은 하나씩밖에 가질수 없다네~\n");
        printf("\t  현재 소지 골드 : %dG\n",*gold);
        line();
        printf("0. 나가기\n1. 힐링 포션 500G \n2. 화속성 포션 1000G [1회 구매 가능]\n3. 수속성 포션 1000G [1회 구매 가능]\n4. 빛속성 포션 50,000G [최종보스전용][1회 구매 가능]\n5. 흑염룡의 눈물 10,000G [All 스텟 ++][1회 구매 가능]\n6. Event Item!! 포션 세트 2000G [힐링, 화속성, 수속성 포션 세트][1회 구매 가능]\n");
        if(escape>=70)                                  // 함정스테이지 확률 등장
        {
        printf("7. 함정 스테이지 탈출권 50,000G [최대 5개까지 구입 가능]\n");
        }
        if(*gold<=0)
        {
        	line();
        	printf("더이상 돈이 남아있지 않습니다. 필드로 돌아갑니다.\n");
        	line();
        	sleep(1);
        	break;
        }
        scanf("%d",&choice);
        switch(choice)
        {
        	case 0:
        	a+=3;
        	break;
                case 1:                                 // 힐링 포션
                if(*gold>=100)                          // 골드 -값 방지용
                {
                        printf("힐링 포션을 구매합니다.\n");
                        *gold-=500;
                        item[0]+=1;
                        break;
                }
                else
                {
                        printf("돈이 없어 사지 못합니다.\n");
                        break;
                }
                break;
                case 2:                                 // 화속성 포션
                if(*gold>=500)                          // 골드 -값 방지용
                {
                        if(item[1]==0)
                        {
                                printf("화속성 포션을 구매합니다.\n");
                                *gold-=1000;
                                item[1]+=1;
                                break;
                        }
                        else                            // 소지하지 않았을 경우
                        {
                                line();
                                printf("\t이미 소지하고 있는 아이템입니다.\n");
                                break;
                        }
                        break;
                }
                else
                {
                        printf("돈이 없어 사지 못합니다.\n");
                        break;
                }
                break;
                case 3:                                 // 수속성 포션
                if(*gold>=500)                         // 골드 -값 방지용
                {
                        if(item[2]==0)
                        {
                                printf("수속성 포션을 구매합니다.\n");
                                *gold-=1000;
                                item[2]+=1;
                                break;
                        }
                        else                            // 소지하지 않았을 경우
                        {
                                line();
                                printf("\t이미 소지하고 있는 아이템입니다.\n");
                                break;
                        }
                        break;
                }
                else
                {
                        printf("돈이 없어 사지 못합니다.\n");
                        break;
                }
                case 4:                                 // 빛속성 포션
                if(*gold>=10000)                         // 골드 -값 방지용
                {
                        if(item[3]==0)
                        {
                                printf("빛속성 포션을 구매합니다.\n");
                                *gold-=50000;
                                item[3]+=1;
                                break;
                        }
                        else                            // 소지하지 않았을 경우
                        {
                                line();
                                printf("\t이미 소지하고 있는 아이템입니다.\n");
                                break;
                        }
                        break;
                }
                else
                {
                        printf("돈이 없어 사지 못합니다.\n");
                        break;
                }
                
                case 5:                                 // 흑염룡의 눈물
                if(*gold>=10000)                         // 골드 -값 방지용
                {
                        if(item[4]==0)                  // 소지하지 않았을 경우
                        {
                                printf("크크큭... 강해지는 느낌이군...\n");
                                *gold-=2000;
                                *hp+=200;
                                *def+=50;
                                atk[0]+=100;
                                atk[1]+=100;
                                item[4]+=1;
                                break;
                        }
                        else                            // 1개 이상 소지하고 있을 경우
                        {
                                line();
                                printf("\t이미 소지하고 있는 아이템입니다.\n");
                                break;
                        }
                        break;
                }
                else
                {
                        printf("돈이 없어 사지 못합니다.\n");
                        break;
                }
                
                case 6:                                 // 포션세트
                if(*gold>=1000)                         // 골드 -값 방지용
                {
                        if(item[5]==0)                  // 소지하지 않았을 경우
                        {
                                printf("힐링 포션, 화속성 포션, 수속성 포션이 1개씩 추가됩니다!\n");
                                *gold-=2000;
                                item[0,1,2]+=1;
                                item[5]+=1;
                                break;
                        }
                        else                            // 1개 이상 소지하고 있을 경우
                        {
                                line();
                                printf("\t이미 구매했습니다.\n");
                                break;
                        }
                        break;
                }
                else
                {
                        printf("돈이 없어 사지 못합니다.\n");
                        break;
                }
                case 7:                                 // 스테이지 탈출권
                if(*gold>=1000 && escape>=70)                         // 골드 -값 방지용
                {
                        if(item[6]<=2)                  // 소지하지 않았을 경우
                        {
                                printf("스테이지 탈출권을 구입합니다.\n");
                                *gold-=50000;
                                item[6]+=1;
                                break;
                        }
                        else                            // 1개 이상 소지하고 있을 경우
                        {
                                line();
                                printf("\t이미 5개를 소지하고 있는 아이템입니다.\n");
                                break;
                        }
                        break;
                }
                else
                {
                        printf("돈이 없어 사지 못합니다.\n");
                        break;
                }
        }
        line();
                sleep(1);
        }
}

int Battle_Low_Grade (int *hp, int *gold, int atk[], int *def, int item[], int *stage)
{
	char Monster_Name[4][100] = {"졸개 복이(물)", "졸개 돌복이(물)","졸개 복이(화)", "졸개 돌복이(화)"}; // 몬스터 이름
	int Monster_Atk[4] = {200, 250, 400, 500};		  // 몬스터 공격력
	int Monster_Hp[4] = {800,1300,1500,2800}; 	          // 몬스터 Hp
	int Monster_Gold[4] = {2000, 3000, 3500, 4000};	          // 몬스터가 드롭할 gold 상한								 
	int M_pick; 						  // 복이와 돌복이 둘중에 랜덤으로 픽
	int Choice;						  // 선택 변수
	int Turn = 1;						  // 턴 표시 변수
	int Phase_chk = 0;					  // 플레이어와 몬스터의 공격 차례 체크를 위한 변수
	int Def_chk = 0;					  // 플레이어가 방어를 선택했는지 체크	
	int Potion_chk = 0;					  // 속성 포션 사용여부 체크
	int cal;						  // 계산값 저장용 변수
	int Itemuse;
	
	if(*stage == 0) M_pick = rand()%2;			  // 스테이지 1인 경우 물속성 복이 또는 돌복이가 선택됨
	else if (*stage == 1) M_pick = rand()%2+2;		  // 스테이지 2인 경우 화속성 복이 또는 돌복이가 선택됨
	
	for(int i= 0; i< 4; i++) // 몬스터 출현 멘트 깜박임
	{
		system("clear");
		gotoxy(10, 10);
		printf("%s 가 출현했다!", Monster_Name[M_pick]);
		usleep(500000);
		gotoxy(10, 10);
		printf("                   ");
		usleep(500000);
	}
	
	while(1)
	{
		if(Monster_Hp[M_pick] <= 0) 
		{
			cal = rand()%Monster_Gold[M_pick]+1;		// 1~몬스터 골드 상한까지 랜덤으로 골드를 획득
			*gold += cal;
			printf("\n진혁은 Gold %d 을 획득했다\n", cal); 
			return 1; // 몬스터 처치시 1을 리턴
		}
		if(*hp <= 0) return 0; // 플레이어 사망시 0을 리턴 
		
		Print_LG_Battle_status(hp, gold, atk, def, Monster_Name, Monster_Atk, Monster_Hp, &Turn, &M_pick, Potion_chk); // 전투 스테이터스 출력 함수 호출
			
		if(Phase_chk == 0)
		{
			switch( Choice = Battle_LG_Input() )
			{
				case 1:		
					Battle_LG_Player_Attack(hp, gold, atk, def, Monster_Name, Monster_Atk, Monster_Hp, &Turn, &M_pick, &Potion_chk); // 플레이어 공격 함수 호출
				break;
				case 2: 
					Def_chk = 1;					// 방어를 선택할 경우 방어 선택 체크 변수를 1로
					printf("진혁은 방어태세를 취했다\n");
				break;
				case 3:
					if( Itemuse = Battle_LG_Itemuse(hp, item, &Potion_chk, stage) ) // 아이템 사용 함수 호출
					{
						sleep(2);
						continue;	// 아이템을 사용하지 못한 경우 재 선택
					}  
				break;
				case 4:
					if( rand()%100 <20 ) //20%의 확률로 도망 성공
					{
						printf("진혁은 전투에서 도망쳤다\n");
						sleep(2);
						return 1; // 도망에 성공할 경우 1을 리턴
					}
					printf("도망을 시도했지만 실패했다\n");
				break;
				default :
					printf("선택을 잘못 했습니다.\n");
					continue;
				break;
			}
			sleep(2);
			Phase_chk = 1;		// 플레이어가 행동을 취한 후 몬스터 공격 가능
			continue;	
		}
		if(Phase_chk == 1) 
		{
			Phase_chk = Battle_LG_Monster_Attack(hp, gold, atk, def, Monster_Name, Monster_Atk, Monster_Hp, &Turn, &M_pick, &Def_chk, Potion_chk); // 몬스터 공격 함수 호출
			sleep(2);
		}
		Turn++;	//몬스터 공격 이후 턴 증가
	}
}

void Battle_LG_Player_Attack(int *hp, int *gold, int *atk, int *def, char Mname[][100], int Matk[], int MHp[], int *Turn, int *M_pick, int *Potion_chk)
{
	int cal = rand()%(atk[1]-atk[0]+1) + atk[0];	// 유저 공격 데미지 계산
	int added_damage = 0;				// 속성 추가데미지 변수
	
	if(*Potion_chk) added_damage = cal*0.2; 	// 해당 스테이지에 적합한 포션을 사용한 경우 계산 된 유저 공격 데미지에 20%만큼 추가 데미지로 산정
	
	MHp[*M_pick] -= cal + added_damage;		// 유저 공격 데미지 + 속성 추가 데미지만큼 몬스터 체력 감소
	
	// 몬스터 피격 깜박임
	if(*M_pick == 0) soldier1_itf(2);
	else if(*M_pick == 1) soldier2_itf(2);
	else if(*M_pick == 2) soldier3_itf(2);
	else if(*M_pick == 3) soldier4_itf(2);
	gotoxy(1, 21);
	
	printf("진혁이 공격했다. %s 는 %d", Mname[*M_pick], cal);
	printf(" (속성 추가 데미지 + %d ) 의 데미지를 입었다.\n", added_damage); 
	
}

int Battle_LG_Monster_Attack(int *hp, int *gold, int *atk, int *def, char Mname[][100], int Matk[], int MHp[], int *Turn, int *M_pick, int *Def_chk, int Potion_chk)
{
	int cal = rand()%(Matk[*M_pick]-49)+50;		//몬스터 공격 데미지 계산
	
	if(*Turn%3 == 0 ) // 3턴 마다 차징
	{
		printf("\n%s 는 깊게 숨을 들이쉬어 힘을 모았다\n", Mname[*M_pick]); 
		return 0;
	}
	else if(*Turn%4 == 0 ) cal = cal*3; // 4턴에 계산 된 데미지의 3배 
	
	if(*Def_chk == 1) // 플레이어가 방어를 선택했을 경우 몬스터의 데미지 90% 감소
	{ 
		cal = cal * 0.1; 
		Def_chk = 0; 
	} 
	if( cal - *def <= 0 ) cal = 1;		// 몬스터 공격 데미지가 유저의 방어력보다 낮을 경우 데미지를 1로 고정
	else cal = cal - *def;			// 몬스터 공격 데미지가 유저의 방어력보다 낮지 않을 경우 유저 방어력 만큼 감산 
	
	*hp -= cal;				
	
	// 플레이어 피격 깜박임
	player_itf(2, Potion_chk);
	gotoxy(1, 21);
	
	printf("\n%s 가 %s했다. 진혁은 %d의 데미지를 입었다\n", Mname[*M_pick], *Turn%4 ? "공격":"힘차게 공격", cal);
	
	return 0;
}

void Print_LG_Battle_status(int *hp, int *gold, int *atk, int *def, char Mname[][100], int *Matk, int *MHp, int *Turn, int *M_pick, int Potion_chk)
{
	system("clear");
	printf("\n%s\nHp : %4d\t   공격력 : %3d\n\n", Mname[*M_pick], MHp[*M_pick], Matk[*M_pick]);
	printf("=================================================================================");
	player_itf(1, Potion_chk);					// 유저 그래픽 프린트
	if(*M_pick == 0) soldier1_itf(1);		// 몬스터 그래픽 프린트
	else if(*M_pick == 1) soldier2_itf(1);
	else if(*M_pick == 2) soldier3_itf(1);
	else if(*M_pick == 3) soldier4_itf(1);
	gotoxy(0, 13);
	printf("=================================================================================\n");
	
	printf("Turn : %2d\n진혁의 Hp : %4d\t 진혁의 공격력 : %3d ~ %3d\t  진혁의 방어력 : %3d\n\n", *Turn, *hp, atk[0], atk[1], *def);
	printf("┌────────────────────────────────────────────────┐\n");
	printf("│1. 공격     2. 방어	3. 아이템 사용   4. 도망 │\n");
	printf("└────────────────────────────────────────────────┘\n");
}

int Battle_LG_Itemuse(int *Hp, int *item, int *Potion_chk, int *stage)
{
	int Choice;
	int Usechk = 0;
	
	Print_Battle_Itemlist(item);	// 아이템 리스트 프린트 함수 호출
	Choice = Battle_LG_Input();

	if( item[Choice-1] == 0) // 선택한 아이템을 소지 하고 있지 않은 경우
	{
		printf("해당 아이템을 소지하고 있지 않습니다\n");
		return 1;
	}
	else
	{
		if( Choice == 1 || (Choice == 2 && *stage ==0) ||  (Choice == 3 && *stage ==1) ) Usechk =1; // 아이템 사용 여부 체크
		if( Choice == 1 ) *Hp = 1000;  // 힐링포션을 사용한 경우 체력 회복
		else if (Choice == 2 && *stage ==1) *Potion_chk = 1;
		else if (Choice == 3 && *stage ==2) *Potion_chk = 2; // 스테이지에 맞는 강화포션을 사용한 경우 
		else if( Choice > 4 || Choice <= 0 ) printf("선택을 잘못 했습니다.\n");
	}
	
	if (Usechk == 1 && Choice == 1) printf("힐링 포션을 사용하여 체력을 회복했다.\n");  
	else if (Usechk == 1 && (Choice >= 2 && Choice <=3 ) ) printf("%s 을 사용했다.\n", *stage == 1 ? "화속성 강화 포션" : "물속성 강화 포션" ); 
	else if (Usechk == 0 && (Choice >= 2 && Choice <=4 ) ) printf("현재 스테이지에서는 사용할 수 없다.\n");
	
	if( item[Choice-1] != 0 && (Choice >= 1 && Choice <=4) && Usechk == 1 ) item[Choice-1]--;  // 사용한 아이템의 소지 갯수 감산	
	if( Usechk == 1 && (Choice >= 1 && Choice <= 4) ) return 0;
	else return 1;
	
}

void Print_Battle_Itemlist(int *item)
{
	printf("\n");
	printf("┌───────────────────────────────────────────────────────────────────────────────────────────────────────────┐\n");
	printf("│1. 힐링포션(%d)     2. 화속성 강화포션(%d)	3. 물속성 강화포션(%d)      4. 빛속성 강화포션(%d)  	    │\n", item[0], item[1], item[2], item[3] );
	printf("└───────────────────────────────────────────────────────────────────────────────────────────────────────────┘\n");
}

void soldier1_itf(int mode)//졸병1
{
	int x=30;
	int y=8;
	Blue
	if(mode==1)//일반모습
	{
		gotoxy(x,y);
		printf("   ^@@^");
		gotoxy(x,y+1);
		printf(">>[@⊙ @]<<");
		gotoxy(x,y+2);
		printf("  %c_@@_/",92);
		gotoxy(1,1);
	}
	else //피격모습
	{
		for(int q=0;q<5;q++)
		{
			gotoxy(x,y);
			printf("   ^@@^");
			gotoxy(x,y+1);
			printf(">>[@＊@]<<");
			gotoxy(x,y+2);
			printf("  %c_@@_/",92);
			gotoxy(1,1);
			
			delay_ms(100);
			
			gotoxy(x,y+0);
			printf("            ");
			gotoxy(x,y+1);
			printf("            ");
			gotoxy(x,y+2);
			printf("            ");
			gotoxy(1,1);
			
			delay_ms(100);
		}
		soldier1_itf(1);
	}
	Def
}

void soldier2_itf(int mode)//졸병2
{
	int x=30;
	int y=8;
	
	Blue
	if(mode==1)//일반모습
	{
		gotoxy(x,y);
		printf("   *@@*");
		gotoxy(x,y+1);
		printf(">>[@⊙ @]<<");
		gotoxy(x,y+2);
		printf("  %c_@@_/",92);
		gotoxy(1,1);
	}
	else //피격모습
	{
		for(int q=0;q<5;q++)
		{
			gotoxy(x,y);
			printf("   *@@*");
			gotoxy(x,y+1);
			printf(">>[@＊@]<<");
			gotoxy(x,y+2);
			printf("  %c_@@_/",92);
			gotoxy(1,1);
			
			delay_ms(100);
			
			gotoxy(x,y);
			printf("            ");
			gotoxy(x,y+1);
			printf("            ");
			gotoxy(x,y+2);
			printf("            ");
			gotoxy(1,1);
			
			delay_ms(100);
		}
		soldier2_itf(1);
	}
	Def
}
void soldier3_itf(int mode)//졸병3
{
	int x=30;
	int y=8;
	
	Red
	if(mode==1)//일반모습
	{
		gotoxy(x,y);
		printf("   ^@@^");
		gotoxy(x,y+1);
		printf(">>[@⊙ @]<<");
		gotoxy(x,y+2);
		printf("  %c_@@_/",92);
		gotoxy(1,1);
	}
	else //피격모습
	{
		for(int q=0;q<5;q++)
		{
			gotoxy(x,y);
			printf("   ^@@^");
			gotoxy(x,y+1);
			printf(">>[@＊@]<<");
			gotoxy(x,y+2);
			printf("  %c_@@_/",92);
			gotoxy(1,1);
			
			delay_ms(100);
			
			gotoxy(x,y+0);
			printf("            ");
			gotoxy(x,y+1);
			printf("            ");
			gotoxy(x,y+2);
			printf("            ");
			gotoxy(1,1);
			
			delay_ms(100);
		}
		soldier3_itf(1);
	}
	Def
}
void soldier4_itf(int mode)//졸병4
{
	int x=30;
	int y=8;
	
	Red
	if(mode==1)//일반모습
	{
		gotoxy(x,y);
		printf("   ^@@^");
		gotoxy(x,y+1);
		printf(">>[@⊙ @]<<");
		gotoxy(x,y+2);
		printf("  %c_@@_/",92);
		gotoxy(1,1);
	}
	else //피격모습
	{
		for(int q=0;q<5;q++)
		{
			gotoxy(x,y);
			printf("   ^@@^");
			gotoxy(x,y+1);
			printf(">>[@＊@]<<");
			gotoxy(x,y+2);
			printf("  %c_@@_/",92);
			gotoxy(1,1);
			
			delay_ms(100);
			
			gotoxy(x,y+0);
			printf("            ");
			gotoxy(x,y+1);
			printf("            ");
			gotoxy(x,y+2);
			printf("            ");
			gotoxy(1,1);
			
			delay_ms(100);
		}
		soldier4_itf(1);
	}
	Def
}

void player_itf(int mode, int Potion_chk)//플레이어
{
	int x=6;
	int y=8;
	
	if(mode==1)//일반모습
	{
		gotoxy(x,y);
		printf("O");
		gotoxy(x+2,y);
		if(Potion_chk == 1) Red
		else if (Potion_chk == 2) Blue
		else if (Potion_chk == 3) YELLOW
		printf("/");
		Def
		gotoxy(x,y+1);
		printf("T");
		gotoxy(x,y+2);
		printf("^");
		gotoxy(1,1);
	}
	else//피격 모습
	{
		for(int q=0;q<5;q++)
		{
			gotoxy(x,y);
			printf("O");
			gotoxy(x,y+1);
			printf("T");
			gotoxy(x,y+2);
			printf("^");
			gotoxy(1,1);
			
			delay_ms(100);
			
			gotoxy(x,y);
			printf(" ");
			gotoxy(x,y+1);
			printf(" ");
			gotoxy(x,y+2);
			printf(" ");
			gotoxy(1,1);
			
			delay_ms(100);
		}
		player_itf(1, Potion_chk);
	}
}

int Battle_High_Grade(int *hp,int *gold,int atk[],int *def,int item[],int *stage,int monster)
{
	char Monster_Name[4][100]={"데빌 킹복이(무)","마왕 킹복이(악)","데빌 킹복이(무)","마왕 킹복이(악)"};
	int Monster_Atk[4] = {400, 700, 650, 800};			//몬스터 공격력
	int Monster_Hp[4] = {2000,5500,3000,5000};         		//몬스터 체력
	int Monster_Gold[4] = {3000, 10000, 5000, 10000};	  	//몬스터 골드드랍 								 
	int M_pick=monster-1; 						//몬스터 배열좌표
	int Choice;						 	//선택문 변수
	int Turn = 1;						 	//턴 카운트
	int Phase_chk = 0;					 	//상대턴 마이턴
	int Def_chk = 0;					 	//방어 on/off
	int cal;							//랜덤 저장
	int Potion_chk = 0;						//포션 변수
	
	if(*stage==1) M_pick+=2;					//층수에 따른 몬스터 뱐화
	
	system("clear");
	for(int q=0;q<3;q++)//몬스터 출현 이벤트
	{
		gotoxy(10,10);
		printf("%s가 나타났다.",Monster_Name[M_pick]);
		gotoxy(1,1);
		delay_ms(500);
		
		gotoxy(10,10);
		printf("                           ");
		gotoxy(1,1);
		delay_ms(500);
	}
	for(;;)
	{
		if(Monster_Hp[M_pick] <= 0) //몬스터 사망
		{
			cal = rand()%Monster_Gold[M_pick]+1;//골드 랜덤
			*gold += cal;//골드 누적
			printf("진혁은 Gold %d 을 획득했다\n", cal); //출력
			return 1;//몬스터 사망 return 1;
		}
		if(*hp <= 0) return 0;//플레이어 사망 return 0;
		
		Print_HG_Battle_status(hp, gold, atk, def, Monster_Name, Monster_Atk, Monster_Hp, &Turn, &M_pick,stage, Potion_chk);//배틀 화면 출력
		
		if(Phase_chk==0)//플레이어 턴
		{
			switch(Choice=Battle_LG_Input())//입력값 저장
			{
				case 1://공격 선택
					Battle_HG_Player_Attack(hp, gold, atk, def, Monster_Name, Monster_Atk, Monster_Hp, &Turn, &M_pick, &Potion_chk,stage);
				
				break;
			
				case 2://방어 선택
					Def_chk=1;
					printf("진혁은 방어태세를 취했다\n");
				break;
			
				case 3://아이템 선택
					Choice=Battle_HG_Itemuse(hp, item, &Potion_chk, stage,monster);
					if(Choice)
					{
						sleep(2);
						continue;
					}
				break;
			
				case 4://도망 선택
					if(rand()%100<20) 
					{
						printf("진혁은 전투에서 도망쳤다\n");
						sleep(2);
						return 2; // 도망에 성공할 경우 1을 리턴
					}
					printf("도망을 시도했지만 실패했다\n");
				break;
			
				default://그외
					printf("선택을 잘못 했습니다.\n");
					continue;
				break;
			}
			sleep(2);
			Phase_chk = 1;
			continue;
		}
		else//몬스터 턴
		{
			Phase_chk = Battle_HG_Monster_Attack(hp, gold, atk, def, Monster_Name, Monster_Atk, Monster_Hp, &Turn, &M_pick, &Def_chk, Potion_chk);	
			sleep(2);
		}
		Turn++;
	}
}

//플레이어 공격
void Battle_HG_Player_Attack(int *hp, int *gold, int *Atk, int *def, char Mname[][100], int MAtk[], int MHp[], int *Turn, int *M_pick, int *Potion_chk,int *stage)
{
	int cal = rand()%(Atk[1]-Atk[0]+1) + Atk[0];//공격랜덤 저장
	int added_damage = 0;
	
	if(*Potion_chk) added_damage = cal*0.2; //속성데미지 20%
	
	MHp[*M_pick] -= cal + added_damage;//공격
	
	if(*M_pick%2 == 0) md_boss_itf(2,stage);//중간보스
	else if(*M_pick%2 == 1) boss_itf(2);//최종보스
	gotoxy(1, 21);
	
	printf("진혁이 공격했다. %s 는 %d", Mname[*M_pick], cal);//출력
	printf(" (속성 추가 데미지 + %d ) 의 데미지를 입었다.\n", added_damage);
	
}

//몬스터 공격
int Battle_HG_Monster_Attack(int *hp, int *gold, int *Atk, int *def, char Mname[][100], int MAtk[], int MHp[], int *Turn, int *M_pick, int *Def_chk, int Potion_chk)
{
	int cal = rand()%(MAtk[*M_pick]-49)+50;//공격력 랜덤 저장
	
	if(*Turn%3 == 0 ) // 3턴 마다 차징
	{
		printf("\n%s 는 깊게 숨을 들이쉬어 힘을 모았다\n", Mname[*M_pick]); 
		return 0;
	}
	else if(*Turn%4 == 0 ) cal = cal*3; // 4턴에 계산 된 데미지의 3배 
	
	if(*Def_chk == 1) // 플레이어가 방어를 선택했을 경우 몬스터의 데미지 90% 감소
	{ 
		cal = cal * 0.1; //90%감소
		*Def_chk = 0; //방어해제
	} 
	if( cal - *def <= 0 ) cal = 1;//최소데미지 1
	else cal = cal -*def;
	
	*hp -= cal;
	
	player_itf(2, Potion_chk);//플레이어
	gotoxy(1, 21);
	
	//출력
	printf("\n%s 가 %s했다. 진혁은 %d의 데미지를 입었다\n", Mname[*M_pick], *Turn%4 ? "공격":"힘차게 공격", cal);
	
	return 0;
}

void boss_itf(int mode)//보스 캐릭
{
	int x=30;//가로
	int y=6;//세로
	PURPLE
	if(mode==1)//일반모습
	{
		gotoxy(x,y);
		printf("   /%c   /%c   	",92,92);
		gotoxy(x,y+1);
		printf(" _//%c%c_//%c%c_",92,92,92,92);
		gotoxy(x,y+2);
		printf("/           %c	",92);
		gotoxy(x,y+3);
		printf("(   O   O   )	");
		gotoxy(x,y+4);
		printf(" %c >     < /	",92);
		gotoxy(x,y+5);
		printf("  %c___X___/	",92);
		gotoxy(1,1);
	}
	else//피격모습
	{
		for(int q=0;q<3;q++)
		{
			gotoxy(x,y);
			printf("   /%c   /%c   	",92,92);
			gotoxy(x,y+1);
			printf(" _//%c%c_//%c%c_",92,92,92,92);
			gotoxy(x,y+2);
			printf("/           %c	",92);
			gotoxy(x,y+3);
			printf("(   X   X   )	");
			gotoxy(x,y+4);
			printf(" %c >     < /	",92);
			gotoxy(x,y+5);
			printf("  %c___X___/	",92);
			gotoxy(1,1);
			
			delay_ms(300);
			
			gotoxy(x,y);
			printf("                          ");
			gotoxy(x,y+1);
			printf("                          ");
			gotoxy(x,y+2);
			printf("                          ");
			gotoxy(x,y+3);
			printf("                          ");
			gotoxy(x,y+4);
			printf("                          ");
			gotoxy(x,y+5);
			printf("                          ");
			gotoxy(1,1);
			
			delay_ms(300);
		}
		boss_itf(1);
	}
	Def
}

void md_boss_itf(int mode,int *stage)//중간 보스 캐릭
{
	int x=30;
	int y=7;
	
	//if(*stage==1) Blue;
	//else Red;
	
	if(mode==1)//일반 모습
	{
		gotoxy(x,y);
		printf("      <⊙ >");
		gotoxy(x,y+1);
		printf("      -[]-- ▲");
		gotoxy(x,y+2);
		printf(" ====|   ★ |■");
		gotoxy(x,y+3);
		printf("      ------");
		gotoxy(x,y+4);
		printf("   /=========%c",92);
		gotoxy(x,y+5);
		printf("   %c=========/",92);
		gotoxy(1,1);
	}
	else//피격 모습
	{
		for(int q=0;q<3;q++)
		{
			gotoxy(x,y);
			printf("      <＊>");
			gotoxy(x,y+1);
			printf("      -[]-- ▲");
			gotoxy(x,y+2);
			printf(" ====|   ★ |■");
			gotoxy(x,y+3);
			printf("      ------");
			gotoxy(x,y+4);
			printf("   /=========%c",92);
			gotoxy(x,y+5);
			printf("   %c=========/",92);
			gotoxy(1,1);
			
			delay_ms(300);
			
			gotoxy(x,y);
			printf("                   ");
			gotoxy(x,y+1);
			printf("                   ");
			gotoxy(x,y+2);
			printf("                   ");
			gotoxy(x,y+3);
			printf("                   ");
			gotoxy(x,y+4);
			printf("                   ");
			gotoxy(x,y+5);
			printf("                   ");
			gotoxy(1,1);
			
			delay_ms(300);
		}
		md_boss_itf(1,stage);
	}
	//Def;
}

//아이템 사용
int Battle_HG_Itemuse(int *Hp, int *item, int *Potion_chk, int *stage,int monster)
{
	int Choice;
	
	Print_Battle_Itemlist(item);//아이템 출력
	
	Choice = Battle_LG_Input();//입력값 저장
	
	if(Choice<1||Choice>4) //범위 이탈
	{
		printf("선택을 잘못 했습니다.\n");
		return 1;//실패시 return 1;
	}
	else if(item[Choice-1] ==0 ) //재고가 없을시
	{
		printf("해당 아이템을 소지하고 있지 않습니다\n");
		return 1;//실패시 return 1;
	}
	else
	{
		switch(Choice)
		{
			case 1:
				if(*Hp>=1000) printf("이미 최대체력 입니다.\n");
				else
				{
					printf("힐링 포션을 사용하여 체력을 회복했다.\n");
					*Hp  = 1000;
					item[Choice-1]--;
				}
			break;
			case 2:
				if(*stage == 0) 
				{
					printf("화속성 강화포션을 사용했다.\n");
					*Potion_chk = 1;
					item[Choice-1]--;
				}
				else printf("현재 스테이지에서는 사용할 수 없다\n");
			break;
			case 3:
				if(*stage == 1) 
				{
					printf("물속성 강화포션을 사용했다.\n");
					*Potion_chk = 2;
					item[Choice-1]--;
				}
				else printf("현재 스테이지에서는 사용할 수 없다\n");
			break;
			case 4:
				if(monster==2)
				{
					printf("빛속성 강화포션을 사용했다.\n");
					*Potion_chk = 3;
					item[Choice-1]--;
				}
				else printf("현재 스테이지에서는 사용할 수 없다\n");
			break;
		}
	}
	
}

//배틀 화면 출력
void Print_HG_Battle_status(int *hp, int *gold, int *Atk, int *def, char Mname[][100], int *MAtk, int *MHp, int *Turn, int *M_pick,int *stage, int Potion_chk)
{
	system("clear");//화면 클리어
	printf("\n%s\nHp : %4d\t   공격력 : %3d\n\n", Mname[*M_pick], MHp[*M_pick], MAtk[*M_pick]); //몬스터 스탯 출력
	printf("=================================================================================");
	player_itf(1, Potion_chk);
	if(*M_pick%2 == 0) md_boss_itf(1,stage);////////////////////
	else if(*M_pick%2 == 1) boss_itf(1);//////////////
	gotoxy(0, 13);
	printf("=================================================================================\n");
	
	printf("Turn : %2d\n진혁의 Hp : %4d\t 진혁의 공격력 : %3d ~ %3d\t  진혁의 방어력 : %3d\n\n", *Turn, *hp, Atk[0], Atk[1], *def);//내 스탯 출력
	printf("┌────────────────────────────────────────────────┐\n");
	printf("│1. 공격     2. 방어	3. 아이템 사용   4. 도망 │\n");
	printf("└────────────────────────────────────────────────┘\n");
}

int Battle_LG_Input() 
{
    char choicebuffer[10]={'\0',};
    char enter;    
    while(1)
    { 
        printf(">> ");
        scanf("%s%c", choicebuffer, &enter);
        if(choicebuffer[0] >=48 && choicebuffer[0] <=57) return choicebuffer[0]-48;
        else printf("다시 입력하세요");
    }
}

void delay_ms(int num)//지연시간 1/1000초
{
	usleep(num*1000);
}

void gotoxy(int x, int y)//커서 옮기기
{
     printf("\033[%d;%df",y,x);
     fflush(stdout);
}

int sm_main(int *gold, int *hp, int item[7]) // 슬롯머신 메인 함수
{
	int number[3]; // 슬롯 머신 숫자 랜덤 값 저장용 배열
	int i; // for
	int out; // 반환값 저장 변수

	Red; // 출력 글자색(붉은색)

	system("clear"); // 화면 비우기

	printf("\n==[슬롯]=================================\n");
	printf(" 내 몸의 같은 숫자가 네 유일한 빛이다...\n");
	printf(" 골드와 목숨을 걸어라...\n");
	printf("=========================================\n");
	printf("\n        ====< 0 >=======< 0 >====\n");
	printf("         WWWWWWWVWWWWWWWVWWWWWWW \n");
	printf("\n\n            .<D>. .<I>. .<E>.\n");
	printf("         MMMMMMMNMMMMMMMNMMMMMMM \n");
	printf("        =========================\n");
	printf("        |<[5][0][0][g][0][L][d]>|\n");
	printf("        =========================\n");
	printf("\n==[진혁]=================================\n");
	if(*hp<=0)("GIVE ME YOUR SOUL..\n");
	else 
	{
		printf("               HP   : %d\n", *hp); // 플레이어 체력 출력
		printf("               GOLD : %d\n", *gold); // 플레이어 골드 출력
	}
	printf("=========================================\n>> Enter... ");

	sm_enter(); // 슬롯머신 엔터 함수 실행

	if(*gold<=0) // 골드가 0원 이하일 때
	{
		*gold=0; // 골드 0으로 초기화
		if(item[6]==1) // 탈출권 소지 시
		{
			printf("탈출권으로 꺼져라...\n");
			item[6]=0; // 탈출권 0으로 초기화
			out=1; // 반환값 0 초기화
			sleep(2); // 2초 딜레이
			return out; // 반환값 반환
		}
	}

	*gold-=500; // 골드 500 감산 
	if(*gold<=0) *gold=0;
	for(i=0;i<=2;i++) // 3회 반복
	{
		number[i]=rand()%9; // 0~9 랜덤 숫자 배열 저장
	}

	sm_effect(hp, gold); // 슬롯머신 숫자 변경 연출 함수 실행

	system("clear");
	printf("\n\n\n\n\n\n\n\n        ====< 0 >=======< 0 >====\n");
	printf("         WWWWWWWVWWWWWWWVWWWWWWW \n");
	printf("            .<%d>. .<%d>. .<%d>.\n",number[0], number[1], number[2]); // 저장된 배열값 출력
	printf("         MMMMMMMNMMMMMMMNMMMMMMM \n");
	printf("        =========================\n");
	printf("        |<[5][0][0][g][0][L][d]>|\n");
	printf("        =========================\n");
	printf("\n==[진혁]=================================\n");
	if(*hp<=0)("GIVE ME YOUR SOUL..\n"); // egg
	else 
	{
		printf("               HP   : %d\n", *hp); // 플레이어 체력 출력
		printf("               GOLD : %d\n", *gold); // 플레이어 골드 출력
	}
	printf("=========================================\n");
	
	sleep(3);

	if(number[0]==number[1]&&number[0]==number[2]&&number[1]==number[2]) // 저장된 배열값이 모두 같을 경우
	{
		Blue; // 출력 글자 파란색
		printf("\n\nYOU ESCAPE\n"); // 승리 출력문
		Def; // 출력 글자색 복구
		out=1; // 반환값 1 초기화
		return out; // 반환값 반환
	}
	else
	{
		if(*hp==500) printf("\n\n앞이 안보입니다! 들리는 건 슬롯의 웃음 소리...\n"); // 체력이 500일 때 출력
		if(*hp==100) printf("\n\n다리에 힘이 풀려 주저 앉았습니다! 움직일 수 있는 건 슬롯의 레버 뿐...\n"); // 체력이 100일 때 출력
		if(*gold<=0&&*hp>0) // 골드가 0 이하고 체력이 0이상일 때 
		{
				*hp-=200; // 체력 200 감산
				if(hp<=0) hp=0; // 체력이 0이하일 때 체력 0 초기화
				printf("\n\n피를 다오... [-200 HP]\n");
				sleep(1);
		}
		else if(*gold==0&&*hp==0) // 골드가 0이고 체력도 0일 때
		{
				printf("\n\nYOU DIED\n"); // 사망 출력문
				sleep(2);
				out=0; // 반환값 0 초기화
				return out; // 반환값 반환
		}
			printf("다시...\n");
			sleep(3);
			sm_main(gold, hp, item); // 슬롯머신 메인 함수 실행
	}
}

void sm_effect(int *hp, int *gold) // 슬롯머신 숫자 변경 연출 함수
{
	char num[10]={'1', '3', '2', '4', '5', '6', '7', '3', '2', '1'}; // 연출 숫자 배열
	int i;
	int j=0;

	for(i=0;i<=20;i++)
	{
		printf("\n\n\n\n\n\n        ====< 0 >=======< 0 >====\n");
		printf("         WWWWWWWVWWWWWWWVWWWWWWW \n");
		printf("\n\n            .<%c>. .<%c>. .<%c>.\n", num[j], num[j+1], num[j-1]); // 연출 숫자 배열 출력		
		printf("         MMMMMMMNMMMMMMMNMMMMMMM \n");
		printf("        =========================\n");
		printf("        |<[5][0][0][g][0][L][d]>|\n");
		printf("        =========================\n");
		printf("\n==[진혁]=================================\n");
		if(*hp<=0)("GIVE ME YOUR SOUL..\n");
		else 
		{
			printf("               HP   : %d\n", *hp); // 플레이어 체력 출력
		printf("               GOLD : %d\n", *gold); // 플레이어 골드 출력
		}
		printf("=========================================\n");
		usleep(35000);
		j++;
		if(j>10) j=0; // j가 10초과일 때 j를 0 초기화
		system("clear");
	}
}

void sm_enter(void)
{
	char en;

	scanf("%c", &en);
	system("clear");
}

int Trap(int *hp,int item[],int *gold)
{
	int floor=1;	// 스테이지
	int clear;	// 스테이지 클리어
	int run;	// 스테이지 중간에 탈출하기 위한 선택 변수
	char escape[5];	// 스테이지 중간에 탈출하기 위한 선택 변수(문자입력 yes)
	char yeschk[6][10]={"Yes","YES","y","Y","yes"};
	
	system("clear");
	if (item[6]==1)		// 함정 탈출권이 있을 때
	{
		if(Trap_escape()==1) //	함정 탈출권을 사용하면 함정탈출권 소지를 없애고 탈출
		{
			item[6]=0;
			return 0;
		}	
	}
	Enter();		// 엔터키를 누르면 넘어 가도록함
					
	for(int i=0;i<5;i++) {		// 인트로 색깔이 변경되면서 깜빡이면서 넘어가도록함
		system("clear");
		usleep(500000);
		switch (i)
		{
			case 0 : Red; break;
			case 1 : Blue; break;
			case 2 : GREEN; break;
			case 3 : Def; break;
			case 4 : Red; break;
		}
		Trap_Intro();		
		usleep(500000);
	}	
//	Def; 
	system("clear");
	
	Enter();
	system("clear");
	while(1)		// 스테이지가 계속 진행되도록 반복함
	{
	clear=Trap_Stage(&floor);	// 스테이지 클리어시 클리어란 변수에 1변환

	if(floor==3 && clear==0)	// 3스테이지 실패시 탈출할 수 있도록 함
	{
	printf("====================================================================================================\n\n\n\n\n");
		printf("\t\t\t  ㅇ 탈출하시겠습니까?...\n\n\n"); usleep(500000);
		printf("\t\t\t  ㅇ 탈출하면 체력과 골드를 상당부분 잃어버립니다.\n\n\n"); usleep(500000);
		printf("\t\t\t     Yes  |  No\n\n");
		printf("====================================================================================================\n\n\n");
		scanf("%s",escape);

		for(int i=0;i<5;i++){
			if(strcmp(escape,yeschk[i])==0) {
			*hp-=(*hp*0.4);
			*gold-=(*gold*0.4);
			return 2;
			}
		}
	}
	else if(floor==4&&clear==0)	// 4스테이지 실패시 탈출할 수 있도록 함
	{
	printf("====================================================================================================\n\n\n\n\n");
	printf("\t\t\t  ㅇ 4스테이지를 클리어 하지 못했네요... \n\n"); usleep(500000);
	printf("\t\t\t  ㅇ 4스테이지는 탈출할 수 있습니다...\n\n"); usleep(500000);
	printf("\t\t\t  ㅇ 5스테이지 클리어시 큰 보상이 주어집니다.\n\n"); usleep(500000);
GRAY;	printf("\t\t\t  ㅁ 클리어 실패시 패널티가 있습니다.\n\n"); usleep(500000); Red;
	printf("\t\t\t  ㅇ 선택하세요 \n\n"); usleep(500000);
	printf("\t\t\t\t  1. 재도전  2. 탈출한다 \n\n");
	printf("====================================================================================================\n\n\n");
	scanf("\t\t\t %d",&run);

		if (run==2) 
		{
		*hp-=(*hp*0.8);
		*gold-=(*gold*0.8);
		return 3; 
		}
	}
	
	else if(floor==5&&clear==0)	// 5스테이지 실패시 탈출할 수 있도록 함
	{
	printf("====================================================================================================\n\n\n\n\n");
	printf("\t\t\t  ㅇ 5스테이지를 탈출하면 패널티가 주어집니다...\n\n"); usleep(500000);
	printf("\t\t\t  ㅇ 선택하세요 \n\n"); usleep(500000);
	printf("\t\t\t   Yes  |  No\n\n");
	printf("====================================================================================================\n\n\n");
	scanf("%s",escape);
		for(int i=0;i<5;i++)
		{
			if(strcmp(escape,yeschk[i])==0)
			{
				*hp=1;
				*gold=1;
				return 4;
			}
		}
	}
	else if(floor==5&&clear==1)	// 5스테이지 성공시 
	{
	printf("\t\t\t  ㅇ 5스테이지 클리어\n\n"); usleep(500000);
	printf("\t\t\t  ㅇ 5스테이지 클리어 보상 골드 + 30000\n\n"); usleep(500000);
	*gold+=30000;
	return 1;
	} 	
	if(clear==1)	// 스테이지 성공시 스테이지가 다음으로 넘어가도록 
	floor++;
	Enter();
	}	
	return 0;
}

void Trap_Intro(void)	// 기억력 테스트 인트로 함수
{
	printf("====================================================================================================\n\n\n\n\n\n");
	printf("\t\t\t\t      ! ! ! 함 정 발 동 ! ! !\n\n\n");
	printf("\t\t\t\t   ! ! ! 기 억 력  테 스 트 ! ! !\n\n\n\n");
	printf("====================================================================================================\n");
}

int Trap_escape(void)	// 함정 탈출권 사용할지에 대한 함
{
	char trapesc[5];
	char yeschk[6][10]={"Yes","YES","y","Y","yes"};
	printf("====================================================================================================\n\n\n\n\n\n");
	printf("\t\t\t\t   함  정  탈  출  권 \n\n\n");
	printf("\t\t\t\t       Yes  |  No\n\n\n");
	printf("====================================================================================================\n\n\n");
	scanf("%s",trapesc);
	for(int i=0;i<5;i++){
	if(strcmp(trapesc,yeschk[i])==0)
	return 1;
	}
	return 0;
}
int Trap_Stage(int *floor)	
// 스테이지별 클리어 조건 및 생성될 난수 생성(1 스테이지 3개, 2~3 스테이지 4개, 4~5 스테이지 5개)
{		
	int fail;
	int Matrix=rand()%3000;
	int Matrix2=rand()%3000;
	int Matrix3=rand()%3000;
	int Matrix4=rand()%3000;
	int Matrix5=rand()%3000;
	switch (*floor)
	{
		case 1 :Trap_Print_Clear_Requirements(floor);
			fail=Trap_Square(Matrix,Matrix2,Matrix3,3000,3000,floor);
			break;
		case 2 :Trap_Print_Clear_Requirements(floor);
			fail=Trap_Square(Matrix,Matrix2,Matrix3,Matrix4,3000,floor);
			break;
		case 3 :Trap_Print_Clear_Requirements(floor);
			fail=Trap_Square(Matrix,Matrix2,Matrix3,Matrix4,3000,floor);
			break;
		case 4 : Trap_Print_Clear_Requirements(floor);
			fail=Trap_Square(Matrix,Matrix2,Matrix3,Matrix4,Matrix5,floor);
			break;
		case 5 :Trap_Print_Clear_Requirements(floor);
			fail=Trap_Square(Matrix,Matrix2,Matrix3,Matrix4,Matrix5,floor);
			break;
	}
	
	return fail;
}
void Trap_Print_Clear_Requirements(int *floor)
// 스테이지별 클리어 조건
{
	printf("====================================================================================================\n\n\n\n\n\n");
	
	printf("\t\t\t\t       %d 스테이지는 클리어 조건\n\n\n",*floor);
	switch (*floor)
	{
		case 1 :
		printf("\t\t\t\tㅇ 3 개의 특수 문자 중 2 개를 맞춰야합니다.\n\n\n");
		printf("\t\t\t\tㅇ 4 초의 시간이 주어집니다...\n\n");
		break;
		case 2 :
		printf("\t\t\t\tㅇ 4 개의 특수 문자 중 3 개를 맞춰야합니다.\n\n\n");
		printf("\t\t\t\tㅇ 3초의 시간이 주어집니다...\n\n");
		break;
		case 3 :
		printf("\t\t\t\tㅇ 4 개의 특수 문자 중 4 개를 맞춰야합니다.\n\n\n");
		printf("\t\t\t\tㅇ 1 초의 시간이 주어집니다...\n\n");
		break;
		case 4 :
		printf("\t\t\t\tㅇ 5 개의 특수 문자 중 4 개를 맞춰야합니다.\n\n\n");
		printf("\t\t\t\tㅇ 0.8 초의 시간이 주어집니다...\n\n");
		break;
		case 5 :
		printf("\t\t\t\tㅇ 5 개의 특수 문자 중 5 개를 맞춰야합니다.\n\n\n");
		printf("\t\t\t\tㅇ 0.5 초의 시간이 주어집니다...\n\n");
		break;
	}
	
	printf("====================================================================================================\n\n");
	Enter();
	system("clear");
}
int Trap_Square(int Matrix,int Matrix2,int Matrix3,int Matrix4,int Matrix5,int *floor)
// 30X100공간에 랜덤한 특수문자를 랜덤하게 나타내
{
	char Symbols[28]={'`','~','!','@','#','$','%','^','&','*','(',')','-','+','=','_',',','<','>','.','/','?',':',';','[',']','{','}'};
	// 특수문자들에 대한 배열
	char In_square[30][100];	// 30 x 100 공간에 따른 배열
	int fail;	// 클리어 실패시 다음 함수로 넘겨주기 위한 변수
	char Symbols_Value[5];	// 나타나게 될 5개의 대입될 특수 문자에 대한 변수
	int chk;	// 중복으로 나타나지 않도록 체크할 변
	int randnum;	// 배열 내의 특수문자를 랜덤으로 대입시켜줄 변수

	for (int i = 0; i < 5;)
	{
		chk=0;
		randnum=rand()%28;
		Symbols_Value[i]=Symbols[randnum];
		if (i>0)
		{
			for(int j=0; j<i;j++)
			{
				if(Symbols_Value[i]==Symbols_Value[j])
				{
					chk=1;
					break;
				}
				
			}
		}
		if (chk==1) continue;
		i++;
	}	

	int Matrix_row;		// 30 x 100의 공간을 행과 열로 각각 나누기 위한 변
	int Matrix_column;
	int Matrix_row2;
	int Matrix_column2;
	int Matrix_row3;
	int Matrix_column3;
	int Matrix_row4;
	int Matrix_column4;
	int Matrix_row5;
	int Matrix_column5;

	Matrix_row=Matrix/100;
	Matrix_column=Matrix%100;
	Matrix_row2=Matrix2/100;
	Matrix_column2=Matrix2%100;
	Matrix_row3=Matrix3/100;
	Matrix_column3=Matrix3%100;
	Matrix_row4=Matrix4/100;
	Matrix_column4=Matrix4%100;
	Matrix_row5=Matrix5/100;
	Matrix_column5=Matrix5%100;
	
	printf("====================================================================================================\n");	

	for(int i=0;i<30;i++)		// 30줄
	{
		for(int j=0;j<100;j++)	// 100칸
		{
			In_square[i][j]=' ';
			printf("%c",In_square[i][j]);		

			if(i==Matrix_row && j== Matrix_column) {
			In_square[Matrix_row][Matrix_column] = Symbols_Value[0];
			printf("%c",In_square[Matrix_row][Matrix_column]);
			}
			if(i==Matrix_row2 && j== Matrix_column2) {
			In_square[Matrix_row2][Matrix_column2] = Symbols_Value[1];
			printf("%c",In_square[Matrix_row2][Matrix_column2]);
			}
			if(i==Matrix_row3 && j== Matrix_column3) {
			In_square[Matrix_row3][Matrix_column3] = Symbols_Value[2];
			printf("%c",In_square[Matrix_row3][Matrix_column3]);
			}
			if(i==Matrix_row4 && j== Matrix_column4) {
			In_square[Matrix_row4][Matrix_column4] = Symbols_Value[3];
			printf("%c",In_square[Matrix_row4][Matrix_column4]);
			}
			if(i==Matrix_row5 && j== Matrix_column5) {
			In_square[Matrix_row5][Matrix_column5] = Symbols_Value[4];
			printf("%c",In_square[Matrix_row5][Matrix_column5]);
			}
			
		}
		printf("\n");
	}
	printf("====================================================================================================\n");

	fail=Trap_Answer(Symbols_Value,Symbols,floor);	// 정답이 아닐 경우 fail로 1로 반환
	if(fail==1)
	return 1;
	else 
	return 0;
}
int Trap_Answer(char Symbols_Value[],char Symbols[],int *floor)
// 정답을 도출하기 위한 함수
{
	char ch[6]={'\0',};	// 입력할 특수문자에 대한 배열
	int count=0;	// 정답의 갯수에 대한 카운트
	int i,j;	// 반복문에서 사용될 일회성 변수
	int correct;	// 스테이지별 정답체크할 갯수
	int chk;	// 입력한 특수문자가 같은지 체크할 변

	switch (*floor)	// 스테이지별 나타낼 시
	{
		case 1 : sleep(4); break;
		case 2 : sleep(3); break;
		case 3 : sleep(1); break;
		case 4 : usleep(800000); break;
		case 5 : usleep(500000); break;
	}
	system("clear");
	system("clear");
	printf("====================================================================================================\n\n\n\n\n");
	
	printf("\t\t\t    특수 문자를 모두 입력하세요. \n\n\n\n\n");
	printf("====================================================================================================\n\n\n");
	while (1)	// 입력된 특수문자가 중복될 경우 체크함
	{
		char ch_buffer[6];
		chk=0;
		printf("정답 입력 >>  ");
		scanf("\t\t\t %s",ch_buffer);
		strcpy(ch,ch_buffer);
		printf("입력한 답안 : %s\n",ch);
		for(i=0;i<5;i++)
		{
			for(j=i+1;j<6;j++)
			{
				if(ch[i]==ch[j] && ch[i]!='\0') chk=1;
			}
		}
		
		if (chk==1)
		{
			printf("중복된 값을 입력했습니다.\n");
			sleep(1);
		}
		if (chk==0) break;
	}
	
	if(*floor==1)	// 스테이지에 따른 정답체크할 갯
	correct=3;
	else if (*floor==2||*floor==3)
	correct=4;
	else if (*floor==4||*floor==5)
	correct=5;	
	
	for (int i = 0; i < correct;i++)	// 중복체크하듯이 정답인 경우만 출력 및 카운트증
	{
		for (int j = 0; j <correct ; j += 1)
		{
			if(ch[i]==Symbols_Value[j])
			{
				count++;
				printf("정답 : %c\n",ch[i]);
				sleep(1);
			}
		}
	}
	
	if (*floor==1&&count>=2) // 스테이지 및 카운트 조건 충족시 1로 리
	{
		printf("\t스테이지 1 클리어!\n\n");
		printf("5초 뒤 다음 스테이지로 넘어갑니다.\n");
		sleep(5);
		system("clear");
		return 1;
	}
	else if (*floor==2 && count>=3)
	{
		printf("\t스테이지 2 클리어!\n\n");
		printf("5초 뒤 다음 스테이지로 넘어갑니다.\n");
		sleep(5);
		system("clear");
		return 1;
	}
	else if (*floor==3 && count>=4)
	{
		printf("\t스테이지 3 클리어!\n\n");
		printf("5초 뒤 다음 스테이지로 넘어갑니다.\n");
		sleep(5);
		system("clear");
		return 1;
	}
	else if (*floor==4 && count>=4)
	{
		printf("\t스테이지 4 클리어!\n\n");
		printf("5초 뒤 다음 스테이지로 넘어갑니다.\n");
		sleep(5);
		system("clear");
		return 1;
	}
	else if (*floor==5 && count==5)
	{
		printf("\t스테이지 5 클리어!\n\n");
		printf("5초 뒤 다음 스테이지로 넘어갑니다.\n");
		sleep(5);
		system("clear");
		printf("다 깨다니 대단하시네요...\n\n");
		printf("수고요...\n");
		return 1;
	}
	else 	// 못 깰시 0으로 반환
	{

printf("====================================================================================================\n\n\n");
		printf("\t\t\t\t스테이지 : %d \n\n\n",*floor);
		printf("\t\t\t  ㅇ 함정에서 빠져나가지 못합니다.\n\n\n"); sleep(1);
		printf("\t\t\t  ㅇ 함정에서 허우적 거립니다..\n\n\n"); sleep(1);
		printf("\t\t\t  ㅇ 함정에 더 깊이 빠져듭니다...\n\n\n"); sleep(1);
		printf("\t\t\t  ㅇ 나가려면 함정과 싸워야 합니다....\n\n\n");
		printf("====================================================================================================\n");
	}
	Enter();
	Enter();
	system("clear");
	
	return 0;
}

void Enter(void)
{
	printf("Enter 키를 누르세요.\n");
	while(getchar()!='\n');
}

void PrintUpgradeStatus(int gold, int *atk, int def, int atkLev, int defLev)
{
    system("clear");
    printf("골드:%d\n", gold);
    puts("──────────────────────────────────────────────────────────────────────");
    printf("공격력(+%d강):%d~%d\n", atkLev, atk[0], atk[1]);
    PrintSword(atkLev);
    puts("──────────────────────────────────────────────────────────────────────");
    printf("방어력(+%d강):%d\n", defLev, def);
    PrintShield(defLev);
    puts("──────────────────────────────────────────────────────────────────────");
    puts("공격력 또는 방어력을 강화 할 수 있습니다.");
    puts("1~3강 실패시 패널티x, 4강~7강 실패시 1강 하락, 8강~10강 실패시 0~5강으로 하락");
    puts("──────────────────────────────────────────────────────────────────────");
}

void PrintUpgradeMenu(int atkLev, int defLev)
{
    printf("[1]공격력 강화(%d골드)\n", GetUpgradePrice(atkLev));
    printf("[2]방어력 강화(%d골드)\n", GetUpgradePrice(defLev));
    puts("[0]나가기");
    printf(">>");
}

int GetUpgradePrice(int level)
{
    int price = 200;  // 초기 강화비용

    for(int i=0;i<level;i++)   // 강화비용 강화레벨당 10%씩 증가
        price *= 1.1;

    return price;
}

int Upgrade(int *gold, int *level)
{
    int upgradeGaps[] = {10, 10, 20, 20, 30, 30, 40, 50, 60, 100};  // 강화레벨별 증가폭
    int successRate = (int)(100-(100*0.1*(*level)));   // 성공확률 강화레벨당 10%씩 감소
    if(*gold< GetUpgradePrice(*level))
    {
        puts("골드가 부족하여 강화를 할 수 없습니다.");
        sleep(1);
        return 0;
    }

    if(*level>=10)
    {
        puts("더 이상 강화 할 수 없습니다.");
        sleep(1);
        return 0;
    }

    int probability = rand()%100+1;

    /* 강화 성공 */
    if(probability <= successRate)
    {
        *gold -= GetUpgradePrice(*level);
        printf("골드 %d를 소모했습니다.\n", GetUpgradePrice(*level));
        sleep(1);

        *level+=1;
        printf("+%d강 성공!\n", *level);
        sleep(1);

        return upgradeGaps[*level-1];
    }

    /* 강화 실패 */
    else
    {
        int newLev = 0; // 강화 실패 후 강화레벨
        int gaps = 0;

        *gold -= GetUpgradePrice(*level);
        printf("골드 %d를 소모했습니다.(현재 소지금:%d골드)\n", GetUpgradePrice(*level), *gold);
        sleep(1);
        puts("강화가 실패하였습니다.");
        sleep(1);

        // 강화레벨 3이하시 변동x
        if(*level<=3)
            return 0;

        // 5~8강 실패시 1강 감소
        if(*level>=4 && *level<=7)
            newLev = *level-1;

        // 9강~10강 실패시 0~5강으로 하락
        if(*level>=8)
            newLev = rand()&6;

        for(int i=*level-1;i>=newLev;i--)
            gaps -= upgradeGaps[i];

        *level = newLev;

        return gaps;
    }
}

void PrintSword(int level)
{
    if(level<3)
    {
        printf("   / \n");
        printf("=={==========-\n");
        printf("   \\\n");
    }
    else if(level>=3 && level<=4)
    {
        printf("      /| ________________\n");
        printf("O|===|* >________________>\n");
        printf("      \\|\n");
    }
    else if(level>=5 && level<=6)
    {
        printf("         />_________________________________\n");
        printf("[########[]_________________________________>\n");
        printf("         \\>\n");
    }
    else if(level>=7 && level<=9)
    {
        printf("              />\n");
        printf(" (           //-------------------------------------(\n");
        printf("(*)OXOXOXOXO(*>======================================\\\n");
        printf(" (           \\\\---------------------------------------)\n");
        printf("              \\>\n");
    }

    else if(level>=10)
    {
        printf("                              .___.\n");
        printf("          /)               ,-^     ^-.\n");
        printf("         //               /           \\\n");
        printf(".-------| |--------------/  __     __  \\-------------------.__\n");
        printf("|WMWMWMW| |>>>>>>>>>>>>> | />>\\   />>\\ |>>>>>>>>>>>>>>>>>>>>>>:>\n");
        printf("`-------| |--------------| \\__/   \\__/ |-------------------'^^\n");
        printf("         \\\\               \\    /|\\    /\n");
        printf("          \\)               \\   \\_/   /\n");
        printf("                            |       |\n");
        printf("                            |+H+H+H+|\n");
        printf("                            \\       /\n");
        printf("                             ^-----^\n");
    }
}
void PrintShield(int level)
{
    switch(level)
    {
        case 0:
        case 1:
        case 2:
            printf("  |`-._/\\_.-`|\n");
            printf("  |    ||    |\n");
            printf("  |___o()o___|\n");
            printf("  |__((<>))__|\n");
            printf("  \\   o\\/o   /\n");
            printf("   \\   ||   /\n");
            printf("    \\  ||  /\n");
            printf("     '.||.'\n");
            printf("       ``\n");
            break;
        case 3:
        case 4:
            printf("    _..._\n");
            printf(".-'_.---._'-.\n");
            printf("||####|(__)||\n");
            printf("((####|(**)))\n");
            printf(" '\\###|_''/'\n");
            printf("  \\\\()|##//\n");
            printf("   \\\\ |#//\n");
            printf("    .\\_/.\n");
            printf("     L.J\n");
            printf("      \"\n");
            break;
        case 5:
        case 6:
            printf("  |\\ _..--.._ /|\n");
            printf("  |############|\n");
            printf("   )##########(\n");
            printf("._/##.'//\\\\'.##\\_.\n");
            printf(" .__)#((()))#(__.\n");
            printf("  \\##'.\\\\//.'##/\n");
            printf("   \\####\\/####/\n");
            printf("   /,.######.,\\\n");
            printf("  (  \\##__##/  )\n");
            printf("      \"(\\/)\"\n");
            printf("        )(\n");
            break;
        case 7:
        case 8:
        case 9:
           printf("|<><><>     |  |    <><><>|\n");
           printf("|<>         |  |        <>|\n");
           printf("|           |  |          |\n");
           printf("|  (______ <\\-/> ______)  |\n");
           printf("|  /_.-=-.\\| \" |/.-=-._\\  | \n");
           printf("|   /_    \\(o_o)/    _\\   |\n");
           printf("|    /_  /\\/ ^ \\/\\  _\\    |\n");
           printf("|      \\/ | / \\ | \\/      |\n");
           printf("|_______ /((( )))\\ _______|\n");
           printf("|      __\\ \\___/ /__      |\n");
           printf("|--- (((---'   '---))) ---|\n");
           printf("|           |  |          |\n");
           printf("|           |  |          |\n");
           printf(":           |  |          :     \n");
           printf(" \\<>        |  |       <>/    \n") ;
           printf("  \\<>       |  |      <>/       \n");
           printf("   \\<>      |  |     <>/       \n");
           printf("    `\\<>    |  |   <>/'         \n");
           printf("      `\\<>  |  |  <>/'         \n");
           printf("        `\\<>|  |<>/'         \n");
           printf("          `-.  .-`           \n");
           printf("            '--'\n");
           break;
        case 10:
           printf("          {}         \n");
           printf("        .::::.       \n");
           printf("    @\\\\/W\\/\\/W\\//@   \n");
           printf("     \\\\/^\\/\\/^\\//    \n");
           printf("      \\_O_{}_O_/     \n");
           printf(" ____________________ \n");
           printf("|<><><>  |  |  <><><>|\n");
           printf("|<>      |  |      <>|\n");
           printf("|<>      |  |      <>|\n");
           printf("|<>   .--------.   <>|\n");
           printf("|     |   ()   |     |\n");
           printf("|_____| (O\\/O) |_____|\n");
           printf("|     \\   /\\   /     |\n");
           printf("|------\\  \\/  /------|\n");
           printf("|       '.__.'       |\n");
           printf("|        |  |        |\n");
           printf(":        |  |        :\n");
           printf(" \\       |  |       /\n");
           printf("  \\<>    |  |    <>/\n");
           printf("   \\<>   |  |   <>/\n");
           printf("    `\\<> |  | <>/'\n");
           printf("      `-.|__|.-`\n");
           break;
    }
}

int hospital(int *hp)
{
	int count; // 게임의 기회는 10번으로 
	int choice; // 선택지에 따른 결과값이 있으므로, 선언
	mercy();
	for(int i=1; i<=87; i++) printf("=");	
	printf("\n메르시:병원에 온걸 환영 해\n");
	sleep(1);
	printf("여긴 그냥 병원이 아니고...\n");
      	sleep(1);	//이벤트이므로 약간의 대화 작성할것 
	printf("나랑 내기 하나 해야 메챠쿠챠 회복시켜줄꺼란다?\n");
	sleep(2);
	while(1)
	{
		count=0;
		count=game();  //카운트 값으로 선택지가 갈라져 변수를 가지고 게임함수로 이동
		*hp=HP_result(*hp, count);
		if(*hp<=0)
		{
			system("clear");
			for(int i=1; i<=87; i++) printf("=");	
			printf("\n이런...죽어버렸네? 후훗\n"); //엔딩으로
			return 0;
		}	
		choice=restart(1);  //choice값에 따른 결과도출을 위함
		if(choice==2)
		{	
			break;
		}	
	}
}
int restart(int cho)  //choice의 매개변수
{
	mercy();
	for(int i=1; i<=87; i++) printf("=");	
	printf("\n어때...다시 나랑 내기 할까?\n");
	printf("<<<1. 예>>>\t<<<2. 아니오>>>\n");
	scanf("%d", &cho);
	switch(cho)
	{
		case 1:
			mercy();
			for(int i=1; i<=87; i++) printf("=");	
			printf("\n좋아~ 다시 한 판 하자~\n");
			sleep(2);
			system("clear");
			break;
		case 2:
			mercy();
			for(int i=1; i<=87; i++) printf("=");	
			printf("\n아쉽네~ 좀더 놀고 싶었는데~\n");
			sleep(2);
			break;
	}
	return cho;
}	
	
int game(void)
{
	int ret;  //test트
	int count=0;
	int num;  //게임1의 숫자맞추기위해 랜덤으로 도출할 변수
	int clear;  //게임 3의 암산게임의 함을 도출할 변수
	int answer;  //게임 1과 3의 정수답을 입력시킬 변수
	char answer1[15];  //게임 2의 문자열입력시킬 변수
	int random_game;  //3가지의 게임을 랜덤으로 선택시킬 변수
	char GG[10][15] = {"TWICE","BlackPink","IZONE","G.Friend","IU","IOI","April","MAMAMOO","Lovelyz","ChungHA"};  //게임2의 문제들
	int GG_num;  //위의 문자열들을 랜덤으로 출력시킬 변수
	int number[2];  //게임 3의 암산을 위한 두가지 정수를 랜덤으로 출력할 변수
	char calculate[] = {'+','-','*','%','/'}; //게임 3을 위한 연산
	int calcul_num;  //연산을 랜덤으로 출력시켜줄 변수
	random_game=rand()%3;
	
	switch(random_game)
	{
		case 0:
			mercy();
			num=rand()%100+1;
			for(int i=1; i<=87; i++) printf("=");	
			printf("\n음... 내가 생각하는 숫자를 맞춰봐\n");
			while(1)
			{
				count++;
				if(count==11) //기회 10번, count=1부터
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");	
					printf("\n기회를 전부 사용했네?\n");
					sleep(1);
				       	return count;
				}
				printf("==:");
				scanf("%d", &answer);
				mercy();

				if(num>answer)
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");	
					printf("\n음... %d보다는 클 수도, 아닐 수도있어.\n", answer);
					continue;
				}
				else if(num<answer)
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");	
					printf("\n음... %d보다는 작을 수도 있고, 아닐 수도.\n", answer);
					continue;
				}
				else if(num==answer)
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");
					printf("\n흐음... 제범인데? \n");
					sleep(2);
					mercy();
					break;
				}
			}
			break;
		case 1:
			mercy();
			for(int i=1; i<=87; i++) printf("=");	
			printf("\n내가 보여주는 단어를 그대로 따라 쓰면 돼\n");
			sleep(1);
			while(1)
			{
				count++;
				if(count==11)
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");	
					printf("\n더 이상의 기회는 없단다\n");
					return count;
				}
				GG_num=rand()%10;
				printf("깜빡거리는 단어를 맞추면 되는거야~\n");
				sleep(1);
				printf("대소문자 토씨하나 틀리면 안된다?\n");
				sleep(1);
				printf("3초니까 잘 보고 맞추렴^^\n");
				sleep(3);
				mercy();
				for(int i=1; i<=87; i++) printf("=");	
				printf("\n3\n");
				sleep(1);
				mercy();
				for(int i=1; i<=87; i++) printf("=");	
				printf("\n2\n");
				sleep(1);
				mercy();
				for(int i=1; i<=87; i++) printf("=");	
				printf("\n1\n");
				sleep(1);
				mercy();
				for(int i=1; i<=87; i++) printf("=");	
				printf("\n%s\n",GG[GG_num]);
				usleep(100000);
				system("clear");
				mercy();
				for(int i=1; i<=87; i++) printf("=");	
				printf("\n==:");
				scanf("%s", answer1);
				ret=strcmp(GG[GG_num], answer1);
				if(ret==0)
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");	
					printf("\n내가 너를 좀 얕봤네?ㅎㅎ\n");
					sleep(2);
					system("clear");
					break;
				}
				else
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");	
					printf("\n후훗 틀려버렸잖아???\n");
					continue;
				}
			}
			break;
		case 2:
			mercy();
			for(int i=1; i<=87; i++) printf("=");	
			printf("\n이건 좀 어려울거야\n");
			printf("설명? 없어~\n");
			while(1)
			{
				count++;
				if(count==11)
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");	
					printf("\n기회는 여기까지야~ 아쉽네?\n");
					break;
				}
				calcul_num=rand()%5;
				for(int i=0; i<2; i++)
				{	
					number[i]=rand()%100+1;
				}
				switch(calcul_num)
				{
					case 0:
						clear=number[0]+number[1];
						break;
					case 1:
						clear=number[0]-number[1];
						break;
					case 2:
						clear=number[0]*number[1];
						break;
					case 3:
						clear=number[0]%number[1];
						break;
				}
				sleep(2);
				mercy();
				for(int i=1; i<=87; i++) printf("=");	
				printf("\n%d %c %d\n", number[0], calculate[calcul_num], number[1]);
				sleep(1);
				system("clear");
				mercy();
				for(int i=1; i<=87; i++) printf("=");
				printf("\n정수 부분만 쓰면 되니까 너무 긴장마~\n");	
				printf("\n==:");
				scanf("%d", &answer);
				while(getchar() != '\n');				
				system("clear");
				if(answer==clear)
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");	
					printf("\n정말 대단해 이걸 맞춘다구요?\n");
					sleep(2);
					system("clear");
					break;
				}
				else
				{
					mercy();
					for(int i=1; i<=87; i++) printf("=");	
					printf("\n흠....잘 좀 해보라구~\n");
					continue;
				}
