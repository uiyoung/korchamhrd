#include <stdio.h>

int main()
{
    int a = 20, b = 0;

    if(a > 10)
        b = a;

    printf("a:%d, b:%d\n", a, b);

    return 0;
}
