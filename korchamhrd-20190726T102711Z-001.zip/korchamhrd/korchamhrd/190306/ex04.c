#include <stdio.h>

int main()
{
    int a, b;
    printf("a, b 입력>>");
    scanf("%d%d", &a, &b);

    printf("사각형 넓이:%d\n", a * b);

    return 0;
}

