#include <stdio.h>

int main()
{
    int hour, min, sec;
    printf("input sec>>");
    scanf("%d", &sec);
    
    hour = sec / 3600;
    sec %= 3600;
    min = sec / 60;
    sec = sec % 60;
    
    printf("%dHours %dMinutes %dSeconds\n", hour, min, sec);

    return 0;
}
