#include <stdio.h>
#include <string.h>

int main()
{
    int a, b;
    char op[4];
    char op2;
    
    //1
    printf("정수 a, b 입력>>");
    scanf("%d%d", &a, &b);
    printf("연산자(+,-,*,/,%%) 입력>>");
    scanf("%c", &op2);

    if(op2=='+')
        printf("yeah\n");


    if(strcmp(op, "+") == 0)
        printf("%d %s %d = %d\n", a, op, b, a+b);
    else if(strcmp(op, "-") == 0)
        printf("%d %s %d = %d\n", a, op, b, a-b);
    else if(strcmp(op, "*") == 0)
        printf("%d %s %d = %d\n", a, op, b, a*b);
    else if(strcmp(op, "/") == 0)
        printf("%d %s %d = %d\n", a, op, b, a/b);
    else if(strcmp(op, "%") == 0)
        printf("%d %s %d = %d\n", a, op, b, a%b);
    else
        printf("올바른 연산자를 입력해주세요.\n");

    //2
    printf("정수 a 입력>>");
    scanf("%d", &a);
    if(a%2 == 0)
        printf("짝수입니다.\n");
    else
        printf("홀수입니다.\n");
    //3
    printf("정수 a, b 입력>>");
    scanf("%d%d", &a, &b);
    if(a > b)
        printf("a가 b보다 크다.\n");
    else if(a < b)
        printf("a가 b보다 작다.\n");
    else
        printf("a와 b가 같다.\n");

    //4
    printf("나이 입력>>");
    scanf("%d", &a);
    if(a>=19)
        printf("성인입니다.\n");
    else
        printf("미성년자입니다.\n");

    //5
    printf("1 or 0 입력>>\n");
    scanf("%d", &a);
    if(a)
        printf("참\n");
    else
        printf("거짓\n");

    //6
    printf("숫자 입력>>\n");
    scanf("%d", &a);
    if(a < 10)
        printf("한자리수\n");
    else if(a < 100)
        printf("두자리수\n");
    else
        printf("세자리 이상의 수\n");

    //7
    printf("몇번째 문제?>>\n");
    scanf("%d", &a);
    if(a == 7)
        printf("정답\n");
    else
        printf("땡\n");

    //8
	printf("아무것도 입력x>>");
	scanf("%d", &a);
    if(a == NULL)
		printf("good\n");
	else
		printf("wrong\n");

	//9
	printf("점수 입력>>");
	scanf("%d", &a);

	if (a >= 90) 
		printf("합격 \n");
	else if (a < 90) 
		printf("불합격\n");

    //10
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}
