#include <stdio.h>

int main()
{
    int a = 3, b = 5;
    int add = a + b;
    int mul = a * b;

    printf("add : %d\n", add);
    printf("add : %d\n", mul);
    
    return 0;
}
