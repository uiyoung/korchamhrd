#include <stdio.h>

int main()
{
    int a;
    printf("cm입력>>");
    scanf("%d", &a);

    printf("%dcm = %dm %dcm\n", a, a/100, a%100);
   
    return 0;
}
