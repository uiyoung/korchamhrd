#include <stdio.h>

int main()
{
    int a, b, c;
    int sum;
    printf("a, b, c 입력 >>");
    scanf("%d%d%d", &a, &b, &c);
    sum = a + b + c;

    printf("총점 : %d, 평균 : %d\n", sum, sum/3);
    
    return 0;
}
