#include <stdio.h>

int main()
{
    char ch1;
    printf("input>>");
    scanf("%c", &ch1);
    
    printf("%c\n", ch1);

    return 0;

}
