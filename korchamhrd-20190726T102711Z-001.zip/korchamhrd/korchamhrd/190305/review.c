#include <stdio.h>
#include <string.h>

int main()
{
    int num = 1;
    int a, b;
	char op[4];
    
    printf("\nreview %d. \n", num++);
    printf("두 정수 a, b 입력>>");
    scanf("%d%d", &a, &b);
    printf("연산자(+,-,*,/) 입력>>");
	scanf("%s", op);
	printf("%d %s %d = %d\n", a, op, b, (strcmp(op, "+")==0 ? a + b : (strcmp(op, "-")==0 ? a - b : (strcmp(op, "*")==0 ? a * b : (strcmp(op, "/")==0 ? a / b : 0)))));
    printf("-----------------------\n");

    char charVar = 127;
    short shortVar = 32767;
    int intVar = 2147483647;
    long longVar = 2147483647;
    float floatVar = 3.14;
    double doubleVar = 23131532.3332112;
    long double longDoubleVar = 213122313.21213122;

    printf("\nreview %d. \n", num++);
    printf("size of char : %ld\n", sizeof(charVar));
    printf("size of short : %ld\n", sizeof(shortVar));
    printf("size of int : %ld\n", sizeof(intVar));
    printf("size of long : %ld\n", sizeof(longVar));
    printf("size of float : %ld\n", sizeof(floatVar));
    printf("size of double : %ld\n", sizeof(doubleVar));
    printf("size of long double : %ld\n", sizeof(long double));
    printf("-----------------------\n");
    
    printf("\nreview %d. \n", num++);
    printf("정수 a, b 입력>>");
    scanf("%d %d", &a, &b );
    printf("%d는 %d와 같다 : %d\n", a, b, a == b);
    printf("%d는 %d보다 크다 : %d\n", a, b, a > b);
    printf("%d는 %d보다 작다 : %d\n", a, b, a < b);
    printf("%d와 %d는 같지 않다 : %d\n", a, b, a != b);
    printf("%d는 %d보다 작거나 같다 : %d\n", a, b, a <= b);
    printf("%d는 %d보다 크거나 같다 : %d\n", a, b, a >= b);
    printf("++a : %d\n", ++a);
    printf("--b : %d\n\n", --b);
    printf("-----------------------\n");
    
    printf("\nreview %d. \n", num++);
    printf("true, false 두개 입력>>");
    scanf("%d %d", &a, &b);
    printf("%d && %d : %d\n", a, b, a && b);
    printf("%d || %d : %d\n", a, b, a || b);
    printf("!%d : %d\n", a, !a);
    printf("-----------------------\n");

    printf("\nreview %d. \n", num++);
	printf("초를 입력>>");
	scanf("%d", &a);
    int h, m, s;
    h = a/3600;
    a -= h*3600;
    m = a/60;
    a -= m*60;
    s = a;
    printf("%d시간 %d분 %d초 입니다.\n", h, m, s);  
    
    return 0;
}
