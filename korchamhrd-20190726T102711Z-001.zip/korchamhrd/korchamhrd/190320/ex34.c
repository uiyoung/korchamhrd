#include <stdio.h>

int main()
{
    int i;
    int n, sum;

    for(i=1;i<=10;i++)
    {
        n+=i;
        sum += n;
    }   
    
    printf("sum:%d\n", sum);

    return 0;
}
