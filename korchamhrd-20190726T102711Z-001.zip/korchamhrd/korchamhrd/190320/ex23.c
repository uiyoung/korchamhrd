#include <stdio.h>

int main()
{
    int i;
    int n, sum;

    for(i=1;i<=100;i++)
    {
        if(i%2==0)
            sum-=i;
        else
            sum+=i;
    }   
    
    printf("sum:%d\n", sum);

    return 0;
}
