#include <stdio.h>

int main()
{
    char str[5]={"apple"};

    for(int i=0;i<5;i++)
        printf("%c", str[i]);

    putchar('\n');

    return 0;
}
