#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void GenerateWord(char lower[], char upper[]);
int main()
{
    char lowerCases[26];
    char upperCases[26];
    char lowerA = 'a';
    char upperA = 'A';
    int counter = 1;

    srand(time(NULL));
    
    //initialize lowercase letters
    for(int i=0;i<sizeof(lowerCases)/sizeof(char);i++)
        lowerCases[i]=lowerA++;

    //initialize uppercase letters
    for(int i=0;i<sizeof(upperCases)/sizeof(char);i++)
        upperCases[i]=upperA++;


    //print randomly generated words
    for(int i=0;i<100;i++)
    {
        printf("%2d. ", counter++);
        GenerateWord(lowerCases, upperCases);
        putchar('\n');
    }

    return 0;
}

void GenerateWord(char lower[], char upper[])
{
    int length = rand()%20+3; // 단어 길이

    for(int i=0;i<length;i++)
    {
        printf("%c", i%2==0?upper[rand()%26]:lower[rand()%26]);
    }
}
