#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>

typedef struct _monster
{
    char name[20];
    int maxHP;
    int currentHP;
    int minDamage;
    int maxDamage;
    int escapeSuccessRate;  // 도망 성공률
    int reward;
} Monster;

typedef struct _bullet
{
    char name[20];
    int remaining; // 남은 갯수
	int minDamage;
	int maxDamage;
    int isInfinite; // 무한총탄 여부
} Bullet;

typedef struct _potion
{
    char name[20];
    int remaining;
    //int healingAmount;
} Potion;
    
typedef struct _player
{
    char name[20];
    int maxHP;
    int currentHP;
    int minDamage;
    int maxDamage;
    Bullet bullets[4];
    Potion healingPotion; 
} Player;

void printIntro(Player *);
void printMenu(Player *, Monster *);
void showBullets(Player *);
void battle(Player *, Monster *, int);
void attackEnemy(Player *, Monster *, int);
void attackPlayer(Player *, Monster *);
void assualt(Player *, Monster *);
void takeHealingPotion(Player *, Monster *);
void showPlayerStatus(Player *);
void showEnemyStatus(Monster *);
void victory(Player *, Monster *);
void escape(Player *, Monster *);
void defeat(Player *, Monster *);
void reward(Player *, Monster *);
void moveToward();
void ending(Player *);

int isVictory, isDefeat, isEscape;
int victoryCounter, escapeCounter;

int main()
{
    int i, choice, bulletChoice;
    char playerName[20];
    srand(time(NULL));

    Monster monsters[] = {
        {.name ="돌복이", .maxHP=500, .currentHP=500, .minDamage=10, .maxDamage=300, .escapeSuccessRate=50, .reward = 300}, 
        {.name ="돌땅복이", .maxHP=2500, .currentHP=2500, .minDamage=30, .maxDamage=500, .escapeSuccessRate = 30, .reward = 500}, 
        {.name ="디아킹복이", .maxHP=5000, .currentHP=5000, .minDamage=50, .maxDamage=1000, .escapeSuccessRate=15, .reward = 1000}
    };
    
    Player player = {" ", 350, 350, 10, 30, 10};
    
	printf("player 이름 입력>>");
    scanf("%s", playerName);
    strcpy(player.name, playerName);

	// initialize bullets 
    strcpy(player.bullets[0].name, "일반 총탄");
    player.bullets[0].minDamage = 50;
	player.bullets[0].maxDamage = 200;
	player.bullets[0].remaining = 9999;
    player.bullets[0].isInfinite = 1;
	strcpy(player.bullets[1].name, "화염 총탄");
    player.bullets[1].minDamage = 300;
	player.bullets[1].maxDamage = 700;
	player.bullets[1].remaining = 3;
    player.bullets[1].isInfinite = 0;
	strcpy(player.bullets[2].name, "얼음 총탄");
    player.bullets[2].minDamage = 300;
	player.bullets[2].maxDamage = 700;
	player.bullets[2].remaining = 3;
    player.bullets[2].isInfinite = 0;
	strcpy(player.bullets[3].name, "바람 총탄");
    player.bullets[3].minDamage = 300;
	player.bullets[3].maxDamage = 700;
	player.bullets[3].remaining = 3;
    player.bullets[3].isInfinite = 0;

    // initialize potion
    strcpy(player.healingPotion.name, "힐링포션");
    player.healingPotion.remaining = 10;
	
    printIntro(&player);

    for(i=0;i<sizeof(monsters)/sizeof(monsters[0]);i++)
    {
        isVictory = 0;
        isDefeat = 0;
        isEscape = 0;

        moveToward();
        printf("%s(은)는 %s와 마주쳤다.\n", player.name, monsters[i].name);
        sleep(1);
        
        while(!isVictory && !isDefeat && !isEscape)
        {
            showPlayerStatus(&player);
            showEnemyStatus(&monsters[i]);
            printMenu(&player, &monsters[i]);
            scanf("%d", &choice);
            
            switch(choice)
            {
                case 1:
                    showBullets(&player);
                    scanf("%d", &bulletChoice);
                    battle(&player, &monsters[i], bulletChoice-1);

                    break;
                case 2:
                    takeHealingPotion(&player, &monsters[i]);

                    break;
                case 3:
                    escape(&player, &monsters[i]);
                    
                    break;
                default:
                    printf("올바른 선택지를 골라주세요\n");

                    break;
            }
        }

        if(victoryCounter+escapeCounter>=sizeof(monsters)/sizeof(monsters[0]))
            ending(&player);
   }

    return 0;
}
void printIntro(Player *p)
{
    printf("%s은(는) 총 한자루와 포션%d개를 가지고 \n", p->name, p->healingPotion.remaining);
    sleep(1);
    printf("전설의 디아킹복이를 무찌르기 위해 여행을 떠났다.\n");
    sleep(1);
}

void printMenu(Player *p, Monster *m)
{
    printf("--------------------------------------\n");
    printf("어떻게 할까?\n");
    printf("1. 공격\n");
    printf("2. 힐링포션 복용(남은 갯수:%d)\n", p->healingPotion.remaining);
    printf("3. 도망(성공률:%d%%)\n", m->escapeSuccessRate);
    printf(">>");
}

void showBullets(Player *p)
{
    int i;
    printf("----------------Bullets----------------\n");
    printf("어떤 총탄을 사용할까?\n");
    for(i=0;i<sizeof(p->bullets)/sizeof(p->bullets[0]);i++)
    {
        if(!p->bullets[i].isInfinite)
            printf("%d. %s (%d발 남음)\n", i+1, p->bullets[i].name, p->bullets[i].remaining);
        else
            printf("%d. %s\n", i+1, p->bullets[i].name);
    }
    printf(">>");
}

void battle(Player *p, Monster *m, int bullet)
{
	if(p->bullets[bullet].isInfinite==0 && p->bullets[bullet].remaining <= 0)
    {
        printf("%s은 모두 떨어져버렸다...\n", p->bullets[bullet].name);
        sleep(1);
        return;
    }

    printf(">>>> %s vs %s <<<< \n", p->name, m->name); 
    if(!isDefeat)
        attackEnemy(p, m, bullet);

    if(!isVictory)
        attackPlayer(p, m);
    
    sleep(1);
    printf("--------------------------------------\n");
}

void attackEnemy(Player *p, Monster *m, int bullet)
{
    int maxDamage = p->maxDamage + p->bullets[bullet].maxDamage;
	int damage = rand() % ((p->maxDamage)+(p->bullets[bullet].maxDamage)) + ((p->minDamage) + (p->bullets[bullet].minDamage));
    
    m->currentHP -= damage;

    if(!p->bullets[bullet].isInfinite)
        p->bullets[bullet].remaining--;

    printf("%s은(는) %s에게 %s을(를) 사용하여 %d만큼의 피해를 입혔다!\n", p->name, m->name, p->bullets[bullet].name,damage); 

    if(m->currentHP < 0)
        m->currentHP = 0;
    
    if(m->currentHP <= 0)
        victory(p, m);
}

void attackPlayer(Player *p, Monster *m)
{
    int damage = rand() % m->maxDamage + m->minDamage;
    p->currentHP -= damage;
    printf("%s은(는) %s에게 %d만큼의 피해를 입혔다!\n", m->name, p->name, damage); 
    
    if(p->currentHP < 0)
        p->currentHP = 0;
    
    if(p->currentHP <= 0)
    {
        defeat(p, m);
        isDefeat = 1;
    }
}

void takeHealingPotion(Player *p, Monster *m)
{
    int assualtRate = rand()%100+1;
    if(p->healingPotion.remaining <=0)
    {
        printf("남은 힐링포션이 없다...\n");
        sleep(1);
        return;
    }
    
    if(p->currentHP >= p->maxHP)
    {
        printf("이미 최대 체력이다.\n\n");
        sleep(1);
        return;
    }

    p->healingPotion.remaining--;

    p->currentHP = p->maxHP;

    printf("힐링포션을 복용하여 체력이 모두 회복되었다.\n");
    sleep(1);
    assualt(p, m);

    }

void assualt(Player *p, Monster *m)
{
    int assualtRate = rand() % 100 + 1;

    // 70%의 확률로 포션마시는중 또는 도망실패시 기습공격 발동 
    if(assualtRate <= 70) 
    {
        printf("그 사이, %s가 기습 공격을 해왔다!\n", m->name);
        sleep(1);
        attackPlayer(p, m);
        sleep(1);
    }
    else
        return;
}

void showPlayerStatus(Player *p)
{
    printf("- %s(HP:%d/%d)\n", p->name, p->currentHP, p->maxHP);
}

void showEnemyStatus(Monster *m)
{
    printf("- %s(HP:%d/%d)\n", m->name, m->currentHP, m->maxHP);
}

void victory(Player *p, Monster *m)
{
    isVictory = 1;
    victoryCounter++;

    printf("\n");
    printf("%s은(는) %s를 물리쳤다!\n", p->name, m->name);
    sleep(1);
    reward(p, m);
}

void defeat(Player *p, Monster *m)
{
    printf("\n");
    printf("%s은(는) %s에게 당하고 말았다...\n", p->name, m->name);
    sleep(1);
    printf("--------------------------------------\n");
    exit(1);
}

void escape(Player *p, Monster *m)
{
    if(rand() % 100 + 1 <= m->escapeSuccessRate) 
    {
        printf("%s은(는) %s에게서 겨우 도망쳤다!!\n", p->name, m->name);
        isEscape = 1;
        sleep(1);
        escapeCounter++;
    }
    else
    {
        printf("%s은(는) %s에게서 도망치는데 실패했다!!\n", p->name, m->name);
        sleep(1);
        assualt(p, m);
        sleep(1);
    }
    printf("--------------------------------------\n");
}

void moveToward()
{
    int i;
    printf("(이동 중)\n");

    for(i=0;i<3;i++)
    {
        printf(".\n");
        sleep(1);
    }    
}

void reward(Player *p, Monster *m)
{
    p->maxHP += m->reward;
    p->currentHP = p->maxHP;
    printf("%s은(는) %s를 물리쳐 최대HP가 %d만큼 증가하고, 체력이 모두 회복되었다!\n", p->name, m->name, m->reward); 
}

void ending(Player *p)
{
    if(victoryCounter>=3)
        printf("용사 %s은(는) 모든 복이들을 물리쳤기 때문에 더 이상의 남은 과제가 없다고 한다.\n", p->name);
    else if(escapeCounter>=3)
        printf("용사 %s은(는) 모든 복이들에게서 도망쳐 더 이상 남은 과제가 없다고 한다.\n", p->name);
    else
        printf("용사 %s은(는) 전투에서 %d번의 전투에서 승리를 거두고, %d번의 전투에서 도망치는데 성공해 더 이상 남은 과제가 없다고 한다.", p->name, victoryCounter, escapeCounter); 
}
