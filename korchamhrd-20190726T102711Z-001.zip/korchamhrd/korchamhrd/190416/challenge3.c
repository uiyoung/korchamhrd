#include <stdio.h>

void rotate(int *pa, int *pb, int *pc)
{
    int temp = *pa;
    *pa = *pb;
    *pb = *pc;
    *pc = temp;
}

int main()
{
    char input; 
    int a=1, b=2, c=3;

    while(1)
    {
        printf("%d:%d:%d", a, b, c);
        rotate(&a, &b, &c);
        input = getchar();

        if(input != '\n')
            break;
    }

    return 0;
}
