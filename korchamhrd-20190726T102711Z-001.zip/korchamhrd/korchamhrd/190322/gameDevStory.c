#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#define MAX_NUM_OF_EMPLOYEES 13    // 최대 고용가능 직원 수
#define MAX_NUM_OF_GAMES 100    // 최대 개발 가능 게임 수

typedef struct _company
{
    char name[30];
    long capital;
    int numOfEmployees;  // 직원 수
    int runningMonths;  // 회사 운영 기간
    int numOfReleasedGames; // 출시작 수
} Company;

typedef struct _game
{
    char title[100];
    int price;
    int developmentPeriod;  // 개발기간
    char developers[600];   // 개발자 이름
    int metaScore;  // 리뷰 점수
    int sales;  // 판매량
} Game;

typedef struct _employee
{
    char name[30];
    int salary;
    double minWorkingSpeed; // 최저 작업속도
    double maxWorkingSpeed; // 최고 작업속도
    int isHired;    // 고용 여부
} Employee;

const long INITIAL_CAPITAL = 100000000;  // 초기자금 1억
const long BANKRUPT_CONDITION = -50000000;   // 파산 조건 : -5000만원

static int gameCounter=0;    // 게임 생성용 카운터
void printStatus(Company *c, Employee e[], Game g[]);
void printMenu();
void printJobMarket(Company *c, Employee e[]);
void printHiredList(Company *c, Employee e[]);
void printWorkSpeedToStars(double workSpeed);
void printDiligenceToCircles(double diligence);
void hire(Company *c, Employee e[], int choice);
int fire(Company *c, Employee e[], int choice);
int developGame(Company *c, Employee e[], Game g[]);
int sellGames(Company *c, Game g[]);
void calcCapital(Company *c, Game g[], long soldCopies);
void checkBankruptcy(Company *c);
void printReleasedGames(Company *c, Game g[]);
void printEnding(Company *c, int isBankruptcy);

int main()
{
    int i, choice;
    srand(time(NULL));
    system("clear");

    // initialize employees
    Employee employees[MAX_NUM_OF_EMPLOYEES] = {{"", 0,0,0,0}};
    char names[][30] = {"김택진", "김정주", "송재경", "손학규", "권순성", "김태곤", "리차드 개리엇", "빌 로퍼", "미야모토 시게루", "존 카맥", "윌 라이트", "시드 마이어", "알렉세이 파지노프"};

    for(i=0;i<MAX_NUM_OF_EMPLOYEES;i++)
    {
        int salary = (rand()%61+20) * 100000; // 월급 200~800사이 랜덤
        double minWorkingSpeed = (double)(rand()%9+2) / 10; //최저, 최대작업속도 
        double maxWorkingSpeed = (double)(rand()%9+2) / 10; // 0.2~1.0 랜덤 

        if(minWorkingSpeed > maxWorkingSpeed)
        {
            double temp;
            temp = minWorkingSpeed;
            minWorkingSpeed = maxWorkingSpeed;
            maxWorkingSpeed = temp;
        }

        strcpy(employees[i].name, names[i]);
        employees[i].salary = salary;
        employees[i].minWorkingSpeed = minWorkingSpeed;
        employees[i].maxWorkingSpeed = maxWorkingSpeed;
        employees[i].isHired = 0;
    }

    //initialize games
    Game games[MAX_NUM_OF_GAMES] = {{"없음", 0, 0, "", 0, 0}};  //title, price, 개발기간, 개발자명, 점수, 판매량 

    for(i=0;i<MAX_NUM_OF_GAMES;i++)
    {
        strcpy(games[i].title, "없음");
        games[i].price = 30000;
        games[i].developmentPeriod = 0;
        strcpy(games[i].developers, "");
        games[i].metaScore= 0;
        games[i].sales = 0;
    }

    // initialize company
    Company company = {"", INITIAL_CAPITAL, 0, 0, 0};   //사명, 자본, 직원수, 운영기간, 출시작수
    printf("그래 게임회사를 만들자!\n");
    sleep(1);
    printf("회사이름은 무엇으로 할까?\n");
    printf(">>");
    scanf("%s", company.name);
    printf("게임회사 %s가 설립되었다!\n", company.name);
    sleep(1);

    while(1)
    {
        printStatus(&company, employees, games);
        printMenu();
        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                if(company.numOfEmployees<= 0)
                {
                    printf("게임을 개발 할 직원이 없다...고용부터 하자\n");
                    sleep(1);
                    break;
                }

                printf("게임 제목은 뭐로 할까?\n");
                printf(">>");
                scanf("%s", games[gameCounter].title);
                int isDeveloping = developGame(&company, employees, games);
                if(isDeveloping)
                {
                    long soldCopies = sellGames(&company, games);
                    calcCapital(&company, games, soldCopies);
                    printf("계속>>");
                    getchar();
                    printStatus(&company, employees, games);
                    printf("계속 하시겠습니까?([1]예 [2]아니오)\n");
                    printf(">>");
                    scanf("%d", &choice); 

                    if(choice==2)
                        printEnding(&company, 0);

                    gameCounter++;
                    company.numOfReleasedGames++;
                }

                break;
            case 2:
                putchar('\n');
                printf("누구를 고용할까?\n");
                printJobMarket(&company, employees);
                printf(">>");
                scanf("%d", &choice);
                hire(&company, employees, choice);

                break;
            case 3:
                if(company.numOfEmployees<=0)
                {
                    printf("해고 할 직원이 없다.\n");
                    sleep(1);
                    break;
                }

                printf("누구를 해고할까?\n");
                printHiredList(&company, employees);
                printf(">>");
                scanf("%d", &choice);
                int isFire = fire(&company, employees, choice);
                if(isFire)
                {
                    printStatus(&company, employees, games); 
                    checkBankruptcy(&company); 
                }

                break;
            case 4:
                if(company.numOfReleasedGames<=0)
                {
                    printf("아직 출시 한 게임이 없다.\n");
                    sleep(1);
                    break;
                }
                printReleasedGames(&company, games);
                printf("[0]뒤로가기\n");
                printf(">>");
                scanf("%d", &choice);

                if(choice==0)
                    printStatus(&company, employees, games);

                break;
            default:
                putchar('\n');
                printf("올바른 선택지를 골라주세요\n");
                sleep(1);

                break;
        }
    }

    return 0;
}

void printStatus(Company *c, Employee e[], Game g[])
{
    int i;
    system("clear");
    printf("───────────────────────────────Game Dev Story───────────────────────────────\n");
    printf(" [%s]\n", c->name);
    printf(" %d개월 동안 운영 중\n\n", c->runningMonths);
    printf("────────────재정────────────\n"); 
    printf(" 자본금: %ld원%s\n", c->capital, c->capital<0 ? "(대출 중)" : "");
    printf(" 손익 : %ld원\n\n", c->capital-INITIAL_CAPITAL);
    printf("────────────직원────────────\n"); 
    if(c->numOfEmployees==0)
        printf(" [없음]");

    for(i=0;i<MAX_NUM_OF_EMPLOYEES;i++)
    {
        if(e[i].isHired)
            printf("/ %s ", e[i].name);
    }
    putchar('\n');
    printf("────────────────────────────\n\n"); 
    printf(" 개발 중인 게임 : [%s]\n", g[gameCounter].title);
    printf(" 개발 기간 : %d개월\n", g[gameCounter].developmentPeriod);
    printf(" 판매량 : %d장\n", g[gameCounter].sales);
    printf("────────────────────────────────────────────────────────────────────────────\n");
}

void printMenu()
{
    printf("[1]게임 개발\n");
    printf("[2]개발자 고용\n");
    printf("[3]개발자 해고\n"); 
    printf("[4]출시 한 게임\n");
    printf(">>");
}

// todo : 정렬
void printJobMarket(Company *c, Employee e[])
{
    int i;

    if(c->numOfEmployees>= MAX_NUM_OF_EMPLOYEES)
    {
        putchar('\n');
        printf("더 이상 고용할 수 없다.\n");
        return;
    }

    printf(" %s %s\t\t %s\t %s\t %s\n", "번호", "이름", "월급", " 평균작업속도", "성실도");
    printf("───────────────────────────────────────────────────────────\n");
    for(i=0;i<MAX_NUM_OF_EMPLOYEES;i++)
    {
        if(!e[i].isHired)
        {
            printf(" [%2d] %-20s\t %d만원\t", i+1, e[i].name, e[i].salary/10000);
            printWorkSpeedToStars((e[i].maxWorkingSpeed+e[i].minWorkingSpeed)/2);
            putchar('\t');
            printDiligenceToCircles(e[i].maxWorkingSpeed-e[i].minWorkingSpeed);
            putchar('\n');
        }
    }
    putchar('\n');
    printf("*평균 작업 속도는 최저작업속도와 최고작업속도의 평균입니다.\n");
    printf("*성실도가 높을수록 컨디션에 영향받지 않고 일정한 속도로 작업을 합니다.\n");
    printf(" [0] 취소\n");
}

// todo : 정렬
void printHiredList(Company *c, Employee e[])
{
    int i;
    printf(" %s %s\t\t %s\t %s\t %s\n", "번호", "이름", "월급", " 평균작업속도", "성실도");
    printf("───────────────────────────────────────────────────────────\n");
    for(i=0;i<MAX_NUM_OF_EMPLOYEES;i++)
    {
        if(e[i].isHired)
        {
            printf(" [%2d] %-20s\t %d만원\t", i+1, e[i].name, e[i].salary/10000);
            printWorkSpeedToStars((e[i].maxWorkingSpeed+e[i].minWorkingSpeed)/2);
            putchar('\t');
            printDiligenceToCircles(e[i].maxWorkingSpeed-e[i].minWorkingSpeed);
            putchar('\n');
        }
    }
    putchar('\n');
    printf("*평균 작업 속도는 최저작업속도와 최고작업속도의 평균입니다.\n");
    printf("*성실도가 높을수록 컨디션에 영향받지 않고 일정한 속도로 작업을 합니다.\n");
    printf("*해고 시, 3개월분의 월급을 위로금으로 지급해야 합니다.\n");

    printf(" [0] 취소\n");
}

/* 
   평균작업속도를 별모양으로 표시
   0.2~0.3 : 1개
   0.4~0.5 : 2개
   0.6~0.7 : 3개
   0.8~0.9 : 4개
   1.0 : 5개
 */
void printWorkSpeedToStars(double workSpeed)
{
    int i;
    int filledStars = (int)(workSpeed*10/2);

    for(i=0;i<5;i++)
        printf("%s", i<filledStars ? "★" : "☆");
}

/*
   성실도(최대작업속도-최저작업속도)를 원모양으로 표시
   0.8 : 1개
   0.5~0.7 : 2개
   0.3~0.4 : 3개
   0.1~0.2 : 4개
   0.0 : 5개
 */
void printDiligenceToCircles(double diligence)
{
    int i;
    int emptyCircles = (int)(diligence*10+1)/2;
    int filledCircles = 5-emptyCircles;

    for(i=0;i<5;i++)
        printf("%s", i<filledCircles ? "●" : "○");
}

void hire(Company *c, Employee e[], int choice)
{
    // 취소를 선택
    if(choice == 0)
        return;

    if(e[choice-1].isHired || choice<1 || choice>MAX_NUM_OF_EMPLOYEES)
    {
        printf("올바른 번호를 입력해주세요\n");
        sleep(1);
        return;
    }

    e[choice-1].isHired = 1;
    c->numOfEmployees++;
    printf("%s을(를) 고용했다!\n", e[choice-1].name);
    sleep(1);
}

int fire(Company *c, Employee e[], int choice)
{
    // 취소를 선택
    if(choice == 0)
        return 0;


    if(!e[choice-1].isHired || choice<1 || choice>MAX_NUM_OF_EMPLOYEES)
    {
        printf("올바른 번호를 입력해주세요\n");
        sleep(1);
        return 0;
    }

    e[choice-1].isHired = 0;
    c->numOfEmployees--;
    printf("%s을(를) 해고했다!\n", e[choice-1].name);
    sleep(1);

    //위로금 지급 
    int compensation = e[choice-1].salary * 3;
    c->capital -= compensation;
    printf("%s에게 위로금으로 %d원을 지급했다.\n", e[choice-1].name, compensation);
    sleep(1);

    return 1;
}

void checkBankruptcy(Company *c)
{
    if(c->capital <= BANKRUPT_CONDITION)
        printEnding(c, 1); 
}


int developGame(Company *c, Employee e[], Game g[])
{
    printStatus(c, e, g);

    int i; 
    double workload = rand()%19+6; // 작업량(6개월~24개월 어치)
    double averageWorkforce = 0;
    int elapsedMonth=0;   // 경과한 개월

    printf("(개발 스케줄 산정 중...)\n");
    sleep(1);

    for(i=0;i<MAX_NUM_OF_EMPLOYEES;i++)
    {
        if(e[i].isHired)
            averageWorkforce += (e[i].minWorkingSpeed+e[i].maxWorkingSpeed)/2;
    }
    printf("우리 개발자들 실력이라면 게임 완성까지 평균 %d개월 정도 걸리겠군...\n", (int)(workload/averageWorkforce)); 
    sleep(1);

    printf("(게임 개발 중...)\n");

    while(workload> 0)
    {
        int salaryOfThisMonth=0;

        for(i=0;i<MAX_NUM_OF_EMPLOYEES;i++)
        {
            if(e[i].isHired)
            {
                int condition = rand() % 3; //0:나쁨 1:보통 2:좋음
                double workingSpeedOfThisMonth;    //컨디션에 따른 이번달 작업속도 

                printf("%s이(가) 일하는 중...\n", e[i].name);
                sleep(1);

                if(condition==2)
                {
                    workingSpeedOfThisMonth = e[i].maxWorkingSpeed;
                    printf("이번 달 %s의 컨디션이 좋다!\n", e[i].name);
                    sleep(1);
                }
                else if(condition==0)
                {
                    workingSpeedOfThisMonth = e[i].minWorkingSpeed;
                    printf("이번 달 %s의 컨디션이 별로다.\n", e[i].name);
                    sleep(1);
                }
                else
                    workingSpeedOfThisMonth = (e[i].minWorkingSpeed+e[i].maxWorkingSpeed)/2;

                workload -= workingSpeedOfThisMonth;
                salaryOfThisMonth += e[i].salary;
            }
        }

        // todo : event
        // [버그발견] +3개월 
        // 전체적으로 사기가 올라 약 -%d개월 분량의 작업을 앞서게 되었다!
        elapsedMonth++;
        g[gameCounter].developmentPeriod = elapsedMonth;
        c->runningMonths++;
        c->capital -= salaryOfThisMonth;
        printf("(%d개월 경과)\n", elapsedMonth);
        printf("이번달 직원들 급여로 총 %d원을 사용했다.\n", salaryOfThisMonth);
        sleep(1);

        printStatus(c, e, g);

        // check if it's bankruptcy 
        checkBankruptcy(c); 
    }

    char developers[600] = "";
    for(i=0;i<MAX_NUM_OF_EMPLOYEES;i++)
    {
        if(e[i].isHired)
        {
            strcat(developers, e[i].name);
            strcat(developers, "/");
        }
    }
    strcpy(g[gameCounter].developers, developers);

    printf("%d개월만에 드디어 %s이(가) 출시되었다!\n", elapsedMonth, g[gameCounter].title);
    sleep(1);

    return 1;
} 

int sellGames(Company *c, Game g[])
{
    int metaScore = rand()%100+1;   // 메타크리틱 전문가 점수
    int userScore = rand()%100+1;   // 유저 점수
    int averageScore = (metaScore + userScore) / 2;
    int sales[] = {100, 500, 1000, 3000, 10000, 50000, 100000, 300000, 500000, 1000000}; //점수 별 판매량

    g[gameCounter].metaScore = averageScore;
    g[gameCounter].sales = sales[averageScore/10];

    printf("%s의 판매가 시작되었다.\n", g[gameCounter].title);
    printf("%s가 개발 한 %s는 ", g[gameCounter].developers, g[gameCounter].title); 
    printf("전문 리뷰어들에게 %d점의 평가를 받았다. \n", metaScore);
    sleep(1);

    if(metaScore - userScore > 30 || userScore - metaScore > 30) 
        printf("반면에, ");

    printf("유저들에게는 %d점의 평가를 받았다. \n", userScore);
    sleep(1);
    printf("판매 중...\n");
    sleep(1);
    printf(".\n");
    sleep(1);
    printf(".\n");
    sleep(1);
    printf("판매 종료!\n");
    sleep(1);
    printf("%s는 %s%d장이 팔렸다!\n", g[gameCounter].title, averageScore/10>=8 ? "무려 " : "" , g[gameCounter].sales);
    getchar();

    return g[gameCounter].sales;
}

void calcCapital(Company *c, Game g[], long soldCopies)
{
    long earnings = soldCopies * g[gameCounter].price;
    c->capital += earnings;
    printf("%s사는 게임판매 수익 %ld원으로, 자본금이 %ld원이 되었다!\n", c->name, earnings, c->capital);
}

void printReleasedGames(Company *c, Game g[])
{
    if(c->numOfReleasedGames==0)
    {
        printf("아직 출시 한 게임이 없습니다.\n");
        sleep(1);
        return;
    }

    int i;
    putchar('\n');
    printf("%s사가 지금까지 출시 한 게임\n", c->name);
    printf("──────────────────────────────────────────────────────────────\n");
    printf(" %s\t %10s\t %s\t %s\t %s\n", "번호", "이름", "개발기간", "메타스코어", "판매량");
    printf("──────────────────────────────────────────────────────────────\n");

    for(i=0;i<c->numOfReleasedGames;i++)
        printf(" %2d\t %10s\t %2d개월\t\t %2d점\t\t %d장\n", i+1, g[i].title, g[i].developmentPeriod, g[i].metaScore, g[i].sales);
}

void printEnding(Company *c, int isBankruptcy)
{
    // 파산 엔딩
    if(isBankruptcy)
    {
        printf("%s사는 %ld원의 빚덩이에 쌓여,\n", c->name, c->capital);
        sleep(1);
        printf("결국 파산하고 말았다...\n");

    }
    // 손해 엔딩
    else if(!isBankruptcy && INITIAL_CAPITAL > c->capital)
    {
        printf("%ld원의 자본금으로 시작한 %s사는, %ld원의 손해를 보고,\n", INITIAL_CAPITAL, c->name, INITIAL_CAPITAL-c->capital);
        sleep(1);
        printf("결국 머기업에 매각되고 말았다...\n");
    }
    // 이득 엔딩
    else if(!isBankruptcy && INITIAL_CAPITAL < c->capital)
    {
        printf("%ld원의 자본금으로 시작한 %s사는, %ld원의 수익을 얻고,\n", INITIAL_CAPITAL, c->name, c->capital - INITIAL_CAPITAL);
        sleep(1);
        printf("머기업에 매각하여 부자가 되었다!\n");
    }
    // 본전 엔딩
    else if(!isBankruptcy && INITIAL_CAPITAL == c->capital)
    {
        printf("%ld원의 자본금으로 시작한 %s사는 손해도 수익도 없이...\n", INITIAL_CAPITAL, c->name);
        sleep(1);
        printf("갑자기 회사 문을 닫았다...\n");
    }

    exit(1);
}
