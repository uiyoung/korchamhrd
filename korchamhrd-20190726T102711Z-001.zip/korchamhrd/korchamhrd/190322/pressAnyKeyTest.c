#include <stdio.h>

int main()
{
    printf("press any key to continue\n");
    getchar();
    puts("sdf");

    return 0;
}
