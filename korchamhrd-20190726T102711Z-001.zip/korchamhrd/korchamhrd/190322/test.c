#include <stdio.h>
#include <time.h>
#include <stdlib.h>

typedef struct student
{
    char name[20];
    int no;
} Student;

void printStudents(Student s[])
{
    printf("%s\n", s[0].name);
}

int main()
{
    Student students[]={{"aaa",1},{"bbb",2},{"ccc",3}};

    printStudents(students);

    return 0;
}
