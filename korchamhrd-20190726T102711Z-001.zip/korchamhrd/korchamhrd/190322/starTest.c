#include <stdio.h>

int main()
{
    int i;

    double workSpeed = 0.4; 
    int filledStars = (int)(workSpeed*10/2);

    for(i=0;i<5;i++)
        printf("%s", i<filledStars ? "★" : "☆");

    putchar('\n');
    
    double diligence = 0.4;
    int emptyCircles = (int)(diligence*10+1)/2;
    int filledCircles = 5-emptyCircles;

    for(i=0;i<5;i++)
        printf("%s", i<filledCircles ? "●" : "○");

    putchar('\n');

    return 0;
}

    
