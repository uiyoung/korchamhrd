#include <stdio.h>

int main()
{
    long a = 30000;
    long b = 3000;
    long c = 10000;
    long d = 50000;

    printf("1. %ld\n", a*b);
    printf("2. %ld\n", a*c);
    printf("3. %ld\n", a*d);

    return 0;
}
