#include <stdio.h>

int main()
{
    int numbers[6];


    for(int i=0;i<sizeof(numbers)/sizeof(int);i++)
    {
        printf("로또번호 입력>>");
        scanf("%d", &numbers[i]);

        for(int j=0;j<i;j++)
        {
            if(numbers[j] == numbers[i])
            {
                puts("같은 번호가 있습니다!");
                i--;
                continue;
            }
        }
    }

    //print
    printf("입력된 로또 번호 : ");
    
    for(int i=0;i<sizeof(numbers)/sizeof(int);i++)
        printf("%d ", numbers[i]);

    putchar('\n');

    return 0;
}

