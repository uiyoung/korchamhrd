#include <stdio.h>

int main()
{
    char str[100];
    int count = 0;

    printf("문장 입력>>");

    fgets(str, sizeof(str), stdin);

    for(int i=0;i<sizeof(str)-1;i++)
    {
        if(str[i]>'A' && str[i]<'Z')
        {
            str[i]+=32;
            count++;
        }
    }
    
    printf("바뀐 문장: %s\n", str);

    printf("바뀐 문자 수 : %d\n", count);
    return 0;
}
