#include <stdio.h>

int main()
{
    int scores[5];
    int sum=0;

    printf("5명 심사위원의 점수 입력>>");
    for(int i=0;i<sizeof(scores)/sizeof(int);i++)
    {
        scanf("%d", &scores[i]);
    }

    // sort
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4-i;j++)
        {
            if(scores[j]<scores[j+1])
            {
                int temp = scores[j];
                scores[j] = scores[j+1];
                scores[j+1] = temp;
            }
        }
    }
        
    // print 유효점수
    printf("유효점수 : ");
    for(int i=1;i<sizeof(scores)/sizeof(int)-1;i++)
    {
        sum += scores[i];
        printf("%d ", scores[i]);
    }

    putchar('\n');

    // print average
    printf("평균 : %.1lf\n", (double)sum/3);


    return 0;
}
