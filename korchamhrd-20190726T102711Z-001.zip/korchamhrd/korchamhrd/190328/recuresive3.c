#include <stdio.h>

void printStars(int x, int y, int num);

int main()
{
    int num;
    printf("숫자 입력>>");
    scanf("%d", &num);

    printStars(1,1, num);

    return 0;
}

void printStars(int x, int y, int num)
{
    printf("*");
    
    if(x==y)
    {
        putchar('\n');
        printStars(1, y+1, num);
    }
    else
    {
        if(y==num)
            return;

        printStars(x+1, y, num);
    }
}
