#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printStars(int x, int y, int num);

int main()
{
    int num;
    srand(time(NULL));
    num = rand()%20+1;

    printStars(1, 1, num);

    return 0;
}

void printStars(int x, int y, int num)
{
    printf("*");
    
    if(x==y)
    {
        putchar('\n');
        printStars(1, y+1, num);
    }
    else
    {
        if(y==num)
            return;

        printStars(x+1, y, num);
    }
}
