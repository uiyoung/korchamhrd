#include <stdio.h>

void printTable(int m, int n);

int main()
{
    int num;
    printf("단 입력>>");
    scanf("%d", &num);
    printTable(num, 1);

    return 0;
}

void printTable(int m, int n)
{
    printf("%d * %d = %d\n", m, n, m*n);

    if(n==9)
        return;

    printTable(m, n+1);
}
