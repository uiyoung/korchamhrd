#include <stdio.h>

void PrintTimesTable(int m, int n);

int main()
{
    PrintTimesTable(2, 1);

    return 0;
}

void PrintTimesTable(int m, int n)
{
    printf("%d * %d = %d\n", m, n, m*n);

    if(m==9 && n==9)
        return;

    if(n<9)
        PrintTimesTable(m, n+1);
    else
        PrintTimesTable(m+1, 1);
}
