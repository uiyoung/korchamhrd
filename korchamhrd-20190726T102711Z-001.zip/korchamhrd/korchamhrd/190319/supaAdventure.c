#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>

typedef struct _monster
{
    char name[20];
    int maxHP;
    int currentHP;
    int minDamage;
    int maxDamage;
    int escapeSuccessRate;  // 도망 성공률
    int reward;
} Monster;

typedef struct _player
{
    char name[20];
    int maxHP;
    int currentHP;
    int minDamage;
    int maxDamage;
    int remainingPotions;   //포션 소지 갯수
} Player;

void showMenu(Player *p, Monster *m);
void battle(Player *p, Monster *m);
void attackEnemy(Player *p, Monster *m);
void attackPlayer(Player *p, Monster *m);
void takeHealingPotion(Player *p, Monster *m);
void showPlayerStatus(Player *p);
void showEnemyStatus(Monster *m);
void victory(Player *p, Monster *m);
void escape(Player *p, Monster *m);
void defeat(Player *p, Monster *m);
void reward(Player *p, Monster *m);
void move();
void ending(Player *p);

int isVictory, isDefeat, isEscape;
int victoryCounter, escapeCounter;

int main()
{
    int i, choice;
    char playerName[20];
    srand(time(NULL));

    Monster monsters[] = {
        {.name ="복이", .maxHP=500, .currentHP=500, .minDamage=10, .maxDamage=100, .escapeSuccessRate=50, .reward = 300}, 
        {.name ="땅복이", .maxHP=700, .currentHP=700, .minDamage=30, .maxDamage=300, .escapeSuccessRate = 30, .reward = 500}, 
        {.name ="킹복이", .maxHP=1500, .currentHP=1500, .minDamage=30, .maxDamage=500, .escapeSuccessRate=15, .reward = 1000}
    };
    
    Player player = {" ", 250, 250, 10, 500, 10};
//    player.maxHP = 250;
//    player.currentHP = 250;
//    player.minDamage = 10;
//    player.maxDamage = 500;
//    player.remainingPotions = 10;

    printf("player 이름 입력>>");
    scanf("%s", playerName);
    strcpy(player.name, playerName);

    printf("%s은(는) 단검 한자루와 포션%d개를 가지고 \n전설의 킹복이를 무찌르기 위해 여행을 떠났다.\n", player.name, player.remainingPotions);
    sleep(1);

    for(i=0;i<sizeof(monsters)/sizeof(monsters[0]);i++)
    {
        isVictory = 0;
        isDefeat = 0;
        isEscape = 0;

        move();
        printf("%s(은)는 %s와 마주쳤다.\n", player.name, monsters[i].name);
        sleep(1);
        
        while(!isVictory && !isDefeat && !isEscape)
        {
            showPlayerStatus(&player);
            showEnemyStatus(&monsters[i]);
            showMenu(&player, &monsters[i]);
            scanf("%d", &choice);
            
            switch(choice)
            {
                case 1:
                    battle(&player, &monsters[i]);
                    
                    break;
                case 2:
                    takeHealingPotion(&player, &monsters[i]);

                    break;
                case 3:
                    escape(&player, &monsters[i]);
                    
                    break;
                default:
                    printf("올바른 선택지를 골라주세요\n");
                    break;
            }
        }

        if(isVictory)
            reward(&player, &monsters[i]);

        if(victoryCounter+escapeCounter>=sizeof(monsters)/sizeof(monsters[0]))
            ending(&player);
   }

    return 0;
}

void showMenu(Player *p, Monster *m)
{
    printf("--------------------------------------\n");
    printf("어떻게 할까?\n");
    printf("1. 공격\n");
    printf("2. 힐링포션 복용(남은갯수:%d)\n", p->remainingPotions);
    printf("3. 도망(성공률:%d%%)\n", m->escapeSuccessRate);
    printf(">>");
}

void battle(Player *p, Monster *m)
{
    printf("------------%s vs %s ------------ \n", p->name, m->name); 
    if(!isDefeat)
    {
        attackEnemy(p, m);
        sleep(1);
    }

    if(!isVictory)
    {
        attackPlayer(p, m);
        sleep(1);
    }

    printf("--------------------------------------\n");
}

void attackEnemy(Player *p, Monster *m)
{
    int damage = rand() % p->maxDamage + p->minDamage;
    m->currentHP -= damage;
    printf("%s은(는) %s에게 %d만큼의 피해를 입혔다!\n", p->name, m->name, damage); 

    if(m->currentHP < 0)
        m->currentHP = 0;
    
    if(m->currentHP <= 0)
    {
        victory(p, m);
    }
}

void attackPlayer(Player *p, Monster *m)
{
    int damage = rand() % m->maxDamage + m->minDamage;
    p->currentHP -= damage;
    printf("%s은(는) %s에게 %d만큼의 피해를 입혔다!\n", m->name, p->name, damage); 
    
    if(p->currentHP < 0)
        p->currentHP = 0;
    
    if(p->currentHP <= 0)
    {
        defeat(p, m);
        isDefeat = 1;
    }
}

void takeHealingPotion(Player *p, Monster *m)
{
    if(p->remainingPotions <=0)
    {
        printf("남은 힐링포션이 없다...\n");
        sleep(1);
        return;
    }
    
    if(p->currentHP >= p->maxHP)
    {
        printf("이미 최대 체력이다.\n");
        sleep(1);
        return;
    }

    p->remainingPotions--;

    int recoverAmount = rand()%500+100;
    
    p->currentHP += recoverAmount;

    if(p->currentHP > p->maxHP)
        p->currentHP = p->maxHP;

    printf("힐링포션을 복용하여 %d만큼의 체력이 회복되었다.\n", recoverAmount);
    sleep(1);
    showPlayerStatus(p);
    sleep(1);
    printf("포션을 마시는 사이, %s가 기습공격을 했다!\n", m->name);
    sleep(1);
    attackPlayer(p, m);
    sleep(1);
}

void showPlayerStatus(Player *p)
{
    printf("- %s(HP:%d/%d)\n", p->name, p->currentHP, p->maxHP);
}

void showEnemyStatus(Monster *m)
{
    printf("- %s(HP:%d/%d)\n", m->name, m->currentHP, m->maxHP);
}

void victory(Player *p, Monster *m)
{
    isVictory = 1;
    victoryCounter++;

    printf("\n");
    printf("%s은(는) %s를 물리쳤다!\n", p->name, m->name);
}

void defeat(Player *p, Monster *m)
{
    printf("\n");
    printf("%s은(는) %s에게 당하고 말았다...\n", p->name, m->name);
    sleep(1);
    printf("--------------------------------------\n");
    exit(1);
}

void escape(Player *p, Monster *m)
{
    if(rand() % 100 + 1 <= m->escapeSuccessRate) 
    {
        printf("%s은(는) %s에게서 겨우 도망쳤다!!\n", p->name, m->name);
        isEscape = 1;
        sleep(1);
        escapeCounter++;
    }
    else
    {
        printf("%s은(는) %s에게서 도망치는데 실패했다!!\n", p->name, m->name);
        sleep(1);
        attackPlayer(p, m);
        printf("도망가려는 사이, %s가 기습공격을 했다!\n", m->name);
        sleep(1);

    }
    printf("--------------------------------------\n");
}

void move()
{
    printf("이동중...\n");
    sleep(1);
    printf(".\n");
    sleep(1);
    printf(".\n");
    sleep(1);
}

void reward(Player *p, Monster *m)
{
    p->maxHP += m->reward;
    printf("%s은(는) %s를 물리쳐 최대HP가 %d만큼 증가했다!\n", p->name, m->name, m->reward); 
}

void ending(Player *p)
{
    if(victoryCounter>=3)
        printf("용사 %s은(는) 모든 복이들을 물리쳤기 때문에 더 이상의 남은 과제가 없다고 한다.\n", p->name);
    else if(escapeCounter>=3)
        printf("용사 %s은(는) 모든 복이들에게서 도망쳐 더 이상 남은 과제가 없다고 한다.\n", p->name);
    else
        printf("용사 %s은(는) 전투에서 %d번의 전투에서 승리를 거두고, %d번의 전투에서 도망치는데 성공해 더 이상 남은 과제가 없다고 한다.", p->name, victoryCounter, escapeCounter); 
}
