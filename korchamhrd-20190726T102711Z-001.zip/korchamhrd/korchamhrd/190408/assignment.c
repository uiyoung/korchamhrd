#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void RandomizeScores(int* scores, int size);
void PrintScores(int* scores, int size);
int CalcAverage(int* scores, int size);

int main()
{
    int scores[10];
    srand(time(NULL));

    RandomizeScores(scores, sizeof(scores)/sizeof(int));
    PrintScores(scores, sizeof(scores)/sizeof(int));
    printf("average : %d점\n", CalcAverage(scores, sizeof(scores)/sizeof(int)));

    return 0;
}

void RandomizeScores(int* scores, int size)
{
    for(int i=0;i<size;i++)
        scores[i] = rand()%100+1;
}

void PrintScores(int* scores, int size)
{
    for(int i=0;i<size;i++)
        printf("%d과목 : %d점\n", i+1, scores[i]);
}

int CalcAverage(int* scores, int size)
{
    int sum = 0;
    for(int i=0;i<size;i++)
        sum += scores[i];

    return sum/size;
}
