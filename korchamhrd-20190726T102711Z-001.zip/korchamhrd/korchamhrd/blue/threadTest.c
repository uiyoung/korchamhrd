#include <stdio.h> 
#include <stdlib.h> 
#include <pthread.h> 
 
void *CountThread(void *); 
void *SumThread(void *); 
 
int main(void) 
{ 
    int num; 
    int result[2]; 
    int i, rc; 
    pthread_t threads[2]; 
     
    printf("input number : "); 
    scanf("%d", &num); 
     
    pthread_create(&threads[0], NULL, &CountThread, (void *)&num); //Count를 할 Thread함수를 threads[0]에서 실행(인자값은 num) 
    pthread_create(&threads[1], NULL, &SumThread, (void *)&num); //Sum을 구할 Thread함수를 threads[1]에서 실행(인자값은 num) 
     
    for(i = 0; i < 2; i++) 
    { 
        rc = pthread_join(threads[i], (void **)&result[i]); 
         
        if(rc != 0) //rc가 0이 아니면 오류 발생 
        { 
            printf("Error in thread[%d] : %d\n", i, rc); 
            exit(1); 
        } 
    } 
     
    printf("Result of CountThread : %d\n", result[0]); 
    printf("Result of SumThread : %d\n", result[1]); 
     
    return 0; 
} 
 
void *CountThread(void *arg) 
{ 
    int i; 
    int num = *(int *)arg; //인자값을 사용해야할 때마다 일일이 void* 포인터에서 int* 포인터로 바꿔줘야 해서 귀찮아지므로 그냥 변수를 하나 만들어서 인자값을 넣어줌 
     
    for(i = 1; i <= num; i++) 
    { 
        printf("In CountThread(0x%lx) : %d\n", pthread_self(), i); 
        usleep(1000); 
    } 
     
    printf("CountThread End\n"); 
    pthread_exit(NULL); //인자값을 return하고 Thread함수 종료 
} 
 
void *SumThread(void *arg) 
{ 
    int result, i; 
    int num = *(int *)arg; 
     
    for(result = 0, i = 1; i <= num; i++) 
        result += i; 
     
    printf("SumThread End\n"); 
    pthread_exit((void *)result); //인자값을 return하고 Thread함수 종료(인자값이 void형 포인터로 들어가므로 void형 포인터로 형변환) 
} 
