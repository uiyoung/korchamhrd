#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    time_t start, end;
    int count;

    start = time(NULL);

    while(1)
    {
        end = time(NULL);
        double elapsedTime = end-start;

        system("clear");
        printf("%lf\n", elapsedTime);

        if(elapsedTime >=5)
            break;

        usleep(100000);
        count++;
    }

    return 0;
}
