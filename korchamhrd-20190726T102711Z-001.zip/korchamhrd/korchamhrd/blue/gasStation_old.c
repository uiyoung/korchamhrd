#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>	//getch()함수 블러오기 위한 헤더파일 (리눅스 라이브러리)
#include <time.h>

void Tutorial();
void PrintGasPump();
void GasStation();
void InitGas(char gas[][10]);
int PrintFuelStatus(char gas[][10], int count, int goal);
void FillGas(char gas[][10], int *put);
void LeakGas(char gas[][10], int *put);
int getch();
int kbhit();

int main()
{
    int money;
    int max_oil;    //최대 주유량
    int oil;    // 현재 주유량

    srand(time(NULL));
    GasStation(&oil, max_oil);
    // todo : 리터당 가격 리턴

    return 0;
}

void GasStation(int *gas, int maxGas)
{
    char gasoline[30][10];
    int amount = 0;
    int timer = 700;
    int goal = rand()%28+1;

    //Tutorial();

    InitGas(gasoline);

    while(1)
    {	
        if(kbhit())
        {
            if(getch()==32) //32:space
            {
                FillGas(gasoline, &amount);
                PrintFuelStatus(gasoline, timer, goal);
            }
        }

        usleep(10000);
        timer--;

        if(timer<0)
            break;

        if(timer%10==0)
        {
            LeakGas(gasoline, &amount);
            PrintFuelStatus(gasoline, timer, goal);
        }   
    }

    printf("%d\n", amount);

    // 기름 풀로 채우기
    *gas = maxGas;

    // todo : 기름값 지불(리터당 계산)
    // todo : 예외처리 돈이 없는 경우

}

void Tutorial()
{
    system("clear");
    PrintGasPump();
    puts("space키를 누르고 있으면 기름이 찹니다.");
    sleep(1);
    puts("남은시간 내에 GOAL에 최대한 가깝게 기름을 채워주세요.");
    sleep(1);
    puts("GOAL에 가까울 수록, 리터당 가격이 내려갑니다.");
    sleep(1);
    printf("(Press any key to start)\n");
    getch();
}

void PrintGasPump()
{
    printf("          _____\n");
    printf("        _[_____]_\n");
    printf("       |---------|\n");
    printf("       |#### ####|\\\n");
    printf("       |...   ...|\\\\\n");
    printf("       |_________|((|\n");
    printf("       |.-------.| ||\n");
    printf("       ||       || []\n");
    printf("       ||   G   ||  #\n");
    printf("       ||   A   || ,#\n");
    printf("       ||   S   || #'\n");
    printf("       ||       ||#'\n");
    printf("       ||       ||'\n");
    printf("     __|'-------'|__\n");
    printf("    [_______________]\n");
}

void InitGas(char gas[][10])
{
    for(int i=0;i<30;i++)
        for(int j=0;j<10;j++)
            gas[i][j]=' ';
}

int PrintFuelStatus(char gas[][10], int timer, int goal)
{
    system("clear");
    printf("남은시간:%d\n", timer);
    printf("\t\t ==============\n");
    for(int i=0;i<30;i++)
    {
        printf("\t\t ││");
        for(int j=0;j<10;j++)
        {
            printf("%c", gas[i][j]);
        }
        printf("││");

        if(i==goal)
            printf("<< GOAL");
        putchar('\n');

    }
    printf("\t\t ==============\n");
    printf("스페이스를 눌러 남은시간 내에 GOAL에 가깝게 기름을 채워 주세요.\n");
}

void FillGas(char gas[][10], int *put)
{
    for(int i=0;i<10;i++)
        gas[29-*put][i]='#';

    (*put)++;

    if(*put>=29)
        *put=29;
}

void LeakGas(char gas[][10],int *put)
{
    for(int i=0;i<10;i++)
        gas[29-*put][i]=' ';

    (*put)--;

    if(*put<=0)
        *put=0;
}

int getch()			
{
    int ch;
    struct termios buf, save;
    tcgetattr(0,&save);
    buf = save;
    buf.c_lflag &= ~(ICANON|ECHO);
    buf.c_cc[VMIN] = 1;
    buf.c_cc[VTIME] = 0;
    tcsetattr(0, TCSAFLUSH, &buf);
    ch = getchar();
    tcsetattr(0, TCSAFLUSH, &save);

    return ch;
}

int kbhit()
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if(ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}
