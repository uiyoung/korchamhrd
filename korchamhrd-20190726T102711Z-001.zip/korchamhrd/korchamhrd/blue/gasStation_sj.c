#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>	//getch()함수 블러오기 위한 헤더파일 (리눅스 라이브러리)

void GasStation();
void InitGas(char gas[][6]);
int PrintFuelStatus(char gas[][6], int count);
void FillGas(char gas[][6], int *put);
void LeakGas(char gas[][6], int *put);
int getch();   //getch 함수 엔터키 입력 값 받아 오기 위한 함수 (인터넷 참조)https://www.hackerschool.org/HS_Boards/zboard.php?id=Free_Board&page=20&sn1=&divpage=4&sn=off&ss=on&sc=on&select_arrange=headnum&desc=asc&no=23480
int kbhit();  //출처: https://corsa.tistory.com/18 [CORSA]

int main()
{
    GasStation();

    return 0;
}

void GasStation()
{
    char gasoline[20][6];
    int amount = 0;
    int timer = 500;

    printf("아무키나 눌러 시작하세요.\n");
    getch();

    InitGas(gasoline);

    while(1)
    {	
        if(kbhit()==1)
        {
            int a = getch();	
            int b = getch();

            // 32:space, 10:enter
            if(((a==32)&&(b==10))||((a==10)&&(b==32)))
            {
                FillGas(gasoline, &amount);
                PrintFuelStatus(gasoline, timer);
            }
        }

        //usleep(20000);
        // todo : 속도 10~15 * 1000
        usleep(15000);
        timer--;

        if(timer<0)
            break;

        if(timer%10==0)
        {
            LeakGas(gasoline, &amount);
            PrintFuelStatus(gasoline, timer);
        }   
    }

    printf("%d\n", amount);
}

void InitGas(char gas[][6])
{
    for(int i=0;i<20;i++)
        for(int j=0;j<6;j++)
            gas[i][j]=' ';
}

int PrintFuelStatus(char gas[][6], int count)
{
    system("clear");
    printf("\t ==========\n");
    for(int i=0;i<20;i++)
    {
        printf("\t ││");
        for(int j=0;j<6;j++)
        {
            printf("%c", gas[i][j]);
        }
        printf("││\n");
    }
    printf("\t ==========\n");
    printf("남은시간:%d\n", count);
    printf("엔터와 스페이스를 연타하여 남은시간 내에 기름을 넣어 주세요.\n");
}

void FillGas(char gas[][6],int *put)
{
    for(int i=0;i<6;i++)
        gas[19-*put][i]='#';

    (*put)++;

    if(*put>=19)
        *put=19;
}

void LeakGas(char gas[][6],int *put)
{
    for(int i=0;i<6;i++)
        gas[19-*put][i]=' ';

    (*put)--;

    if(*put<=0)
        *put=0;
}

int getch()			
{
    int ch;
    struct termios buf, save;
    tcgetattr(0,&save);
    buf = save;
    buf.c_lflag &= ~(ICANON|ECHO);
    buf.c_cc[VMIN] = 1;
    buf.c_cc[VTIME] = 0;
    tcsetattr(0, TCSAFLUSH, &buf);
    ch = getchar();
    tcsetattr(0, TCSAFLUSH, &save);

    return ch;
}

int kbhit()
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if(ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}
