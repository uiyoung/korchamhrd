#include <stdio.h>

int main()
{
    int i, j;
    int num;

    printf("숫자 입력>>");
    scanf("%d", &num);

    for(i=0;i<num;i++)
    {
        for(j=0;j<i+1;j++)
        {
            printf("*");
        }
        printf("\n");
    }
    
    for(i=num-1;i>0;i--)
    {
        for(j=i;j>0;j--)
        {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}
