#include <stdio.h>

int main()
{
    int a, b;

    printf("a, b 입력>>");
    scanf("%d%d", &a, &b);

    pritnf("%d", a > b ? a : b);

    return 0;
}
