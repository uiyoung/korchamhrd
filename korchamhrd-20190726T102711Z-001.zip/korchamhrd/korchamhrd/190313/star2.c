#include <stdio.h>

int main()
{
    int i, j;
    int num;

    printf("원하는 별 갯수 입력>>");
    scanf("%d", &num);

    for(i=0;i<num;i++)
    {
        for(j=0;j<=i;j++)
        {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}
