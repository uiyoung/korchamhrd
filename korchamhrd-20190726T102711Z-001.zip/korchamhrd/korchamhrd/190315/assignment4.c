#include <stdio.h>

int factorial(int a);

int main()
{
    int num;

    printf("숫자입력>>");
    scanf("%d", &num);
    
    printf("%d! = %d\n", num, factorial(num));

    return 0;
}

int factorial(int a)
{
    int result;
    if(a==1)
        result = 1;
    else
        result = a * factorial(a-1);
}


