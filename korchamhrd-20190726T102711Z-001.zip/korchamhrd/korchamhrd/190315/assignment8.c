#include <stdio.h>

int main()
{
    int i;
    int num1, num2;

    printf("숫자 두 개 입력>>");
    scanf("%d%d", &num1, &num2);
    
    for(i=1;i<=num1;i++)
    {
        if(num1%i==0 && num2%i==0)
            printf("%d\n", i);
    }


    return 0;
}

