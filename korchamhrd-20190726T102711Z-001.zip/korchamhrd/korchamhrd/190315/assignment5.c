#include <stdio.h>

int main()
{
    int i, j, n;
    int k = 0;
    int counter;
    
    printf("구구단 전체를 출력하는 프로그램입니다.\n");

    for(n=0;n<2;n++)
    {
        for(j=2+4*n;j<=5+4*n;j++)
            printf("  -%d단-   \t", j);

        printf("\n");
        
        for(i=1;i<=9;i++)
        {
            for(j=2+4*n;j<=5+4*n;j++)
            {
                printf("%d × %d = %d\t", j, i, i*j);
            }
            printf("\n");
        }
        counter++;
    }
    return 0;
}
