#include <stdio.h>

int main()
{
    int i,j;
    int num;
    int result=1;
    
    printf("숫자입력>>");
    scanf("%d", &num);

    for(i=2;i<=num;i++)
    {
        result = 1;
        
        for(j=2;j<i;j++)
        {
            if(i%j==0)
            {
                result = 0;
                break;
            }
        }
        
        if(result)
            printf("%d\n", i);
    }

    return 0;
}
