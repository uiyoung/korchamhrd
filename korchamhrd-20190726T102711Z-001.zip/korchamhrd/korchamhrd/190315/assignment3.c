#include <stdio.h>

int main()
{
    int num;
    int counter=0;
    int i;

    printf("1이상 숫자입력>>");
    scanf("%d", &num);
    
    for(i=1;counter<num;i++)
    {
        if(num%2!=0 && i%2==0)
            continue;
        else if(num%2==0 && i%2!=0)
            continue;
        
        printf("%d\n", i);
        counter++;
    }

    return 0;
}

