#include <stdio.h>

int main()
{
    int i, num;

    printf("숫자입력>>");
    scanf("%d", &num);

    printf("짝수 : ");
    for(i=1;i<=num;i++)
    {
        if(i%2!=0)
            continue;
        
        printf("%d ", i);
    }

    printf("\n");

    printf("홀수 : ");
    for(i=1;i<=num;i++)
    {
        if(i%2==0)
            continue;
        
        printf("%d ", i);
    }
    printf("\n");

    return 0;
}

