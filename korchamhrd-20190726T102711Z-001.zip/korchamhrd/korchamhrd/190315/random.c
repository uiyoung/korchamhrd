#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    const int RANGE = 50;
    int numbers[10] = {0};
    int i,j;
    
    //generate random number and check duplication
    srand(time(NULL));
    for(i=0;i<sizeof(numbers)/sizeof(numbers[0]);i++)
    {
        numbers[i] = (rand() % RANGE) + 1;
        
        for(j=0;j<i;j++)
        {
            if(numbers[j]==numbers[i])
            {
                i--;
                break;
            }
        }
    }

    // print 10 random numbers
    for(i=0;i<sizeof(numbers)/sizeof(numbers[0]);i++)
    {
        printf("%d ", numbers[i]);
    }

    printf("\n------------------------------------------------\n");

    //print stars
    for(i=0;i<sizeof(numbers)/sizeof(numbers[0]);i++)
    {
        printf("%2d : ", numbers[i]);
        for(j=0;j<numbers[i];j++)
        {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}

