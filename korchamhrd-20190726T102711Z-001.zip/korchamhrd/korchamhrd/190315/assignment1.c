#include <stdio.h>

int main()
{
    int num;
    printf("숫자입력>>");
    scanf("%d", &num);

    printf("%s입니다.\n", num%2==0 ? "짝수" : "홀수");
        
    return 0;
}

