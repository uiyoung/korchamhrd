#include <stdio.h>
#include <string.h>

int main()
{
    int i;
    int flag = 0;
    int answer;
    char ordered[128] = "";
    char noodles[][50] = {"라면", "잔치국수", "오뎅라면", "치즈라면", "비빔국수", "해장라면", "해물라면", "우동"};
    char soups[][50] = {"김치찌개", "된장찌개", "순두부찌개", "부대찌개", "고추장찌개"};
    char cutlets[][50] = {"돈가스", "왕돈가스", "수제돈가스", "치즈돈가스", "뒤진다돈가스", "생선가스", "치킨가스", "고구마치즈돈가스", "모둠돈가스"};
    char dotbaps[][50] = {"제육덮밥", "오징어덮밥", "불고기덮밥", "돈가스덮밥", "카레덮밥", "연어덮밥", "오므라이스"};
    char gimbaps[][50] = {"행복김밥", "야채김밥", "돈가스김밥", "참치김밥", "누드김밥", "계란말이김밥", "샐러드김밥", "왕김밥", "김치김밥", "땡초김밥", "진미김밥", "불고기김밥", "멸치김밥", "멸추김밥", "치즈김밥"};
    char drinks[][50] = {"콜라", "사이다", "환타", "옥수수수염차", "헛개차", "매실차"};

    printf("<다함께 김밥나라>\n");
    printf("1. 배가 고프다.\n2. 배가 부르다.\n>>");
    scanf("%d", &answer);

    if(answer == 1)
    {        
        printf("그럼 김밥나라에 가자.\n");
        printf("1. 친구랑 같이 간다.\n2. 혼자 간다.\n>>");
        scanf("%d", &answer);
        printf("%s\n", answer==1 ? "친구랑 같이 가자" : "혼자가자");
        
        do
        {
            printf("무엇을 주문할까?\n");
            printf("1. 면류를 먹는다.\n");
            printf("2. 찌개를 먹는다.\n");
            printf("3. 돈가스를 먹는다.\n");
            printf("4. 덮밥을 먹는다.\n");
            printf("5. 김밥을 먹는다.\n");
            printf("6. 음료수를 마신다.\n");
            printf("7. %s", flag==0 ? "별로인데 그냥 나간다.\n>>" : "취소\n>>");
            scanf("%d", &answer);
            
            switch(answer)
            {
                case 1:
                    for(i = 0; i < sizeof(noodles) / sizeof(noodles[0]); i++)
                    {
                        printf("%d. %s\n", i+1, noodles[i]);
                    }
                    printf(">>");
                    scanf("%d", &answer);
                    printf("%s를 주문했습니다.\n", noodles[answer-1]);
                    strcat(ordered, noodles[answer-1]);            
                    
                    break;
                case 2:
                    for(i = 0; i < sizeof(soups) / sizeof(soups[0]); i++)
                    {
                        printf("%d. %s\n", i+1, soups[i]);
                    }
                    printf(">>");
                    scanf("%d", &answer);
                    printf("%s를 주문했습니다.\n", soups[answer-1]);
                    strcat(ordered, soups[answer-1]);            

                    break;
                case 3:
                    for(i = 0; i < sizeof(cutlets) / sizeof(cutlets[0]); i++)
                    {
                        printf("%d. %s\n", i+1, cutlets[i]);
                    }
                    printf(">>");
                    scanf("%d", &answer);
                    printf("%s를 주문했습니다.\n", cutlets[answer-1]);
                    strcat(ordered, cutlets[answer-1]);            

                    break;
                case 4:
                    for(i = 0; i < sizeof(dotbaps) / sizeof(dotbaps[0]); i++)
                    {
                        printf("%d. %s\n", i+1, dotbaps[i]);
                    }
                    printf(">>");
                    scanf("%d", &answer);
                    printf("%s를 주문했습니다.\n", dotbaps[answer-1]);
                    strcat(ordered, dotbaps[answer-1]);            
                    
                    break;
                case 5:
                    for(i = 0; i < sizeof(gimbaps) / sizeof(gimbaps[0]); i++)
                    {
                        printf("%d. %s\n", i+1, gimbaps[i]);
                    }
                    printf(">>");
                    scanf("%d", &answer);
                    printf("%s를 주문했습니다.\n", gimbaps[answer-1]);
                    strcat(ordered, gimbaps[answer-1]);            

                    break;
               case 6:
                    for(i = 0; i < sizeof(drinks) / sizeof(drinks[0]); i++)
                    {
                        printf("%d. %s\n", i+1, drinks[i]);
                    }
                    printf(">>");
                    scanf("%d", &answer);
                    printf("%s를 주문했습니다.\n", drinks[answer-1]);
                    strcat(ordered, drinks[answer-1]);            
               
                    break;
               default:
                    break;
            }
            strcat(ordered, " ");
            printf("더 주문하시겠습니까(1.네 2.아니오)>>");
            scanf("%d", &answer);
            flag = answer==1 ? 1 : 0;
        }
        while(flag);

        printf("-----------------------------------------------------\n");
        printf("주문내역 : %s\n", ordered);
        printf("-----------------------------------------------------\n");
        printf("결재선택\n1. 카드\n2. 현금\n3. 탈주\n>>");
        scanf("%d", &answer);
        if(answer == 1)
            printf("치-치칙\n안녕히가세요\n");
        else if(answer == 2)
            printf("카-칭!\n안녕히가세요\n");
        else
            printf("철컹철컹\n");
    }   
    else
        printf("종료\n");

    return 0;
}
