#include <stdio.h>

int main()
{
    int a = 10, b = 20;

    if(a < 0)
    {
        if(b > 0)
            printf("ok");
    }
    else
        printf("ok");

    return 0;
}
