#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void randomCalc(int arr[], int size);

int main()
{
    srand(time(NULL));
    int arr[10];
    int counter = 1;
    int sum = 0; 

    // initialize array
    for(int i=0;i<sizeof(arr)/sizeof(int);i++)
        arr[i] = i+1;

    puts("배열의 모든 요소");
    puts("────────────────────────────────────");
    for(int i=0;i<sizeof(arr)/sizeof(int);i++)
    {
        printf("%2d. arr[%d]=%d\n", counter++, i, arr[i]);
    }
    putchar('\n');

    puts("배열의 모든 요소의 합");
    puts("────────────────────────────────────");
    for(int i=0;i<sizeof(arr)/sizeof(int);i++)
    {
        sum += arr[i];
    }
    printf("%2d. sum=%d\n", counter++, sum);
    putchar('\n');

    puts("배열 모든 요소의 평균");
    puts("────────────────────────────────────");
    printf("%2d. average=%d\n", counter++, sum/10);
    putchar('\n');

    puts("랜덤한 랜덤갯수 요소들의 랜덤연산");
    puts("────────────────────────────────────");
    for(int i=0;i<88;i++)
    {
        printf("%2d. ", counter++);
        randomCalc(arr, sizeof(arr)/sizeof(int));
    }

    return 0;
}

void randomCalc(int arr[], int size)
{
    int index[10];  // index저장 배열
    int opIndex[5];   // 0:+, 1:-, 2:*, 3:/, 4:%
    char opChars[] = {'+', '-', '*', '/', '%'};
    int numOfIndex = rand()%(size-2)+2; 
    int result=0;

    //initialize index
    for(int i=0;i<numOfIndex;i++)
        index[i] = rand()%size;

    //initialize operators
    for(int i=0;i<numOfIndex-1;i++)
        opIndex[i]=rand()%5;


    //print equations 
    for(int i=0;i<numOfIndex;i++)
    {
        if(numOfIndex!=2 && i==0)
        {
            for(int i=0;i<numOfIndex-2;i++)
                printf("(");
        }

        printf("arr[%d]", index[i]);

        if(i!=0 && numOfIndex!=2 && i != numOfIndex-1)
            printf(")");

        if(i != numOfIndex-1)
            printf("%c", opChars[opIndex[i]]);

    }

    //calc
    for(int i=0;i<numOfIndex-1;i++)
    {
        switch(opIndex[i])
        {
            case 0:
                if(i==0)
                    result = arr[index[i]] + arr[index[i+1]];
                else
                    result += arr[index[i+1]];

                break;
            case 1:
                if(i==0)
                    result = arr[index[i]] - arr[index[i+1]];
                else
                    result -= arr[index[i+1]];

                break;
            case 2:
                if(i==0)
                    result = arr[index[i]] * arr[index[i+1]];
                else
                    result *= arr[index[i+1]];

                break;
            case 3:
                if(i==0)
                    result = arr[index[i]] / arr[index[i+1]];
                else
                    result /= arr[index[i+1]];

                break;
            case 4:
                if(i==0)
                    result = arr[index[i]] % arr[index[i+1]];
                else
                    result %= arr[index[i+1]];

                break;
        }
    }
    //print calc result
    printf("=%d\n", result);
}
