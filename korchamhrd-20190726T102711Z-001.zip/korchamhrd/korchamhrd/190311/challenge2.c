#include <stdio.h>

int main()
{
    int tuition = 100;
    int rich = 150;
    double grade = 4.1;

    if((rich>=100) && (grade>4.0))
       tuition *= 0.8;
    else if(rich<100)
        tuition *= 0.4;

    printf("다음 학기 납입할 등록금은 %d만원 입니다.\n", tuition);
    
    return 0;
}
