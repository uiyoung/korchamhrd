#include <stdio.h>

int main()
{
    int a = 1;

    while(a < 10)
    {
        a *= 2;
    }

    printf("%d\n", a);

    return 0;
}
