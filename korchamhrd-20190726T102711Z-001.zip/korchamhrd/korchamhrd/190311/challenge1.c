#include <stdio.h>

int main()
{
    int x, y;
    char op;

    printf("사칙 연산 입력(정수)>>");
    scanf("%d%c%d", &x, &op, &y);

    switch(op)
    {
        case '+':
            printf("%d%c%d=%d\n", x, op, y, x+y);

            break;
        case '-': 
            printf("%d%c%d=%d\n", x, op, y, x-y);
            
            break;
        case '*': 
            printf("%d%c%d=%d\n", x, op, y, x*y);

            break;
        case '/': 
            printf("%d%c%d=%d\n", x, op, y, x/y);
            
            break;
        default:
            printf("올바른 사칙연산을 입력하세요\n");

            break;
    }

    return 0;
}
