#include <stdio.h>

int main()
{
    const double TAX = 0.09;
    double chargePerKw[] = {52, 88.5, 127.8, 184.3, 274.3, 494};
    int useOfElectricity;
    int basicCharge = 0;
    double totalCharge = 0;
    int i = 0;

    printf("전기 사용량을 입력하세요(kw)>>");
    scanf("%d", &useOfElectricity);

    if(useOfElectricity <= 100)
        basicCharge = 370;
    else if(useOfElectricity >= 101 && useOfElectricity <= 200)
        basicCharge = 660;
    else if(useOfElectricity >= 201 && useOfElectricity <= 300)
        basicCharge = 1130;
    else if(useOfElectricity >= 301 && useOfElectricity <= 400)
        basicCharge = 2710;
    else if(useOfElectricity >= 401 && useOfElectricity <= 500)
        basicCharge = 5130;
    else if(useOfElectricity > 500)
        basicCharge = 9330;
    
    while(useOfElectricity/100 > 0)
    {
        totalCharge += (chargePerKw[i] * 100);
        useOfElectricity -= 100;
        i < sizeof(chargePerKw) / sizeof(chargePerKw[0]) ? i++ : i;
    }
            
    totalCharge += (chargePerKw[i] * useOfElectricity); 
    totalCharge += basicCharge;
    totalCharge *= 1.09;

    printf("이번 달 요금은 %.0lf원 입니다.\n", totalCharge); 

    return 0;
}
