#include <stdio.h>

int main()
{
    int i, j;
    int num;
    
    printf("별 갯수>>");
    scanf("%d", &num);

    for(i=0;i<num/2+1;i++)
    {
        for(j=0;j<num/2+1+i;j++)
        {
            printf("%c", j<num/2-i ? ' ' : '*');
        }                    
        printf("\n");
    }
    
    for(i=1;i<num/2+1;i++)
    {
        for(j=0;j<num/2+i;j++)
        {
            if(j<i)
                printf(" ");
            else
                printf("*");
        }
        
        printf("\n");
    }

    return 0;
}
