#include <stdio.h>

int main()
{
    int i, j, input;
    int result = 1;
    int counter = 0;

    printf("2이상의 정수를 입력하세요>>");
    scanf("%d", &input);

    for(i=2;i<=input;i++)
    {
        result = 1;

        for(j=2;j<i;j++)
        {
            if(i%j==0)
            {
                result = 0;
                break;
            }
        }
        
        if(counter>4)
        {
            printf("\n");
            counter=0;
        }
        
        if(result)
        {
            printf("%d\t",i);
            counter++;
        }
    }

    printf("\n");
    
    return 0;
}
