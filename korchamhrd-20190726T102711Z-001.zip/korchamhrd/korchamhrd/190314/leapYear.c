#include <stdio.h>

int main()
{
	int year; 

	while(1)
{

	printf(">>");
	scanf("%d", &year);

	if(year%4==0)
	{
		if(year%400==0)
		{
			printf("leap\n");
		}
		else if(year%100==0)
		{
			printf("dont leap\n");
		}
		else
			printf("leap\n");
	}
	else
		printf("dont leap\n");
}
	return 0;
}
