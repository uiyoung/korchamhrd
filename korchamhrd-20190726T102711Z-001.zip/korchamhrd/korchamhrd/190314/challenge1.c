#include <stdio.h>

int main()
{
    const int ANSWER = 17;
    int input;
    int counter=0;

    while(1)
    {
        printf("숫자입력(1~30)>>");
        scanf("%d", &input);
        counter++;
    
        if(ANSWER == input)
        {
            printf("정답입니다!\n");
            printf("시도한 횟수는 %d회 입니다.\n", counter);

            break;
        }
        else
            printf("%d보다 %s\n", input, (ANSWER-input >0 ? "큽니다" :"작습니다")); 

    }
    
    return 0;
}
