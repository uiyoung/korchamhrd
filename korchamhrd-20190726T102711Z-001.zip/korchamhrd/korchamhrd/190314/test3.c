#include <stdio.h>

int main()
{
    int i,j;

    for(i=0;i<4;i++)
    {
        for(j=0;j<i+4;j++)
        {
            if(j<3-i)
               printf(" ");
            else
                printf("*");
        }
        printf("\n");
    }
    
    return 0;
}



