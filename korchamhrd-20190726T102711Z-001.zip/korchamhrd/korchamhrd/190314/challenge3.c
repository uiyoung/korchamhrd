#include <stdio.h>

int main()
{
    int year, month;
    int daysTillLastYear; // 1년1월1일~전년도까지 총 일수
    int daysOfThisYear; // 입력년도 1월1일부터 입력 월 1일까지 총 일수
    int totalDays; // 1년1월1일~입력한 년 월 1일까지 총일수
    int daysPerMonth[]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int startWeekName;
    int i, j;
    int counter;

    while(1)
    {
        // initialize
        daysTillLastYear=0;
        daysOfThisYear=0;
        totalDays=0;
        daysPerMonth[1]=28;
        counter=0;

        printf("년, 월을 입력하세요(종료는 0)>>");
        scanf("%d", &year);
        
        if(year==0)
            break;

        scanf("%d", &month);
        
        // 작년이 윤년이면 366, 아니면365씩 증가
        for(i=1;i<year;i++)
        {
            if((i%4==0 && i%100!=0) || i%400==0)
                daysTillLastYear += 366;
            else
                daysTillLastYear += 365;
        }

        //윤년이면 2월을 29일로 변경
        if((year%4==0 && year%100!=0) || year%400==0)
            daysPerMonth[1] = 29;
        
        // 입력년도 1월1일~지난달까지 총 일수   
        for(i=0;i<month-1;i++)
            daysOfThisYear += daysPerMonth[i];
        
        //1년1월1일~입력한 년 월의 1일까지의 총 일수
        totalDays = daysTillLastYear + daysOfThisYear + 1;

        // 해당월의 시작요일(총일수를 7로 나눈나머지)
        startWeekName = totalDays % 7;

        /* print calendar */
        printf("\n         %d년 %d월\n", year, month);
        printf("         ===========\n");
        printf("----------------------------\n");
        printf(" SUN MON TUE WED THU FRI SAT\n");
        printf("----------------------------\n");

        for(i=0;i<daysPerMonth[month-1];i++)
        {
            if(counter>6)
            {
                printf("\n");
                counter=0;
            }
            
            if(i==0 && startWeekName!=0)
            {
                // 시작 요일까지 공백 출력
                for(j=0;j<startWeekName;j++)
                {
                    printf("%4s", " ");
                    counter++;
                }
            }
            printf("%4d", i+1);
            counter++;
        }
        printf("\n");
    }        

    return 0;
}
