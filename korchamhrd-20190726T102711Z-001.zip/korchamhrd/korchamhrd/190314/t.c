#include <stdio.h>

int main()
{
    int i, j;
    int num=23;

    for(i=0;i<num/5;i++)
    {
        for(j=0;j<5;j++)
        {
            printf("a\t");

        }
        printf("\n");
    }

    return 0;
}

