#include <stdio.h>
#include <string.h>

int main()
{
    const char HOST[] = "박예은";
    const char NAMES[][16] = {"강진광", "고선주", "김경훈", "김규완", "김길환", "김다정", "김주현", "김태완", "김현서", "문선철", "박소희", "박예은", "박종화", "서의영", "심민선", "양승호", "오금성", "오유진", "오지구", "윤미정", "윤호영", "이효동", "장진혁", "정의인", "조민권"};
    const int NUM_OF_FRIENDS = sizeof(NAMES) / sizeof(NAMES[0]);
    const int ORDER = 3; // 차수

    char guests[ORDER][NUM_OF_FRIENDS][16];
    int i, j;
    int flag = 1;
    int choice, choice2;
    int count = 0;

    //initialize guests array
    for(i = 0 ; i < ORDER ; i++)
    {
        for(j = 0; j < NUM_OF_FRIENDS ; j++)
        {
            strcpy(guests[i][j], "");
        }
    }
    
    printf("<%s의 생일파티>\n", HOST);
    do
    {
        flag = 1;
        printf("\n1. 초대하기\n2. 그만두기\n>>");
        scanf("%d", &choice);
        if(choice == 2)
            break;

        // print friend list
        for(i=0 ; i < NUM_OF_FRIENDS ; i++)
        {
            printf("%d. %s ", i+1, NAMES[i]);
        }        
        printf("\n누구를 초대할까?>>");
        scanf("%d", &choice);
        if(strcmp(NAMES[choice-1], HOST) == 0)
            printf("아무리 초대할 사람이 없어도 내 자신을 초대할 순 없어...\n");
        else
        {
            for(i = 0 ; i < ORDER ; i++)
            {
                for(j = 0 ; j < NUM_OF_FRIENDS; j++)
                {
                    if(strcmp(guests[i][j], NAMES[choice-1]) == 0)
                    {
                        printf("%s은(는) 이미 초대했어.\n", NAMES[choice-1]);
                        flag = 0;
                        break;
                    }
                }
            }
            if(flag)
            {
                printf("그래 %s을(를) 초대하자.\n", NAMES[choice-1]);
                printf("몇차에 초대할까? (1~%d)>>", ORDER);
                scanf("%d", &choice2);
                strcpy(guests[choice2-1][count], NAMES[choice-1]);
                count++;
            }
        }
    }  
    while(1);

    // print invited guests
    printf("----------------------------------------------------\n");
    printf("초대된 사람 : %d명\n", count);
    for(i = 0 ; i < ORDER; i++)
    {
        printf("%d차 :", i+1);
        for(j = 0 ; j < NUM_OF_FRIENDS ; j++)
        {
            if(strcmp(guests[i][j], "") == 0)
                continue;

            printf(" %s", guests[i][j]);
        }
        printf("\n");
    }

    printf("\nHappy Birthday %s!\n", HOST);

    return 0;
}
