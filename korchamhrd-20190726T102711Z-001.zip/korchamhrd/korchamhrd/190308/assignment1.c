#include <stdio.h>
#include <string.h>

void order(int type, char menu[][16][50], int price[][16]);

int totalSum = 0; 
int count = 0;
char ordered[128] = "";

int main()
{
    int flag = 0;
    int numOfCompanion = 0;
    int answer;
    char menus[6][16][50] = {
        {"잔치국수", "그냥라면", "오뎅라면", "치즈라면", "비빔국수", "해장라면", "해물라면", "우동"},
        {"김치찌개", "된장찌개", "순두부찌개", "부대찌개", "고추장찌개"},
        {"돈가스", "왕돈가스", "수제돈가스", "치즈돈가스", "뒤진다돈가스", "생선가스", "치킨가스", "고구마치즈돈가스", "모둠돈가스"},
        {"제육덮밥", "오징어덮밥", "불고기덮밥", "돈가스덮밥", "카레덮밥", "연어덮밥", "오므라이스"},
        {"함께김밥", "행복김밥", "야채김밥", "돈가스김밥", "참치김밥", "누드김밥", "계란말이김밥", "샐러드김밥", "왕김밥", "김치김밥", "땡초김밥", "진미김밥", "불고기김밥", "멸치김밥", "멸추김밥", "치즈김밥"},
        {"콜라", "사이다", "환타", "옥수수수염차", "헛개차", "매실차"}
    };
    int prices[6][16] = {
        {3500, 2000, 3000, 3000, 3500, 4000, 4500, 3000}, //면류
        {4500, 4000, 4500, 5500, 5000}, //찌개류
        {5500, 7000, 7000, 6000, 12000, 6000, 6000, 6500, 5500, 7500}, //돈가스류
        {5000, 5000, 6000, 6500, 4500, 6000, 5000}, //덮밥류
        {1500, 1500, 2000, 3500, 3500, 3500, 3500, 3000, 5500, 2500, 3000, 3000, 4000, 3500, 4000, 3000}, //김밥류
        {1000, 1000, 1000, 1500, 1500, 1500} //음료
    };

    printf("<함께해요 행복해요 김밥나라2>\n");
    printf("1. 배가 고프다.\n2. 배가 부르다.\n>>");
    scanf("%d", &answer);

    if(answer == 1)
    {        
        printf("그럼 김밥나라에 가자.\n");
        printf("1. 혼자간다.\n2. 친구랑 간다.\n>>");
        scanf("%d", &answer);
        if(answer == 2)
        {
            printf("몇명이랑 갈까?>>");
            scanf("%d", &numOfCompanion);
            printf("%d명의 친구랑 가자.\n", numOfCompanion);
        }
        else
            printf("혼자 먹으러 가자.\n");
        
        do
        {
            printf("무엇을 먹을까?\n");
            printf("1. 면류를 먹는다.\n");
            printf("2. 찌개를 먹는다.\n");
            printf("3. 돈가스를 먹는다.\n");
            printf("4. 덮밥을 먹는다.\n");
            printf("5. 김밥을 먹는다.\n");
            printf("6. 음료수를 마신다.\n");
            printf("7. %s", flag==0 ? "별로인데 그냥 나간다.\n>>" : "취소\n>>");
            scanf("%d", &answer);
            
            switch(answer)
            {
                case 1:
                    order(answer, menus, prices);

                    break;
                case 2:
                    order(answer, menus, prices);

                    break;
                case 3:
                    order(answer, menus, prices);

                    break;
                case 4:
                    order(answer, menus, prices);
                    
                    break;
                case 5:
                    order(answer, menus, prices);

                    break;
               case 6:
                    order(answer, menus, prices);
               
                    break;
               default:
                    if(flag == 0)
                        return 0;

                    break;
            }
            strcat(ordered, " ");
            printf("더 주문하시겠습니까(1.네 2.아니오)>>");
            scanf("%d", &answer);
            flag = answer==1 ? 1 : 0;
        }
        while(flag);

        printf("-------------------------receipt-------------------------\n");
        printf("주문내역 : %s\n", ordered);
        if(count >= 3)
            printf("가격 : %d원(10%% 할인 적용)\n", totalSum *= 0.9);
        else
            printf("가격 : %d원\n", totalSum);
        printf("---------------------------------------------------------\n");
        
        if(numOfCompanion)
        {
            printf("누가 계산을 합니까?\n");
            printf("1. 내가 산다\n2. n빵을 한다.\n>>");
            scanf("%d", &answer);
            if(answer == 2)
               totalSum /= (numOfCompanion+1); 
        }

        printf("결제방법선택\n1. 카드\n2. 현금\n3. 탈주\n>>");
        scanf("%d", &answer);
        if(answer == 1)
            printf("치-치칙- %d원을 결제했습니다.\n안녕히가세요.\n", totalSum);
        else if(answer == 2)
            printf("카-칭! %d원을 결제했습니다.\n안녕히가세요.\n", totalSum);
        else
            printf("철컹철컹\n");
    }   
    else
        printf("종료\n");

    return 0;
}

void order(int type, char menu[][16][50], int price[][16])
{
    int i;
    int answer2;

    //print menu
    for(i = 0; i < 16 ; i++)
    {
        if(strcmp(menu[type-1][i], "\0") != 0)
            printf("%d. %s\n", i+1, menu[type-1][i]);
        else
            break;
    }
        printf(">>");
        scanf("%d", &answer2);
        totalSum += price[type-1][answer2-1];
        strcat(ordered, menu[type-1][answer2-1]);            
        printf("%s를 주문했습니다. 가격은 %d원 입니다.\n", menu[type-1][answer2-1], price[type-1][answer2-1]);
        count++;
}
