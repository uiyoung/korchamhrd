#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    srand(time(NULL));
    int i;
    for(i=0;i<100;i++)
    {
        printf("%d\n", rand()%5000000+1);
    }
    return 0;
}

