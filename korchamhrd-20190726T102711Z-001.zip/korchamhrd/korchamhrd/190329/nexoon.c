#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>

const int SALARY = 500; // 급여
const int BANKRUPT_CONDITION = 2000000;  // 파산 조건 -200억 이하
const int COURT_RECEIVERSHIP_CONDITION = 4000000;   // 법정관리 조건(400억 이하)
const int DISMISS_CONDITION = 7000000;  // 법정관리 해제 조건(700억 이상)
static int capital = 10000000;  // 시작 총자본금 1000억
static int gameCounter = 0; // 게임개발 수 
static int addedEmployees = 0;  // 추가 채용 인력
static int isCourtRecievership = 0; // 법정관리 상태 0:아님 1:맞음

typedef struct _company
{
    char name[20];
    double availableCapitalRate;   // 사용 가능 자본 비율
    int maxNumOfEmployees;  // 최대 투입 가능 직원 수
} Company;

typedef struct _game
{
    char title[100];
    int price;
    int isSuccess;  // 프로젝트 성공:1 실패:0
} Game;

void PrintStatus(Company c);
int PrintMenu(Company c);
void PrintMoneyUnit(int money);
Company SelectDevCompany(Company c[]);
void DevelopGame(Company *c);
int CalcWorkforce(int max);
int CalcDevPeriod(int min, int max);
int PrintDevSituations();
int SellGame(Game *g);
int PrintPromotions(Game *g, int count);
void CheckBankrupt();
void PrintEnding();
void CheckCourtRecievership();

int main()
{
    int nMenu;
    Company selectedCo;
    srand(time(NULL));

    //initialize companies
    Company companies[] = {
        {"넥순코리아", 0.2, 50},
        {"넥순지티", 0.3, 100},
        {"넥순재팬", 0.4, 200}
    };
    strcpy(selectedCo.name, "");

    while((nMenu=PrintMenu(selectedCo)) != 0)
    {
        switch(nMenu)
        {
            case 1:
                if(addedEmployees<=100 && gameCounter>0)
                {
                    int num;
                    puts("(추가채용을 하면 10명당 개발기간이 1개월씩 줄어듭니다)");
                    printf("추가 채용 인력(0~100명)>>");
                    scanf("%d", &num);
                    if(num>100 || num<0)
                    {
                        puts("범위 내의 숫자를 입력해주세요");
                        continue;
                    }
                    if(addedEmployees+num>100)
                    {
                        puts("추가인력을 100명 이상 채용 할 수 없습니다.");
                        continue;
                    }

                    addedEmployees += num;
                }

                selectedCo = SelectDevCompany(companies); // 개발 할 회사 선정
                printf("(발주사 선정 중...)\n");
                sleep(1);
                printf("이번 프로젝트는 %s이(가) 맡기로 결정했다!\n", selectedCo.name);
                sleep(1);
                PrintStatus(selectedCo);
                DevelopGame(&selectedCo);
                CheckBankrupt();    // 파산 여부 체크
                CheckCourtRecievership();   // 법정 관리 여부 체크

                break;
            case 2:
                break;
            default:
                puts("올바른 선택지를 골라주세요");
                break;
        }
    }



    return 0;
}

void PrintStatus(Company c)
{
    int availableCapital = (int)(capital * c.availableCapitalRate);

    if(isCourtRecievership)
        availableCapital *= 0.7;

    system("clear");
    puts("───────────────────────NEXOON COMPANY───────────────────────────");
    printf("- 총 자본금 : ");
    PrintMoneyUnit(capital);
    printf("%s", isCourtRecievership ? "(법정관리중)" : "");
    if(strcmp(c.name, "")!=0)
    {
        printf("\n- 개발사 : %s", c.name);
        printf("(최대 직원 수 %d명)\n", c.maxNumOfEmployees);
        printf("- %s의 사용가능 자본금 : ", c.name);
        PrintMoneyUnit(availableCapital);
        printf("(총 자본금의 %d%%)", (int)(c.availableCapitalRate*100));
        if(isCourtRecievership)
            printf("(법정관리에 의한 70%% 제한 적용 중)");
    }
    if(addedEmployees!=0)
    {
        printf("\n- 추가 인력 : %d명(개발기간 %d개월 감소)", addedEmployees, addedEmployees/10); 
    }
    putchar('\n');
    puts("────────────────────────────────────────────────────────────────");
}

int PrintMenu(Company c)
{
    int input;

    PrintStatus(c);

    puts("[1]게임 개발 시작");
    puts("[0]종료");
    printf(">>");
    scanf("%d", &input);
    return input;
} 

void PrintMoneyUnit(int money)
{
    int unit1 = money/10000;    //억 단위
    int unit2 = money%10000;    //만 단위

    if(money>9999)
    {
        if(unit2!=0)
            printf("%d억 %d만원", unit1, unit2);
        else
            printf("%d억", unit1);
    }
    else
        printf("%d만원", money);
}

Company SelectDevCompany(Company c[])
{
    return c[rand()%3];
}

void DevelopGame(Company *c)
{
    int devPeriod = CalcDevPeriod(11,36) - addedEmployees/10;    // 게임개발기간 11~36개월분 생성
    int eventPeriod = CalcDevPeriod(6,12); // 이벤트 발생(개발기간 6~12개월 증가)
    int workforce = CalcWorkforce(c->maxNumOfEmployees) + addedEmployees;    //투입인력 10~회사별max명
    int spentCapital = 0;
    int availableCapital = 0;   // 회사 별 사용 가능 자본금
    char title[100];
    Game newGame = {"", 5, 0};

    puts("게임 제목은 뭐로 할까?");
    printf(">>");
    scanf("%s", newGame.title);

    printf("%s의 개발에 %d명의 개발자가 투입되었다.\n", newGame.title, workforce);
    printf("개발 기간은 %d개월 정도 걸리겠군.\n", devPeriod);
    sleep(1);

    puts("(개발 중...)");
    sleep(1);
    PrintDevSituations(5);
    devPeriod += eventPeriod;
    printf("(버그가 발생하여 개발기간이 %d개월 만큼 증가했다.)\n", eventPeriod);
    sleep(1);
    PrintDevSituations(5);

    spentCapital = devPeriod * workforce * SALARY;
    availableCapital = isCourtRecievership ? (int)(capital * c->availableCapitalRate * 0.7) : (int)(capital * c->availableCapitalRate);

    capital -= spentCapital;
    gameCounter++;

    if(spentCapital > availableCapital)
    {
        newGame.isSuccess= 0;
        printf("%s가 사용 가능 자본금(", c->name);
        PrintMoneyUnit(availableCapital);
        printf(")을 초과하여 프로젝트가 실패하였다.\n"); 
        capital -= availableCapital; 

        return;
    }

    if(rand()%100<60)   // 60%확률로 프로젝트 실패
    {
        newGame.isSuccess = 0;
        puts("────────────────────");
        printf("프로젝트가 실패하였다...\n");
        sleep(1);
        printf("개발비 ");
        PrintMoneyUnit(spentCapital);
        printf("가 날아갔다!\n");
        sleep(1);
        printf("계속(enter)>>");
        getchar();
        getchar();

        return;
    }

    newGame.isSuccess = 1;
    puts("────────────────────");
    puts("프로젝트가 성공했다!");
    printf("개발 기간 : %d개월\n", devPeriod);
    printf("소요 비용 : ");
    PrintMoneyUnit(spentCapital);
    putchar('\n');
    printf("출시하기(enter)>>");
    getchar();
    getchar();
    PrintStatus(*c);
    SellGame(&newGame);
}

int CalcWorkforce(int max)
{
    return rand()%(max-9) + 10;
}

int CalcDevPeriod(int min, int max)
{
    return rand()%(max-min+1) + min;
}

int PrintDevSituations(int count)
{
    int i;
    char str[][100] = {"열심히 게임 개발 중...", "불꽃 코딩!!", "오늘도 야근 중...", "크런치 모드!"};

    for(i=0;i<count;i++)
    {
        printf("%s\n", str[rand()%(sizeof(str)/sizeof(str[0]))]);
        sleep(1);
    }
}

int SellGame(Game *g)
{
    int sold = rand()%5000000+1;
    int earnings = sold * g->price;
    capital += earnings;

    PrintPromotions(g, 5);
    puts("──────────판매결과──────────");
    printf("게임 %s은(는) %d장이 팔렸다!\n", g->title, sold);
    printf("수익금으로 ");
    PrintMoneyUnit(earnings);
    printf("을 벌었다!\n");
    printf("계속(enter)>>");
    getchar();
}

int PrintPromotions(Game *g, int count)
{
    char str[][200] = {"지금껏 경험했던 RPG는 모두 잊어라!", "지금까지 이런 게임은 없었다!", "모든 것은 당신의 선택에 따라!", "독특한 디자인의 게임!", "뭐든지 할 수 있는!", "엄청난 복선과 충격적인 스토리!", "뭐든지 할 수 있는!", "불가능한 도전!", "뛰어난 액션!", "당신의 행동에 따라 적응하고 변화하는!", "코스믹 호러!", "높은 자유도의!", "한정판 출시!", "서정적 대서사시!"};

    puts("(프로모션 중...)");

    int i;
    for(i=0;i<count;i++)
    {
        printf("%s %s!\n", str[rand()%(sizeof(str)/sizeof(str[0]))], g->title);
        sleep(1);
    }
}

void CheckBankrupt()
{
    if(capital <= BANKRUPT_CONDITION)
        PrintEnding();
}

void PrintEnding()
{
    printf("넥순그룹은 자본금이 ");
    PrintMoneyUnit(BANKRUPT_CONDITION);
    printf(" 이하가 되어 결국 역사속으로 사라지고 말았다...\n");
    exit(1);
}

void CheckCourtRecievership()
{
    if(capital<=COURT_RECEIVERSHIP_CONDITION)
        isCourtRecievership = 1;
    else if(capital>=DISMISS_CONDITION)
        isCourtRecievership = 0;
}
