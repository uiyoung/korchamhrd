#include <stdio.h>
#include <string.h>

const char * SayHi(const char* name)
{
    static char szBuffer[255];
    snprintf(szBuffer, sizeof(szBuffer), "Hi %s", name);
    return szBuffer;
}

int main()
{
    printf("%s\n", SayHi("uiyoung"));

    return 0;
}
