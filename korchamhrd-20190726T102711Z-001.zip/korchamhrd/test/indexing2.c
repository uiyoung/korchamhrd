#include <stdio.h>

int main()
{
    int b=3, n; // 검색숫자
    int a[10] = {0};

    for(int i=0;i<10;i++)
    {
        scanf("%d", &n);
        a[n]=1;
    }

    if(a[b]==1)
        printf("Y\n");
    else
        printf("N\n");

    return 0;
}


