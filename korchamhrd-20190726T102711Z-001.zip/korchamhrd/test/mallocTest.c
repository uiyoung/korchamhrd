#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int length=0;
    int maxLen=0;
    char *str;
    
    printf("문자열 길이 입력>>");
    scanf("%d", &maxLen);
    getchar();  // 개행문자 삭제
    
    str = (char *)malloc(sizeof(char)*maxLen+1);
    printf("문자열 입력>>");
    fgets(str, maxLen+1, stdin);

    printf("%s\n", str);

    str[strlen(str)-1] = 0;
    length = strlen(str);

    for(int i=length;i>=0;i--)
    {
        if(str[i]==' ')
        {
            printf("%s ", &str[i+1]);
            str[i]=0;
        }
    }
    printf("%s\n", &str[0]);

    free(str);

    return 0;
}
