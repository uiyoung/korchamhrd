#include <stdio.h>

int main()
{
    const int xMax = 100, yMax = 100; // size of map
    int key;
    int gap = 1;    // 한번 이동 거리    
    int flag = 0;
    int x=0, y=0;

    while(1)
    {
        printf("현재좌표 : (%d, %d)\n", x, y);
        printf("이동 [위:1], [아래:2], [왼쪽:3], [오른쪽:4]>>");
        scanf("%d", &key);
        
        if(key == 0)
            break;
        else if( key > 4 || key < 0 )
        {
            printf("명령을 잘못입력했습니다.\n");
            continue;
        }        
        
        switch(key)
        {
            case 1:
                y -= gap;
                if(y < 0)
                {
                    y += gap;
                    flag = 1;
                }
                else
                    flag = 0;

                break;
            case 2:
                y += gap;
                if(y > yMax)
                {
                    y -= gap;
                    flag = 1;
                }
                else
                    flag = 0;

                break;
            case 3:
                x -= gap;
                if(x < 0)
                {
                    x += gap;
                    flag = 1;
                }
                else
                    flag = 0;

                break;
            case 4:
                x += gap;
                if(x > xMax)
                {
                    x -= gap;
                    flag = 1;
                }
                else
                    flag = 0;

                break;
        }        

        if(flag)
            printf("막혀있습니다.\n"); 
        else
            printf("현재 위치 : (%d, %d)\n", x, y);
    }
    
    printf("종료\n");

    return 0;
}
