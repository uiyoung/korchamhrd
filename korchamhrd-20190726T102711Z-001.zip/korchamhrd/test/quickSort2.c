#include <stdio.h>

void quickSort(int* list, int left, int right);

int main()
{
    int list[] = {5, 3, 8, 4, 9, 1, 6, 2, 7};

    puts("before");
    for(int i=0;i<9;i++)
        printf("%d ", list[i]);

    quickSort(list, 0, 8);
    puts("");

    puts("after");
    for(int i=0;i<9;i++)
        printf("%d ", list[i]);

    puts("");

    return 0;
}

void quickSort(int* list, int start, int end)
{
    // 데이터가 2개 이하인 경우 종료
    if(start >= end)
        return;

    int pivot = arr[start];
    int left = start + 1;
    int right = end;

    do{

    }
}
