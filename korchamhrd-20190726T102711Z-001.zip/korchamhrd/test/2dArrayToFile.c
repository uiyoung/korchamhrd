#include <stdio.h>
#include <stdlib.h>

int main()
{
    //    int arr[3][3] = {{1, 1, 1},{1, 1, 1}, {1, 0, 1}};

    // 동적할당으로 2차원배열 생성
    int **arr = (int**)malloc(sizeof(int*)*3);
    for(int i=0;i<3;i++)
        arr[i] = (int*)malloc(sizeof(int)*3);

    // init arr[i][j]
    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
            arr[i][j] = 1;


    FILE *fp = fopen("a.txt", "w");

    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            fprintf(fp, "%d ", arr[i][j]);
        }
        fprintf(fp, "%c", '\n');
    }

    fclose(fp);

    return 0;
}

