#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arrLength = 5;  //초기 배열 길이 5
    int * arr = (int*)malloc(sizeof(int)*arrLength);
    int idx=0; 

    while(1)
    {
        printf("정수 입력>>");
        scanf("%d", &arr[idx]);

        if(arr[idx]==-1)
            break;

        if(idx==arrLength+1)
        {
            arrLength+=3;   //배열 크기+3
            arr = (int*)realloc(arr, sizeof(int)*arrLength);
        }
        idx++;
    }

    //print
    for(int i=0;i<arrLength;i++)
        printf("%d ", arr[i]);

    putchar('\n');

    free(arr);

    return 0;
}
