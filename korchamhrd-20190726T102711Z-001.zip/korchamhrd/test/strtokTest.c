#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    char str[] = "player 200";
    char* ptr = NULL;
    char* sArr[2] = {NULL, };

    char name[10];
    int score = 0;

    int i = 0;

    ptr = strtok(str, " ");

    while(ptr != NULL)
    {
        sArr[i] = ptr;
        i++;
        ptr = strtok(NULL, " ");
    }

    strcpy(name, sArr[0]);
    score = atoi(sArr[1]);

    printf("name:%s\n", name);
    printf("score:%d점\n", score);

    return 0;
}
