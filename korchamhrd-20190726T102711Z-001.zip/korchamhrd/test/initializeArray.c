#include <stdio.h>

int main()
{
    // numArr의 모든 배열요소를 모두 -1로 초기화
    int numArr[10] = {[0 ... 9] = -1};
    int i;

    for(i=0;i<sizeof(numArr)/sizeof(numArr[0]);i++)
        printf("%d\n", numArr[i]);

    // strArr의 모든 배열요소를 모두 "aa"로 초기화
    char strArr[10][100] = {[0 ... 9] = "aa"};

    for(i=0;i<sizeof(strArr)/sizeof(strArr[0]);i++)
        printf("%s\n", strArr[i]);

    return 0;
}
