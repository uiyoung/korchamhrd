#include <stdio.h>

void quickSort(int* list, int left, int right);

int main()
{
    int list[] = {5, 3, 8, 4, 9, 1, 6, 2, 7};

    puts("before");
    for(int i=0;i<9;i++)
        printf("%d ", list[i]);

    quickSort(list, 0, 8);
    puts("");

    puts("after");
    for(int i=0;i<9;i++)
        printf("%d ", list[i]);

    puts("");

    return 0;
}

void quickSort(int* list, int left, int right)
{
    int pivot = left;
    int j = pivot;
//    int i = left+1;

    // 데이터가 2개 이상일때 정렬 실행
    if(left<right)
    {
        for(int i=left+1;i<=right;i++)
        {
            if(list[i] < list[pivot])
            {
                j++;
                // swap 
                int temp = list[j];
                list[j] = list[i];
                list[i] = temp;
            }
        }

        //swap
        int temp = list[left];
        list[left] = list[j];
        list[j] = temp;

        pivot = j;

        quickSort(list, left, pivot-1);
        quickSort(list, pivot+1, right);
    }
}
