#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct _Player
{
    int elapsedTime;
}Player;

void* timer(void *p)
{
    Player *p1 = (Player*)p;

    while(1)
    {
        (p1->elapsedTime)++;
        usleep(100000);
    }
}

int main()
{
    Player p;
    pthread_t elapsedTime;
    int status;

    pthread_create(&elapsedTime, NULL, timer, (void*)&p);
    p.elapsedTime = 0;

    while(1)
    {
        system("clear");
        printf("elapsed:%d.%dsec\n", (p.elapsedTime)/10, (p.elapsedTime)%10);
        usleep(50000);
    }

    // 스레드 종료 대기
    pthread_join(elapsedTime, (void**)&status);
    
    return 0;
}
