#include <stdio.h>

int* testFunc(int arr[])
{
    static int pos[2];
    pos[0]=arr[0];
    pos[1]=arr[1];

    return pos;

}
int main()
{
    int arr[] = {1,2,3};

    int* newArr; 
    newArr = testFunc(arr);

    printf("%d%d\n", newArr[0], newArr[1]);

    return 0;
}
