#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
#include<time.h>
#include<termios.h>
typedef struct _player
{
    int hp;
    int xPos;
    int yPos;
}Player;


void* thread_1(Player* p,int v_map[][10] );
void initialize(Player* player,int v_map[][10]);
void print_map(int v_map[][10]);
int getch();
void Move(int v_map[][10],Player* p);
int cant_go(int direction,int v_map[][10],Player *p);

int main(void)
{
   int v_map[10][10]=
   {
       1,1,1,1,1,1,1,1,1,1,
       1,0,0,0,0,0,0,0,0,1,
       1,0,0,0,0,0,0,0,0,1,
       1,0,0,0,0,0,0,0,0,1,
       1,0,0,0,0,0,0,0,0,1,
       1,0,0,0,0,0,0,0,0,1,
       1,0,0,0,0,0,0,0,0,1,
       1,0,0,0,0,0,0,0,0,1,
       1,0,0,0,0,0,0,0,0,1,
       1,1,1,1,1,1,1,1,1,1,
   };
   int state1;
   int state2;

   pthread_t t_id[2];

   void* t_return1;
   void* t_return2;


   printf("starting game\n");
   sleep(5);

   Player p1;
   Player p2;

   state1=pthread_create(&t_id[0],NULL,thread_1(&p1,v_map),"1");
   state2=pthread_create(&t_id[1],NULL,thread_1(&p2,v_map),"2");

}
int getch()
{
    int ch;
    struct termios buf;
    struct termios save;
    tcgetattr(0,&save);
    buf=save;
    buf.c_lflag&=~(ICANON|ECHO);
    buf.c_cc[VMIN]=1;
    buf.c_cc[VTIME]=0;
    tcsetattr(0,TCSAFLUSH,&buf);
    ch=getchar();
    tcsetattr(0,TCSAFLUSH,&save);
    return ch;
}
void* thread_1(Player *p,int v_map[][10])
{   
    initialize(p,v_map);
    while(1)
    {
     print_map(v_map);
     Move(v_map,p);
    }
}


void initialize(Player* player,int v_map[][10])
{
    srand(time(NULL));
    player->hp=100;
    player->xPos=rand()%8+1;
    player->yPos=rand()%8+1;
    v_map[player->yPos][player->xPos]=3;
}
void print_map(int v_map[][10])
{
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<10;j++)
        {
            if(v_map[i][j]==1)printf("X ");
            if(v_map[i][j]==0)printf("  ");
            if(v_map[i][j]==3)printf("O ");
        }
        printf("\n");
    }
}

void Move(int v_map[][10],Player* p)
{
    char Key;
    int direction;
    int wall;
    Key=getch();
    switch(Key)
    {
        case 'B' :direction=2;
            break;
        case 'A': direction=1;
            break;
        case 'C': direction=3;
            break;
        case 'D': direction=4;
            break;
    }
    wall=cant_go(direction,v_map,p);
    if(wall!=0)
    {
        v_map[p->yPos][p->xPos]=0;
        switch(direction)
        {
            case 1://y--(up)
                p->yPos-=1;
                break;
            case 2://y++(down)
                p->yPos+=1;
                break;
            case 3://x++(right)
                p->xPos+=1;
                break;
            case 4://x--(left)
                p->xPos-=1;
                break;
        }
        v_map[p->yPos][p->xPos]=3;
    }
}
int cant_go(int direction,int v_map[][10],Player *p)
{
    int blocked=0;
    switch(direction)
    {
        case 1://y--(up)
            if(v_map[p->yPos-1][p->xPos]==1)blocked=1;
            break;
        case 2://y++(down)
            if(v_map[p->yPos+1][p->xPos]==1)blocked=1;
            break;
        case 3://x++(right)
            if(v_map[p->yPos][p->xPos+1]==1)blocked=1;
            break;
        case 4://x--(left)
            if(v_map[p->yPos][p->xPos-1]==1)blocked=1;
            break;
    }
    return blocked;
}
