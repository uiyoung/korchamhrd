#include <stdio.h>

int main()
{
    int a[] = {1, 4, 7, 2};
    int b[] = {2, 3, 5, 9};
    int check[10] = {0};
    
    for(int i=0;i<sizeof(a)/sizeof(int);i++)
        check[a[i]]++;

    for(int i=0;i<sizeof(b)/sizeof(int);i++)
        check[b[i]]++;


    puts("합집합");
    for(int i=0;i<10;i++)
    {
        if(check[i] != 0)
            printf("%d ", i);
    }
    putchar('\n');

    puts("교집합");
    for(int i=0;i<10;i++)
    {
        if(check[i] == 2)
            printf("%d ", i);
    }
    putchar('\n');

    return 0;
}
