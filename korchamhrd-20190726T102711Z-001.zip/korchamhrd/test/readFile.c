#include <stdio.h>

int main()
{
    char ch;
    char str[30];
    FILE * fp = fopen("data.txt", "rt");

    if(fp==NULL)
    {
        puts("failed to open file");
        return -1;
    }

    ch = fgetc(fp);
    printf("%c", ch);
    ch = fgetc(fp);
    printf("%c", ch);
    ch = fgetc(fp);
    printf("%c", ch);
    ch = fgetc(fp);
    printf("%c", ch);

    fgets(str, sizeof(str), fp);
    printf("%s", str);

    fclose(fp);

    return 0;
}
