#include <stdio.h>

int main()
{
    char str[5];
    puts("tell me something");
    fgets(str, sizeof(str),stdin);


    printf("%s\n", str);

    return 0;
}



