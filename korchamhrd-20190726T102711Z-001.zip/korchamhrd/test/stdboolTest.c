#include <stdbool.h>
#include <stdio.h>

int main()
{
    int a = false;
    bool b = true;

    printf("%d\n", a);
    printf("%d\n", b);
    return 0;
}
