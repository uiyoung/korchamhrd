#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int *pList1 = NULL;
    int *pList2 = NULL;
    int pArr[3] = {0};
    int i = 0;
    
    pList1 = (int*)malloc(sizeof(int)*3);
    memset(pList1, 0, sizeof(int)*3);

    pList2 = (int*)calloc(3, sizeof(int));

    for(i=0;i<3;i++)
        printf("pList1[%d]의 값:%d\n", i, pList1[i]);

    for(i=0;i<3;i++)
        printf("pList2[%d]의 값:%d\n", i, pList2[i]);

    free(pList1);
    free(pList2);

    return 0;
}
