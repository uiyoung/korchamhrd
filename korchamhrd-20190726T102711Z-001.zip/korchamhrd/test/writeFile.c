#include <stdio.h>

int main()
{
    FILE * fp = fopen("data.txt", "wt");

    if(fp==NULL)
    {
        puts("failed to open file");
        return -1;
    }

    fputc('s', fp);
    fputc('u', fp);
    fputc('y', fp);
    fputc('\n', fp);
    fputs("Hello suy!\n", fp);
    fclose(fp);
    
    return 0;
}

