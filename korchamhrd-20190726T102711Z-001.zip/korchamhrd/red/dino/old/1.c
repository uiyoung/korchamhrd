// party T-rex Game
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <termios.h>
#include <fcntl.h>
#include<pthread.h>

#define ROW 10
#define COLUMN 50

typedef struct _player
{
    char name;		// 이름 (랭킹)
    int xPos;		// 유저 x좌표
    int yPos;		// 유저 y좌표
    int heart;		// 유저 체력
    int elapsedTime;    // 경과 시간
    int score;		// 유저 점수
    int map[ROW][COLUMN];	// map
    int speed;      // usleep 속도 
    int stand[9][21];
    int jump[9][21];
}Player;

void gotoxy(int x, int y);
int getch();
int kbhit();
void removeCursor();
int Menu_Select_Key(void);
void *thread_move(void* p1);
void* timer(void *p);
void maps(Player *p1);
void printDinosaur();
void printDinosaur2();

void get_Item(int invincible,int speed_change,Player *p,int* have_gun);
void Itm_heart(Player *p);
void Itm_speed_up(Player* p);
void return_speed(Player* p);

int main()
{
    Player p1;
    p1.heart=3;
    p1.xPos=2;
    p1.yPos=ROW-2;
    void * thread_result;

    removeCursor();

    for(int i=0;i<ROW;i++)
    {
        for(int j=0;j<COLUMN;j++)
        {
            if(i==ROW-1)
                p1.map[i][j]=3;
            else
                p1.map[i][j]=0;
        }
    }

    int stand[9][21]={
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 55, 55, 55, 55, 55, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 55, 55, 66, 55, 55, 55, 55, 55, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 55, 55, 55, 55, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 55, 55, 55, 55, 55, 55, 55, 55, 0, 
        0, 0, 0, 0, 0, 55, 0, 0, 0, 0, 55, 55, 55, 55, 55, 55, 55, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 55, 55, 0, 0, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 0, 0, 
        0, 0, 0, 0, 0, 0, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 0, 0, 55, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 55, 0, 0, 0, 0, 55, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 55, 55, 0, 0, 0, 55, 55, 0, 0, 0, 0 
    };

    int jump[9][21]={
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55,55,55,55,55,55,0, 0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 55,55,0, 0, 0, 0, 55,55,55,66,55,55,55,55,55, 
        0, 0, 0, 0, 0, 0, 0, 55,55,0, 0, 0, 55,55,55,55,55,0, 0, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 55,55,0, 55,55,55,55,55,55,55,55,55,0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 55,55,55,55,55,55,55,0, 0, 0, 0, 0,  
        0, 0, 0, 0, 0, 0, 0, 0, 55,55,55,55,55,55,55,55,55,0, 0, 0, 0,  
        0, 0, 0, 0, 0, 0, 55, 55, 55, 55, 55, 55, 55, 55, 55, 0, 55, 55, 0, 0, 0,  
        0, 0, 0, 0, 0, 55, 55, 0, 0, 0, 55, 0, 0, 55, 0, 0, 0, 55, 55, 0, 0, 
        0, 0, 0, 0, 55, 0, 0, 0, 55, 55, 55, 0, 0, 55, 55, 0, 0, 0, 0, 0, 0 
    };

    // copy array stand, jump to player
    for(int i=0;i<9;i++)
    {
        for(int j=0;j<21;j++)
        {
            p1.jump[i][j]=jump[i][j];
            p1.stand[i][j]=stand[i][j];
        }
    }

    pthread_t t_id[2];
    int state;
    void * t_return;

    p1.speed=100000;		// usleep 안에 들어갈꺼임.

    pthread_create(&t_id[0], NULL, thread_move, (void*)&p1);
    pthread_create(&t_id[0], NULL, timer, (void*)&p1);  // thread for timer

    //    pthread_create(&t_id[1],NULL,thread_move,(void*)&p1);

    maps(&p1);
    pthread_join(t_id[0], &thread_result);
    pthread_join(t_id[0], &thread_result);

    /*   if(time%100==0)				// 플레이 시간 100초가 넘어갈시 스피드 증가.
         {
         speed-=1000*500;
         }*/

    if(p1.heart<=0)				// You Die.
    {
        printf("Your Score : %d\n", p1.score);
        printf("You Die\n");
    }

    return 0;
}

void maps(Player *p1)
{
    int x,y,a;				// 맵 생성할 임의의 변수
    int appear=COLUMN-1;			// 변할 장애물
    int already_obs=0;              //최소 장애물 간격을 위한..

    while(1)
    {
        system("clear");
        printf("x : %d, y : %d\n",p1->xPos,p1->yPos);
        if(already_obs<=0&&rand()%3==1)             //일단 3분의 1의 확률로 장애물 등장
        {
            p1->map[ROW-2][appear]=2;
            already_obs=2;                          //요거늘리면 최소간격 설정가능.
        }
        else
            already_obs-=1;

        //아이템 출현 확률 더 낮추기
        if(rand()%500==1)
            p1->map[ROW-3][appear]=11;
        else if(rand()%500==1)
            p1->map[ROW-3][appear]=22;
        else if(rand()%500==1)
            p1->map[ROW-3][appear]=33;
        else if(rand()%500==1)
            p1->map[ROW-3][appear]=44;

        //데미지데미지데미지
        if(p1->map[p1->yPos][p1->xPos]==2)
            p1->heart-=1;

        //점수
        if(p1->yPos!=ROW-2&&p1->map[ROW-2][p1->xPos]==2)
            p1->score+=1;

        printf("score : %d time : %d.%d\n",p1->score, (p1->elapsedTime)/10, (p1->elapsedTime)%10);

        if(p1->yPos==ROW-2)
        {
            p1->map[ROW-3][p1->xPos]=0;
            p1->map[p1->yPos][p1->xPos]=1;/////////플레이어 위치출력을 위해 현 플레이어위치에 1삽입
        }
        else if((p1->yPos==ROW-3)||(p1->yPos==ROW-4))
        {
            p1->map[p1->yPos][p1->xPos]=4;///떠있을때 모양
        }

        for(a=0;a<3;a++)
        {
            if(a<p1->heart)
                p1->map[0][COLUMN-1-a]=11;
            else
                p1->map[0][COLUMN-1-a]=12;
        }

        for(y=0;y<ROW;y++)
        {
            for(x=0;x<COLUMN;x++)
            {
                if(p1->map[y][x]==0)
                    printf("  ");
                if(p1->map[y][x]==1)		// @ 플레이어
                {
                    //printDinosaur();
                    printf("@ ");
                    /*
                       for(int i=0;i<9;i++){
                       for(int j=0;j<21;j++){
                       if(p1->stand[i][j]==0)printf(" ");
                       if(p1->stand[i][j]==55)printf("█");
                       if(p1->stand[i][j]==66)printf("▄");
                       }
                       printf("\n");
                       }
                     */
                }
                if(p1->map[y][x]==2)
                    printf("▲ ");
                if(p1->map[y][x]==3)
                    printf("■ ");
                if(p1->map[y][x]==4)
                {
                    //printDinosaur2();
                    printf("@ ");
                    /*
                       for(int i=0;i<9;i++){
                       for(int j=0;j<21;j++){
                       if(p1->jump[i][j]==0)printf(" ");
                       if(p1->jump[i][j]==55)printf("█");
                       if(p1->jump[i][j]==66)printf("▄");
                       }
                       printf("\n");
                       }
                     */
                }
                if(p1->map[y][x]==11)
                    printf("♥ ");
                if(p1->map[y][x]==12)
                    printf("♡ ");
                if(p1->map[y][x]==22)
                    printf("★ ");
                if(p1->map[y][x]==33)
                    printf("⇒ ");
                if(p1->map[y][x]==44)
                    printf("♬ ");
            }
            printf("\n");
        }
        for(int i=0;i<ROW;i++)
        {
            if(i!=ROW-1)
                p1->map[i][0]=0;

            for(int j=1;j<COLUMN;j++)
            {
                if(p1->map[i][j]!=1&&p1->map[i][j]!=4&&i>1&&i<ROW-1)
                {
                    p1->map[i][j-1]=p1->map[i][j];
                    p1->map[i][j]=0;
                }
            }
        }

        usleep(p1->speed);
    }
}

void* timer(void *p)
{
    Player *p1 = (Player*)p;

    while(1)
    {
        (p1->elapsedTime)++;
        usleep(100000);
    }
}

/*
void* player_input(void *p)
{
    Player *pp1 = (Player*)p;
    int key;

    while(1)
    {
        key = getch();

        switch(key)
        {
            case 65:
    //j            for(int i=0;i<4;i++)
                    jump(pp1, i);
            break;
        }
    }
}
*/

void jump(Player *p)
{
    p->map[p->yPos][p->xPos]=0;/////////////////////////
    p->yPos=ROW-3;
    usleep(p->speed);//30000
    p->yPos=ROW-4;
    usleep(p->speed);//30000
    p->yPos=ROW-3;
    usleep(p->speed);//30000
    p->yPos=ROW-2;
    
    usleep(50000);
}

void* thread_move(void* p1)
{
    int key;
    Player *pp1=(Player*) p1;

    while(1)
    {
        pp1->map[pp1->yPos-1][pp1->xPos]=0;/////////////////////////

        key=getch();
        switch(key)
        {
            
            case 65 :
                /*
                pp1->map[pp1->yPos][pp1->xPos]=0;/////////////////////////
                pp1->yPos=ROW-3;
                usleep(pp1->speed);//30000
                pp1->yPos=ROW-4;
                usleep(pp1->speed);//30000
                pp1->yPos=ROW-3;
                usleep(pp1->speed);//30000
                pp1->yPos=ROW-2;
                */
                jump(p1);

                break;
            default :
                break;
        }
    }
}

void gotoxy(int x, int y)
{
    printf("\033[%d;%df",y,x);
    fflush(stdout);
}

int getch()
{
    int c;
    struct termios oldattr, newattr;

    tcgetattr(STDIN_FILENO, &oldattr);           // 현재 터미널 설정 읽음
    newattr = oldattr;
    newattr.c_lflag &= ~(ICANON | ECHO);         // CANONICAL과 ECHO 끔
    newattr.c_cc[VMIN] = 1;                      // 최소 입력 문자 수를 1로 설정
    newattr.c_cc[VTIME] = 0;                     // 최소 읽기 대기 시간을 0으로 설정
    tcsetattr(STDIN_FILENO, TCSANOW, &newattr);  // 터미널에 설정 입력
    c = getchar();                               // 키보드 입력 읽음
    tcsetattr(STDIN_FILENO, TCSANOW, &oldattr);  // 원래의 설정으로 복구

    return c;
}

void removeCursor()
{
    printf("\e[?25l");
    fflush(stdout);
}

int kbhit()
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if(ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}

void get_Item(int invincible,int speed_change,Player* p,int* have_gun)
{
    if(p->map[p->yPos][p->xPos]==11)//11 '♡'
        Itm_heart(p);
    if(p->map[p->yPos][p->xPos]==22)//22 '☆'
        invincible=10; //invincible=1이면 damage함수를 10초동안 미실행 
    if(p->map[p->yPos][p->xPos]==33)//33 '⇒'
        *have_gun=10;
    //getch() 함수를 if문넣어서 바꿔야할듯 if(have_gun>0) have_gun-=1;
    if(p->map[p->yPos][p->xPos]==44)//44 '♬'
    {
        Itm_speed_up(p);
        speed_change=10;//speed_change가 1이면 출력,이동관련함수에서 speed_change가 1일 때 10초이후 return_speed를 실행하게 한다.
    }
}

void Itm_heart(Player *p)
{
    if(p->heart<3)p->heart+=1;
}

void Itm_speed_up(Player* p)
{
    p->speed*=2;  
}

void return_speed(Player* p)
{
    p->speed/=2;
}

void printDinosaur()
{
    puts("──────────██████");
    puts("────────────███▄█████");
    puts("────────────█████");
    puts("───────────█████████");
    puts("─────█────███████");
    puts("─────██──██████████");
    puts("──────██████████  █");
    puts("─────────██────█");
    puts("─────────███───██");
}

void printDinosaur2()
{
    puts("──────────██████");
    puts("──────██────███▄█████");
    puts("───────██───█████");
    puts("────────██─█████████");
    puts("─────────███████");
    puts("────────█████████");
    puts("──────█████████─██");
    puts("─────██───█──█───██");
    printf("────█───███──██");
}
