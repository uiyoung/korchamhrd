// party T-rex Game
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <termios.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio_ext.h>

#define ROW 10
#define COLUMN 50

typedef struct _player
{
    char name[30];		// 이름 (랭킹)
    int xPos;		// 유저 x좌표
    int yPos;		// 유저 y좌표
    int heart;		// 유저 체력
    int timeRecord;    // 기록 시간
    int score;		// 유저 점수
    int map[ROW][COLUMN];	// map
    //    int speed;      // usleep 속도 
    int stand[9][21];
    int jump[9][21];
    int isGameOver;
}Player;

typedef struct _game
{
    Player p[2];
    int players;
    int elapsedTime;
    int speed;
} Game;

void gotoxy(int x, int y);
int getch();
int kbhit();
void removeCursor();
void InitGame(Game *g);
int Menu_Select_Key(void);
void* t_timer(void*);
void* t_keyInput(void*);
void* t_game(void*);
void maps(Game* g, int player);
void jump(Game* g, int player);
void printDinosaur();
void printDinosaur2();

void Itm_heart(Game* g, int player);
void Itm_speed_up(Game* p);
void return_speed(Game* p);

void PrintGameOver(Game* g, int player);

int main()
{
    Game game;
    srand(time(NULL));

    removeCursor();
    InitGame(&game);

    pthread_t thread[3];
    void * t_result;

    pthread_create(&thread[0], NULL, t_timer, (void*)&game);  // thread for timer
    pthread_create(&thread[1], NULL, t_keyInput, (void*)&game);
    pthread_create(&thread[2], NULL, t_game, (void*)&game);

    pthread_join(thread[0], &t_result);
    pthread_join(thread[1], &t_result);
    pthread_join(thread[2], &t_result);


    if(*((int*)t_result) == 0)
    {

        __fpurge(stdin);
        puts("press any key to record");
        getch();
        printf("p1 %d %d\n", game.p[0].timeRecord, game.p[0].score);
        printf("p2 %d %d\n", game.p[1].timeRecord, game.p[1].score);
    }

    /*
       if(time%100==0)				// 플레이 시간 100초가 넘어갈시 스피드 증가.
       {
       speed-=1000*500;
       }

     */

    return 0;
}

void* t_timer(void* g)
{
    Game *pg = (Game*)g;

    while(1)
    {
        (pg->elapsedTime)++;
        usleep(100000);

        if(pg->p[0].isGameOver && pg->p[1].isGameOver)
            pthread_exit((void*)g);

    }
}

void* t_game(void* g)
{
    Game *pg = (Game*)g;
    int isEnd = 0;

    while(1)
    {
        system("clear");

        // todo : remove
        printf("1p x:%d, y:%d , gameOver:%d\n", pg->p[0].xPos, pg->p[0].yPos, pg->p[0].isGameOver);
        printf("2p x:%d, y:%d , gameOver:%d\n", pg->p[1].xPos, pg->p[1].yPos, pg->p[1].isGameOver);

        if(pg->p[0].heart>0)
        {
            printf("score : %d time : %d.%d\n", pg->p[0].score, (pg->elapsedTime)/10, (pg->elapsedTime)%10);
            maps(pg, 0);
            pg->p[0].timeRecord = pg->elapsedTime;
        }
        else
        {
            pg->p[0].isGameOver=1;
            PrintGameOver(pg, 0);
        }

        // 2p인 경우
        if(pg->players==2 && pg->p[1].heart>0)
        {
            printf("score : %d time : %d.%d\n", pg->p[1].score, (pg->elapsedTime)/10, (pg->elapsedTime)%10);
            maps(pg, 1);
            pg->p[1].timeRecord = pg->elapsedTime;
        }
        else
        {
            pg->p[1].isGameOver=1;
            PrintGameOver(pg, 1);
        }

        // 1p, 2p 모두 gameover시 스레드 종료 후 isEnd 값을 반환
        if(pg->p[0].isGameOver && pg->p[1].isGameOver)
        {
            isEnd = 1;
            pthread_exit((void*)&isEnd);
        }

        usleep(pg->speed);
    }
}

void* t_keyInput(void* g)
{
    Game *pg = (Game*)g;
    int key;

    while(1)
    {
        pg->p[0].map[pg->p[0].yPos-1][pg->p[0].xPos]=0; // 잔상제거

        key=getch();
        switch(key)
        {
            case 'a' :
                jump(pg, 0);
                break;

            case 'w':
                jump(pg, 1);
                break;

            default :
                break;
        }
        __fpurge(stdin);

        if(pg->p[0].isGameOver && pg->p[1].isGameOver)
            pthread_exit((void*)g);
    }
}

void InitGame(Game *g)
{
    g->players = 2;
    for(int i=0;i<2;i++)
    {
        g->p[i].heart = 3;
        g->p[i].xPos = 2;
        g->p[i].yPos = ROW-2;
        g->p[i].isGameOver = 0;
        g->speed = 100000;	

        // init map array
        for(int j=0;j<ROW;j++)
        {
            for(int k=0;k<COLUMN;k++)
            {
                if(j==ROW-1)
                    g->p[i].map[j][k]=3;
                else
                    g->p[i].map[j][k]=0;
            }
        }
    }
}

void maps(Game* g, int player)
{
    int appear=COLUMN-1;			// 변할 장애물
    int already_obs=0;              //최소 장애물 간격을 위한..

    if(already_obs<=0 && rand()%3==1)             //일단 3분의 1의 확률로 장애물 등장
    {
        g->p[player].map[ROW-2][appear]=2;
        already_obs=2;                          //요거늘리면 최소간격 설정가능.
    }
    else
        already_obs-=1;

    //아이템 출현 확률 더 낮추기
    if(rand()%500==1)
        g->p[player].map[ROW-3][appear]=11;
    else if(rand()%500==1)
        g->p[player].map[ROW-3][appear]=22;
    else if(rand()%500==1)
        g->p[player].map[ROW-3][appear]=33;
    else if(rand()%500==1)
        g->p[player].map[ROW-3][appear]=44;

    //데미지
    if(g->p[player].map[g->p[player].yPos][g->p[player].xPos]==2)
        g->p[player].heart-=1;

    //점수
    if(g->p[player].yPos!=ROW-2 && g->p[player].map[ROW-2][g->p[player].xPos]==2)
        g->p[player].score+=1;

    if(g->p[player].yPos==ROW-2)
    {
        g->p[player].map[ROW-3][g->p[player].xPos]=0;
        g->p[player].map[g->p[player].yPos][g->p[player].xPos]=1;//플레이어 위치출력을 위해 현 플레이어위치에 1삽입
    }
    else if((g->p[player].yPos==ROW-3)||(g->p[player].yPos==ROW-4))
    {
        g->p[player].map[g->p[player].yPos][g->p[player].xPos]=4;//떠있을때 모양
    }

    // 하트 출력
    for(int a=0;a<3;a++)
    {
        if(a < g->p[player].heart)
            g->p[player].map[0][COLUMN-1-a]=11;
        else
            g->p[player].map[0][COLUMN-1-a]=12;
    }

    for(int y=0;y<ROW;y++)
    {
        for(int x=0;x<COLUMN;x++)
        {
            if(g->p[player].map[y][x]==0)
                printf("  ");
            if(g->p[player].map[y][x]==1)		// @ 플레이어
            {
                printf("@ ");
                /*
                   for(int i=0;i<9;i++){
                   for(int j=0;j<21;j++){
                   if(p1->stand[i][j]==0)printf(" ");
                   if(p1->stand[i][j]==55)printf("█");
                   if(p1->stand[i][j]==66)printf("▄");
                   }
                   printf("\n");
                   }
                 */
            }
            if(g->p[player].map[y][x]==2)
                printf("▲ ");
            if(g->p[player].map[y][x]==3)
                printf("■ ");
            if(g->p[player].map[y][x]==4)
            {
                //printDinosaur2();
                printf("@ ");
                /*
                   for(int i=0;i<9;i++){
                   for(int j=0;j<21;j++){
                   if(p1->jump[i][j]==0)printf(" ");
                   if(p1->jump[i][j]==55)printf("█");
                   if(p1->jump[i][j]==66)printf("▄");
                   }
                   printf("\n");
                   }
                 */
            }
            if(g->p[player].map[y][x]==11)
                printf("♥ ");
            if(g->p[player].map[y][x]==12)
                printf("♡ ");
            if(g->p[player].map[y][x]==22)
                printf("★ ");
            if(g->p[player].map[y][x]==33)
                printf("⇒ ");
            if(g->p[player].map[y][x]==44)
                printf("♬ ");
        }
        printf("\n");
    }

    for(int i=0;i<ROW;i++)
    {
        if(i!=ROW-1)
            g->p[player].map[i][0]=0;

        for(int j=1;j<COLUMN;j++)
        {
            if(g->p[player].map[i][j]!=1 && g->p[player].map[i][j]!=4&&i>1&&i<ROW-1)
            {
                g->p[player].map[i][j-1]=g->p[player].map[i][j];
                g->p[player].map[i][j]=0;
            }
        }
    }
}

void jump(Game *g, int player)
{
    g->p[player].map[g->p[player].yPos][g->p[player].xPos]=0;/////////////////////////
    g->p[player].yPos=ROW-3;
    usleep(g->speed);//30000
    g->p[player].yPos=ROW-4;
    usleep(g->speed);//30000
    g->p[player].yPos=ROW-3;
    usleep(g->speed);//30000
    g->p[player].yPos=ROW-2;
    usleep(g->speed);//30000

    usleep(50000);
}

void PrintGameOver(Game* g, int player)
{
    printf("score : %d time : %d.%d\n", g->p[player].score, g->p[player].timeRecord/10, g->p[player].timeRecord%10);
    for(int i=0;i<ROW;i++)
    {
        if(i == 4)
            puts("\t\t\t\t\t Game Over");
        else if(i == 5)
            printf("\t\t\t\t\t· %d.%d sec\n", g->p[player].timeRecord/10, g->p[player].timeRecord%10);
        else if(i == 6)
            printf("\t\t\t\t\t· %d point\n", g->p[player].score);
        else
            puts("");
    }
}


void gotoxy(int x, int y)
{
    printf("\e[%d;%df",y,x);
    fflush(stdout);
}

int getch()
{
    int c;
    struct termios oldattr, newattr;

    tcgetattr(STDIN_FILENO, &oldattr);           // 현재 터미널 설정 읽음
    newattr = oldattr;
    newattr.c_lflag &= ~(ICANON | ECHO);         // CANONICAL과 ECHO 끔
    newattr.c_cc[VMIN] = 1;                      // 최소 입력 문자 수를 1로 설정
    newattr.c_cc[VTIME] = 0;                     // 최소 읽기 대기 시간을 0으로 설정
    tcsetattr(STDIN_FILENO, TCSANOW, &newattr);  // 터미널에 설정 입력
    c = getchar();                               // 키보드 입력 읽음
    tcsetattr(STDIN_FILENO, TCSANOW, &oldattr);  // 원래의 설정으로 복구

    return c;
}

void removeCursor()
{
    printf("\e[?25l");
    fflush(stdout);
}

int kbhit()
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if(ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}

void Itm_heart(Game* g, int player)
{
    if(g->p[player].heart<3)
        g->p[player].heart += 1;
}

void Itm_speed_up(Game* g)
{
    g->speed*=2;  
}

void return_speed(Game* g)
{
    g->speed/=2;
}
