#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>
#include <pthread.h>
#include <semaphore.h>
#define RED printf("%c[1;31m", 27);
#define DEF printf("%c[0m", 27);
#define BLUE printf("%c[34m", 27);
#define GREEN printf("%c[32m", 27);
#define YELLOW printf("%c[33m", 27);
#define PURPLE printf("%c[35m", 27);
#define GRAY printf("\x1b[30m"); // 회색 출력



typedef struct _Player{
    char name[20];
    int y;
    int endgame;
    int score;
    int Map[16][120];
} Player;

typedef struct _Gamestate{
    unsigned int playtime;
    int playtime_msec;
    int player_num;
    Player p[2];
    sem_t bin_sem;
    sem_t bin_sem2;
} Gamestate;

void Read_Ranking(char name[][20], int score[], int playtime[]);
void Game_Initialize(Gamestate *gs);
void Play_Game(Gamestate *gs);
void Show_Ranking(char name[][20], int score[], int playtime[]);
void Huddle_Spwan(Gamestate *gs, int Player);
void Draw_Map(Gamestate *gs, int Player);
void *Play_Routine(void *vp);
void AsciiArt1(Gamestate *gs);
void Rabbit_Jump(Gamestate *gs, int num);
void *DrawMap2(void *vp);
void *Time_count(void *vp);
void gotoxy(int sx, int sy);
void Title();
int Show_Title();
int getch();
int kbhit(); 
void *Player_Input(void *vp);

int main(void)
{
    char name[10][20];  // 랭킹정보를 읽어 온 후 이름을 저장할 변수
    int score[10];      // 랭킹정보를 읽어 온 후 점수를 저장할 변수
    int playtime[10];   // 랭킹정보를 읽어 온 후 플레이타임을 저장할 변수
    int choice; 
    
    srand(time(NULL));
    Gamestate gs;   // 구조체 변수 선언
    Read_Ranking(name, score, playtime);    // ranking.txt 파일의 내용을 읽어온다
   
    while(choice != 4)
    {
        Game_Initialize(&gs);   // 게임 정보 초기화
        choice = Show_Title();  // 타이틀 출력 및 메뉴 선택

        switch(choice)
        {
            case 1: // 1인용으로 게임 플레이 시작
				gs.player_num =0;
				Play_Game(&gs);     
            break;   
            case 2: // 2인용으로 게임 플레이 시작
				gs.player_num =1;
				Play_Game(&gs); 
            break;   
            case 3: 
				Show_Ranking(name, score, playtime); 
			break; // 랭킹정보 출력
        }
    }
    //Save_Ranking(&name, &score, &playtime,gs);

    return 0;
}

void Read_Ranking(char name[][20], int score[], int playtime[])
{
    FILE *fp = fopen("ranking.txt", "r");

    for(int i= 0; i< 10; i++)
     fscanf(fp, "%s%d%d", name[i], &score[i], &playtime[i]);

    fclose(fp);
}

void Game_Initialize(Gamestate *gs)
{
    int rnum;
    int bottom = 0;

    gs->playtime = 0;
    gs->playtime_msec = 0;


   for(int i = 0; i<16; i++)
   {
        for(int j =0; j<120; j++)
        {
            if(i!=15)
            {
                gs->p[0].Map[i][j] = 3;
                gs->p[1].Map[i][j] = 3;
            }
            else
            {
                if(rnum = rand()%100 <= 95) bottom =0;
                else bottom = 1;
                gs->p[0].Map[15][j] = bottom;
                gs->p[1].Map[15][j] = bottom;
            }       
        }
    }
	for(int i=0; i<2; i++)
   {
		gs->p[i].score = 0;
		gs->p[i].endgame = 0;
		gs->p[i].y = 11;
        //토끼 모습 초기화
		gs->p[i].Map[gs->p[i].y][30]='/';
		gs->p[i].Map[gs->p[i].y][30+1]='/';
		gs->p[i].Map[gs->p[i].y+1][30-1]='(';
		gs->p[i].Map[gs->p[i].y+1][30]='"';
		gs->p[i].Map[gs->p[i].y+1][30+1]='>';
		gs->p[i].Map[gs->p[i].y+2][30-1]='/';	
		gs->p[i].Map[gs->p[i].y+2][30]='r';
		gs->p[i].Map[gs->p[i].y+2][30+1]='r';
		gs->p[i].Map[gs->p[i].y+3][30-2]='*';
		gs->p[i].Map[gs->p[i].y+3][30-1]='\\';
		gs->p[i].Map[gs->p[i].y+3][30]=')';
		gs->p[i].Map[gs->p[i].y+3][30+1]=')';
		gs->p[i].Map[gs->p[i].y+3][30+2]='_';
   }
   



}

int Show_Title()
{
    int choice;

    while(1)
    {
        system("clear");
        Title();
        GREEN
        printf("\n\t\t\t1. 1인 플레이\n\t\t\t2. 2인 플레이\n\t\t\t3. 랭킹보기\n\t\t\t4. 종료\n>> ");
        DEF
        scanf("%d", &choice);

        if(choice >3 && choice <0) 
        {
            printf("잘못 선택 했습니다.\n");
            sleep(1);
        }
        else return choice;
    }
}
void Play_Game(Gamestate *gs)
{
    int threadErr;
    int th_result;
    int state;

    int temp;
    

    pthread_t Playtime,Play, Input;
 //   state = sem_init(&(gs->bin_sem), 0, 0);
 //   state = sem_init(&(gs->bin_sem2), 0, 0);
    pthread_create(&Playtime,NULL,Time_count,(void*)gs); //시간 카운트 

    pthread_create(&Play,NULL,Play_Routine,(void*)gs);
	pthread_create(&Input,NULL,Player_Input,(void*)gs);
 //   pthread_create(&Player[1],NULL,DrawMap2,(void*)gs);

    pthread_join(Playtime, (void**)&th_result);
    pthread_join(Play, (void**)&th_result);
	pthread_join(Input, (void**)&th_result);
//    pthread_join(Player[1], (void**)&th_result);
 //   sem_destroy(&(gs->bin_sem));
 //   sem_destroy(&(gs->bin_sem2));
}
void *Time_count(void *vp)
{
    Gamestate *gs = (Gamestate*)vp;

    while(1)
    {
        gs->playtime_msec++;
        if(gs->playtime_msec == 10) 
        {
            gs->playtime++;
            gs->playtime_msec = 0; 
        }
        usleep(100000);
    }
}

void *Play_Routine(void *vp)
{
    Gamestate *gs = (Gamestate*)vp;

    int rnum;
    int spwan_cnt=1;
    int delay = 50000;

    while(1)
    {
        system("clear");

        printf("Playtime : %4d.%d sec\n\n", gs->playtime, gs->playtime_msec);
        printf("Player 1\nScore : %d", gs->p[0].score);
       
		Draw_Map(gs, 0);
        printf("\n\n");

        if(gs->player_num)  // 2p 맵출력
        {
            printf("Player 2\nScore : %d", gs->p[1].score);
            Draw_Map(gs, 1);
        }
            
        if(gs->playtime%5 == 0 && delay > 20000) delay -= 1000;
    //   sem_post(&(gs->bin_sem));
    //   sem_wait(&(gs->bin_sem2));
        if(((rnum=rand()%100)<10)&&(spwan_cnt>100)) // 허들 생성 
        {
            Huddle_Spwan(gs, Player);
            spwan_cnt=1;    
        }
        spwan_cnt++;
	
		usleep(delay);
    }
    

}
void Draw_Map(Gamestate *gs, int Player)
{
	int rnum;
    int bottom;
    int count=1;
	static int term;
	
	if(term <20) term++;
	
    if(gs->p[Player].y == 11)
    {
        gs->p[Player].Map[gs->p[Player].y+3][30] = term %7==0 ? ')': '\\';
        gs->p[Player].Map[gs->p[Player].y+3][30+1]= term %7==0 ? ')': '\\';
    }

	if(term ==20) term =0;
	printf("\n                      ┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐\n");
	for(int i= 0; i<16; i++)
	{
        printf("                      │");
		for(int j =0; j<120; j++)
		{
			switch(gs->p[Player].Map[i][j])
			{
				case 0 : printf("─"); break;
                case 1 : printf("^"); break;
                case 2 : printf("#"); break;
                case 3 : printf(" "); break;
                case 4 : printf("["); break;
                case 5 : printf("]"); break;
                case 6 : printf("U"); break;
                case 7 : printf("|"); break;
                case 8: printf("{"); break;
                case 9 : printf("}"); break;
                case 10 : printf("_"); break;
                case 11 : printf("T"); break;
                case 12 : printf("\\"); break;
                case 13 : printf("("); break;
                case 14 : printf(")"); break;
                case 15 : printf("/"); break;
                
				default : printf("%c", gs->p[Player].Map[i][j]); break;
			}
		}
		printf("│\n");
	}
    printf("                      └────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘\n");
       
	for(int i= 8; i<16; i++)
	{
		for(int j =0; j<120; j++)
		{
			if(gs->p[Player].Map[i][j] >=0 && gs->p[Player].Map[i][j] <=15&& gs->p[Player].Map[i][j+1]<=15 )
			{
				gs->p[Player].Map[i][j] = gs->p[Player].Map[i][j+1];  // 장애물을 왼쪽으로 한칸씩 이동시킨다
			}
			gs->p[Player].Map[i][0] = 3; // 장애물이 이동한 뒤는 다시 빈칸으로 체운다
		}
	}
  /*  for(int i=8;i<16;i++)
        {
            for(int j =0; j<120; j++)
            {
                gs->p[0].Map[i][j] = gs->p[0].Map[i][j+1];
                gs->p[0].Map[i][0] =3;
            }
        }
	*/
	if(rnum = rand()%100 <= 95) bottom =0; 	// 0이면 "─"
	else bottom = 1;	// 1이면 "^"
	gs->p[Player].Map[15][119] = bottom; // 바닥 길 모양을 랜덤 변화

   

}
void Huddle_Spwan(Gamestate *gs, int Player)
{
    int rnum = rand()%100;
    if(gs->player_num == 0 && Player ==1) return;
    /*
    for(int i = 12; i<16; i++)
    {
        for(int j = 116; j<120; j++)
        {
            gs->p[Player].Map[i][j] = 2;
        }
    }
    */
    if(rnum<50)
    {
         AsciiArt1(gs);
    }
    else
    {
         AsciiArt1(gs);
    }   
}
void AsciiArt1(Gamestate *gs)
{
    int random = rand() % 100+1;
    if (random>0 && random<=33) 
    {
        gs->p[0].Map[12][116] = 4;
        gs->p[0].Map[12][117] = 6;
        gs->p[0].Map[12][118] = 6;
        gs->p[0].Map[12][119] = 5;

        gs->p[0].Map[13][116] = 3;
        gs->p[0].Map[13][117] = 7;
        gs->p[0].Map[13][118] = 7;
        gs->p[0].Map[13][119] = 3;

        gs->p[0].Map[14][116] = 3;
        gs->p[0].Map[14][117] = 8;
        gs->p[0].Map[14][118] = 9;
        gs->p[0].Map[14][119] = 3;

        gs->p[0].Map[15][116] = 8;
        gs->p[0].Map[15][117] = 10;
        gs->p[0].Map[15][118] = 10;
        gs->p[0].Map[15][119] = 9;
    }
    else if(random>=34 && random<=66)
    {
        gs->p[0].Map[12][116] = 3;
        gs->p[0].Map[12][117] = 11;
        gs->p[0].Map[12][118] = 12;
        gs->p[0].Map[12][119] = 3;

        gs->p[0].Map[13][116] = 3;
        gs->p[0].Map[13][117] = 7;
        gs->p[0].Map[13][118] = 12;
        gs->p[0].Map[13][119] = 14;

        gs->p[0].Map[14][116] = 3;
        gs->p[0].Map[14][117] = 8;
        gs->p[0].Map[14][118] = 9;
        gs->p[0].Map[14][119] = 3;

        gs->p[0].Map[15][116] = 8;
        gs->p[0].Map[15][117] = 10;
        gs->p[0].Map[15][118] = 10;
        gs->p[0].Map[15][119] = 9;

    }
    else if(random>=67 && random<=100)
    {
        gs->p[0].Map[12][116] = 3;
        gs->p[0].Map[12][117] = 13;
        gs->p[0].Map[12][118] = 14;
        gs->p[0].Map[12][119] = 3;

        gs->p[0].Map[13][116] = 3;
        gs->p[0].Map[13][117] = 15;
        gs->p[0].Map[13][118] = 12;
        gs->p[0].Map[13][119] = 3;

        gs->p[0].Map[14][116] = 3;
        gs->p[0].Map[14][117] = 8;
        gs->p[0].Map[14][118] = 9;
        gs->p[0].Map[14][119] = 3;

        gs->p[0].Map[15][116] = 8;
        gs->p[0].Map[15][117] = 10;
        gs->p[0].Map[15][118] = 10;
        gs->p[0].Map[15][119] = 9;
    }
}

void *Player_Input(void *vp)
{
	
	Gamestate *gs = (Gamestate*)vp;
    int key;
    int *y = &gs->p[0].y;

	while(1)
	{
		key = getch();

		switch(key)
		{
			case 'w' :
                for(int i =0; i<10; i++)
                    Rabbit_Jump(gs, i);
			break;
		}
	}
}

void Rabbit_Jump(Gamestate *gs, int num)
{
    int *y= &gs->p[0].y;

    if(num < 5) 
    {
        
        for(int i=*y; i<= (*y)+3; i++)
        {
            for(int j= 28; j<33; j++)
            {								
                if(gs->p[0].Map[i][j] > 4 )
                {
                        gs->p[0].Map[i-1][j] = gs->p[0].Map[i][j];
                }
            }    
        }
        for(int j =28; j<33; j++)
            gs->p[0].Map[*y+3][j] = 3;
        
        if(*y-1 >=0 )*y -=1;
    }
    else 
    {
        
        for(int i=(*y)+3; i>= *y; i--)
        {
            for(int j= 28; j<33; j++)
            {								
                if(gs->p[0].Map[i][j] > 4 )
                {
                        gs->p[0].Map[i+1][j] = gs->p[0].Map[i][j];
                        gs->p[0].Map[i][28] = 3;
                        gs->p[0].Map[i][32] = 3;
                        
                }
            }    
        }
        for(int j =28; j<33; j++)
            gs->p[0].Map[*y][j] = 3;

        if(*y+1 <=15) *y += 1;    
        gs->p[0].Map[*y][29] = 3;
    }
    usleep(50000);
    
    
}

void Show_Ranking(char name[][20], int score[], int playtime[])
{
    for(int i=0; i<10; i++)
    printf("%s %d %d\n", name[i], score[i], playtime[i]);
    while(getchar() != '\n');
    getchar();
}

void Save_Ranking(char name[][20], int score[], int playtime[],Gamestate *gs)
{


    

}

void Title()
{
    RED
    printf("########     ###    ########  ########  #### ########    ########  ##     ## ##    ##\n");
    printf("##     ##   ## ##   ##     ## ##     ##  ##     ##       ##     ## ##     ## ###   ## \n");
    BLUE
    printf("##     ##  ##   ##  ##     ## ##     ##  ##     ##       ##     ## ##     ## ####  ## \n");
    printf("########  ##     ## ########  ########   ##     ##       ########  ##     ## ## ## ## \n");
    printf("##   ##   ######### ##     ## ##     ##  ##     ##       ##   ##   ##     ## ##  #### \n");
    YELLOW
    printf("##    ##  ##     ## ##     ## ##     ##  ##     ##       ##    ##  ##     ## ##   ### \n");
    printf("##     ## ##     ## ########  ########  ####    ##       ##     ##  #######  ##    ## \n");
    DEF
}

int kbhit()
{
	struct termios oldt, newt;
	int ch;
	int oldf;

	tcgetattr(STDIN_FILENO, &oldt);
	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);
	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
	fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

	ch = getchar();

	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	fcntl(STDIN_FILENO, F_SETFL, oldf);

	if(ch != EOF)
	{
		ungetc(ch, stdin);
		return 1;
	}

	return 0;
}

int getch()					// 키보드 이동키 함수
{
	int ch;
	struct termios buf;
	struct termios save;

	tcgetattr(0,&save);
	buf=save;
	buf.c_lflag&=~(ICANON|ECHO);
	buf.c_cc[VMIN]=1;
	buf.c_cc[VTIME]=0;
	tcsetattr(0,TCSAFLUSH,&buf);
	ch=getchar();
	tcsetattr(0,TCSAFLUSH,&save);

    return ch;
}
void gotoxy(int sx, int sy)
{

	printf("\033[%d;%df",sy,sx);

	fflush(stdout);
}


