#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define Red printf("%c[1;31m", 27);
#define Def printf("%c[0m", 27);
#define Blue printf("%c[1;34m", 27);
#define GREEN printf("%c[1;32m", 27);
#define YELLOW printf("%c[1;33m", 27);
#define PURPLE printf("%c[1;35m", 27);

typedef struct _Player 
{
    char name[30];
    int score;
} Player;

typedef struct _State
{
    char nick[30][50];
    int limit[30];
    int high[30];
    int year[30];
    int month[30];
    int day[30];
    char yo1[30][10];
} State;

void SaveScore(Player *p1, struct tm date, int *time, FILE *fp);    // 플레이정보를 파일에 저장
int HighScore(Player *p1, State *st, int *MaxScore, FILE *fp);      // 최고점수반환하는 함수 구현
void Ranking(Player *p1, State *st, FILE *fp);                      // 랭킹 출력함수

int main(void)
{
    struct tm *date;                // time.h 헤더파일의 time 구조체 
    State st;                       // 저장된 랭킹파일을 저장하여 출력할 구조체
    FILE *fp;                       // 파일입출력 포인터
    const time_t t = time(NULL);    // time.h를 사용하여 시간을 받아오기위함
    date = localtime(&t);           // time.h를 사용하기위함
    Player p1;                      // 플레이어의 정보 구조체
    int time = 100;                 // 프로그램 확인을 위한 플레이시간
    int MaxScore = 0;               // 랭킹의 최고점 변수
    int choice;                     // 선택지 변수

    while(1)
    {
        printf("이름>>");
        scanf("%s", p1.name);
        printf("점수>>");
        scanf("%d", &p1.score);

        SaveScore(&p1, *d//ate, &time, fp);           // 파일입출력을 위해 세이브 함수로
        HighScore(&p1, &st, &MaxScore, fp);         // 최고점수를 반환하는 함수
        Ranking(&p1, &st, fp);

        printf("%d\n", MaxScore);

        printf("[1]종료[2]계속>>");
        scanf("%d", &choice);

        if(choice==1)
            break;
        else
        {
            while(getchar()!='\n');
            continue;
        }
    }

    return 0;
}


void SaveScore(Player *p1, struct tm date, int *time, FILE *fp)
{
    char day[8][10] = {" ", "MON", "TUE", "WED", "THR", "FRI", "SAT", "SUN"};
    fp = fopen("ranking.txt", "a");
    fprintf(fp, "%s %d %d %d %d %d %s\n", p1->name, *time, p1->score, date.tm_year + 1900, date.tm_mon + 1, date.tm_mday, day[date.tm_wday]);
    fclose(fp);
}

int HighScore(Player *p1, State *st, int *MaxScore, FILE *fp)
{
    int num=0;
    fp = fopen("ranking.txt", "r");
    while(!feof(fp))
    {
        fscanf(fp, "%s %d %d %d %d %d %s", st->nick[num], &st->limit[num], &st->high[num], &st->year[num], &st->month[num], &st->day[num], st->yo1[num]);
        num++;
    }
    for(int i=0; i<num-1; i++)
    {
        if (st->high[i] > *MaxScore)
            *MaxScore = st->high[i];
    }
    fclose(fp);

    return *MaxScore;
}

void Ranking(Player *p1, State *st, FILE *fp)
{
    int t_high, t_limit, t_year, t_month, t_day;
    int num=0;
    char t_nick[10], t_yo1[10];

    fp = fopen("ranking.txt", "r");
    while(!feof(fp))
    {
        fscanf(fp, "%s %d %d %d %d %d %s ", st->nick[num], &st->limit[num], &st->high[num], &st->year[num], &st->month[num], &st->day[num], st->yo1[num]);
        num+=1;
    }

    printf("%d개의 랭킹정보\n",num);

    /*while(EOF!=fscanf(fp, "%s %d %d %d %d %d %s", st->nick[num], &st->limit[num], &st->high[num], &st->year[num], &st->month[num], &st->day[num], st->yo1[num]));*/
    for (int i = 0; i < num; i++)
    {
        for (int j = 0; j < num - 1; j++)
        {
            if (st->high[j] < st->high[j + 1])
            {
                t_high = st->high[j];
                st->high[j] = st->high[j + 1];
                st->high[j + 1] = t_high;
                t_limit = st->limit[j];
                st->limit[j] = st->limit[j + 1];
                st->limit[j + 1] = t_limit;
                t_year = st->year[j];
                st->year[j] = st->year[j + 1];
                st->year[j + 1] = t_year;
                t_month = st->month[j];
                st->month[j] = st->month[j + 1];
                st->month[j + 1] = t_month;
                t_day = st->day[j];
                st->day[j] = st->day[j + 1];
                st->day[j + 1] = t_day;
                strcpy(t_nick, st->nick[j]);
                strcpy(st->nick[j], st->nick[j + 1]);
                strcpy(st->nick[j + 1], t_nick);
                strcpy(t_yo1, st->yo1[j]);
                strcpy(st->yo1[j], st->yo1[j + 1]);
                strcpy(st->yo1[j + 1], t_yo1);
            }
        }
    }

    printf("\tNAME\t\tTIME\t\tSCORE\t\tDATE\n");

    for (int i = 0; i < 80; i++)
        printf("=");
    for (int i = 0; i < num; i++)
    {
        printf("\n");
        if(strcmp(p1->name, st->nick[i]) == 0)
        {
            if(p1->score == st->high[i])
            {
                Red
                    printf("\t%s\t\t%d\t\t%d\t\t%d-%d-%d-%s ", st->nick[i], st->limit[i], st->high[i], st->year[i], st->month[i], st->day[i], st->yo1[i]);
                Def
                    printf("\n");
                for (int i = 0; i < 80; i++) printf("=");
            }     
        }
        else 
        {
            if(p1->score != st->high[i])
            {
                printf("\t%s\t\t%d\t\t%d\t\t%d-%d-%d-%s ", st->nick[i], st->limit[i], st->high[i], st->year[i], st->month[i], st->day[i], st->yo1[i]);
                printf("\n");
                for (int i = 0; i < 80; i++) printf("=");
            }
        }
    }
    printf("\n");
    fclose(fp);
}