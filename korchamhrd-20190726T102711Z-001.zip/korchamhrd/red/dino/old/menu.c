#include <stdio.h>
#include <termios.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

// keyboard values
#define UP 65
#define DOWN 66
#define ENTER '\n'

int kbhit();
int getch();
void gotoxy(int x, int y);
void removeCursor();
void printMenu(int menuPos);
int selectMenu(int *pos);
void printMenuDinosaur();

int main()
{
    int menuPos = 20;
    int isSelected = 0;

    removeCursor();

    while(1)
    {
        printMenu(menuPos);
        isSelected = selectMenu(&menuPos);

        if(isSelected)
        {
            system("clear");
            switch(menuPos)
            {
                case 20:
                    // todo : 1p 게임 시작
                    puts("1p");
                    sleep(1);
                    break;
                case 21:
                    // todo : 2p 게임 시작
                    puts("2p");
                    sleep(1);
                    break;
                case 22:
                    // todo : ranking 정보 출력
                    puts("ranking");
                    sleep(1);
                    break;
                case 23:
                    puts("exit");
                    sleep(1);
                    return 0;
                    break;
            }
        }
    }

    return 0;
}

void printMenu(int menuPos)
{
    char instructions[][50] = 
    {
        "  1p 점프:w키", 
        "  1p 점프:w키, 2p 점프:↑키",
        "  랭킹기록을 확인합니다.",
        "  게임을 종료합니다."
    };

    system("clear");
    printMenuDinosaur(menuPos);
    gotoxy(1, 20);
    puts("  1p");
    puts("  2p");
    puts("  ranking");
    puts("  exit");
    printf("\n%s\n", instructions[menuPos-20]);
    gotoxy(1, menuPos);
    puts(">");
}

int selectMenu(int *pos)
{
    int isSelected = 0;
    int ch = getch();

    if(ch == UP || ch == 'w' || ch == 'W')
    {
        (*pos)--;
        if(*pos < 20)
            *pos = 20;
    }
    else if(ch == DOWN || ch == 's' || ch == 'S')
    {
        (*pos)++;
        if(*pos > 23)
            *pos = 23;
    }
    else if(ch == ENTER)
        isSelected = 1;

    return isSelected;
}

void printMenuDinosaur(int menuPos)
{
    int max = (menuPos-19)*2;
    for(int i=0;i<max;i++)
    {
        gotoxy(i, 1);
        puts("");
        gotoxy(i, 2);
        puts("────────────────████████");
        gotoxy(i, 3);
        puts("───────────────███▄███████");
        gotoxy(i, 4);
        puts("───────────────███████████");
        gotoxy(i, 5);
        puts("───────────────███████████");
        gotoxy(i, 6);
        puts("───────────────██████");
        gotoxy(i, 7);
        puts("───────────────█████████");
        gotoxy(i, 8);
        puts("─────█───────███████");
        gotoxy(i, 9);
        puts("─────██────████████████");
        gotoxy(i, 10);
        puts("─────███──██████████──█");
        gotoxy(i, 11);
        puts("─────███████████████");
        gotoxy(i, 12);
        puts("─────███████████████");
        gotoxy(i, 13);
        puts("──────█████████████");
        gotoxy(i, 14);
        puts("───────███████████");
        gotoxy(i, 15);
        puts("─────────████████");
        gotoxy(i, 16);
        puts("──────────███──██");
        gotoxy(i, 17);
        puts("──────────██────█");
        gotoxy(i, 18);
        puts("──────────█─────█");
        gotoxy(i, 19);
        puts("──────────██────██");
        usleep(10000);
    }
}

int kbhit()
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if(ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}

int getch(void)
{
    int ch;
    struct termios buf;
    struct termios save;

    tcgetattr(0,&save);
    buf=save;
    buf.c_lflag&=~(ICANON|ECHO);
    buf.c_cc[VMIN]=1;
    buf.c_cc[VTIME]=0;
    tcsetattr(0,TCSAFLUSH,&buf);
    ch=getchar();
    tcsetattr(0,TCSAFLUSH,&save);

    return ch;
}

void gotoxy(int x, int y)
{
    printf("\e[%d;%df", y, x);
    fflush(stdout);
}

void removeCursor()
{
    printf("\e[?25l");
    fflush(stdout);
}


