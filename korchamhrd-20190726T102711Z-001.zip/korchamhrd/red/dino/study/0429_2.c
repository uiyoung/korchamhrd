#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <termios.h>

typedef struct _player
{
	char name;		// 이름 (랭킹)
	int xPos;		// 유저 x좌표
	int yPos;		// 유저 y좌표
	int heart;		// 유저 체력
	int score;		// 유저 점수
}Player;

void maps(int map[][20],Player *p1,int *speed);
int getch();
void gotoxy(int x, int y);
void *thread_MovingKey(void* p1);

int main (int argc, char **argv)
{
	Player *p1;
	pthread_t t_id;
	void *t_return;
	int state;
	
	p1->heart=3;
	p1->xPos=2;
	p1->yPos=2;
	
	int speed=500000;		// usleep 안에 들어갈꺼임.
	int map[4][20]={		// map 넓이는 4*20
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3};
//	1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6,7,8,9,0
	
	
	//maps(map, p1,&speed);
	state=pthread_create(&t_id, NULL,thread_MovingKey,(void*)p1);
	if(state!=0) {
		puts("쓰레드 Join 오류\n");
		exit(1);
		}
	printf("생성된 쓰레드의 ID : %d \n",(int) t_id);
	/* 
	if(time%100==0)				// 플레이 시간 100초가 넘어갈시 스피드 증가.
	{
		speed-=1000*500;
	}
	if(p1.heart<=0)				// You Die.
	{
		printf("Your Score : %d\n",p1.score);
		printf("You Die\n");
	}
	*/
	return 0;
}

void maps(int map[][20],Player *p1,int *speed)
{
	int x,y,a;				// 맵 생성할 임의의 변수
	int obs1=19;			// 변할 장애물
	int obs2=19;			// 장애물 원상복구
	printf("x : %d, y : %d\n",p1->xPos,p1->yPos);
	while(1)
	{
		map[p1->yPos][p1->xPos]=1;
		map[2][obs1]=2;
		system("clear");
		for(a=0;a<p1->heart;a++)
		{
			printf("♥ ");
		}
		printf("\n\n");
		
		for(y=0;y<4;y++)
		{
			for(x=0;x<20;x++)
			{
				if(map[y][x]==0)
				{
					printf(". ");
				}
				if(map[y][x]==1)		// @ 플레이어
				{
					printf("@ ");
				}
				if(map[y][x]==2)
				{
					printf("▲ ");
				}
				if(map[y][x]==3)
				{
					printf("■ ");
				}
			}
			printf("\n");
		}
		if(map[2][obs1]==2)
		{
			map[2][obs2]=0;
		}
		obs1--;
		obs2--;
		if(obs1<0)
		{
			obs1=19;
			obs2=19;
		}
		usleep(*speed);
	}
}
void gotoxy(int x, int y)
{
     printf("\033[%d;%df",y,x);
     fflush(stdout);
}

int getch()
{
    int c;
    struct termios oldattr, newattr;

    tcgetattr(STDIN_FILENO, &oldattr);           // 현재 터미널 설정 읽음
    newattr = oldattr;
    newattr.c_lflag &= ~(ICANON | ECHO);         // CANONICAL과 ECHO 끔
    newattr.c_cc[VMIN] = 1;                      // 최소 입력 문자 수를 1로 설정
    newattr.c_cc[VTIME] = 0;                     // 최소 읽기 대기 시간을 0으로 설정
    tcsetattr(STDIN_FILENO, TCSANOW, &newattr);  // 터미널에 설정 입력
    c = getchar();                               // 키보드 입력 읽음
    tcsetattr(STDIN_FILENO, TCSANOW, &oldattr);  // 원래의 설정으로 복구
    
    return c;
}
void *thread_MovingKey(void* p1)
{
	int key;
	Player *p2=(Player*) p1;

	
	while(1)
	{
		key=getch();
		if (key==27){
			key=getch();
			if (key==91){
				key=getch();
				switch(key)
				{
					case 65 :
		//				p2->yPos-=1;
					break;
					case 66 :
			//			p2->yPos+=1;
					break;

					default :
					break;
				}
			}
		}
	}
	
}
