#include <stdio.h>
#include <string.h>

typedef struct _Player
{
    char name[30];
    int level;
    int gold;
} Player;


void PrintPlayerInfo(Player p);
void LevelUp(Player *p);

int main()
{
    int choice;

    FILE *fp = NULL;
    Player p = {"", 1, 1000};
    printf("이름 입력>>");
    scanf("%s", p.name);

    while(1)
    {
        puts("────────────────────");
        puts("[0]종료");
        puts("[1]플레이어 정보");
        puts("[2]lev up");
        puts("[3]세이브");
        puts("[4]로드");
        puts("────────────────────");
        printf(">>");
        scanf("%d", &choice);

        switch(choice)
        {
            case 0:
                return 0;
            case 1:
                PrintPlayerInfo(p);
                break;
            case 2:
                LevelUp(&p);
                break;
            case 3:
                fp = fopen("data.bin", "wb");
                fwrite(&p, sizeof(p), 1, fp);
                puts("세이브 성공");
                break;
            case 4:
                fp = fopen("data.bin", "rb");
                fread(&p, sizeof(p), 1, fp);
                puts("로드 완료");
                break;
        }
    }
    fclose(fp);

    return 0;
}

void PrintPlayerInfo(Player p)
{
    printf("name : %s\n", p.name);
    printf("lev : %d\n", p.level);
    printf("gold : %d\n", p.gold);
}

void LevelUp(Player *p)
{
    p->level++;
    printf("레벨업! %s의 레벨이 %d가 되었습니다.\n", p->name, p->level);
}
