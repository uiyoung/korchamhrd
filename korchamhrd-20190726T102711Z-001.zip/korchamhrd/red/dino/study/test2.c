#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct _item
{
    char name[50];
    int amount;
} Item;

void PrintItems(Item items[], int idx);

int main()
{
    int arrLength=0;  // 초기 배열 크기 
    Item *items = (Item*)malloc(sizeof(Item));
    int idx = 0;
    char tempName[50] = {0};
    int tempAmount = 0;
    int isDuplicated;   // 중복 체크변수

    while(1)
    {
        isDuplicated = 0;
        printf("아이템명(종료:exit)>>");
        scanf("%s", tempName);

        if(strcmp(tempName, "exit")==0)
            break;

        printf("수량>>");
        while(getchar()!='\n');
        scanf("%d", &tempAmount);

        // 중복체크 : 이미 가지고있는 아이템인경우 수량만 증가
        for(int i=0;i<idx;i++)
        {
            if(strcmp(items[i].name, tempName)==0)
            {
                items[i].amount += tempAmount;
                isDuplicated = 1;
                break;
            }
        }

        // 중복아이템이 아닌 경우 
        if(!isDuplicated)
        {
            strcpy(items[idx].name, tempName);
            items[idx].amount = tempAmount;

            if(idx+1>=arrLength)
            {
                // 배열이 가득 찬 경우 크기 재할당
                arrLength+=3; //배열 길이++
                items = (Item*)realloc(items, sizeof(Item) * arrLength);
            }
            idx++;
        }
    }

    //print
    PrintItems(items, arrLength);

    free(items);

    return 0;
}

void PrintItems(Item items[], int idx)
{
    puts("----------inventory----------");
    for(int i=0;i<idx;i++)
    {
        printf("%s : ", items[i].name);
        printf("%d개\n", items[i].amount);
    }
}
