#include <stdio.h>

void plus(int *pNum)
{
    *pNum+=1;
    printf("%d\n", *pNum);
}

int main()
{
    int num = 1;
    printf("%d\n", num);
    plus(&num);
    printf("%d\n", num);

    return 0;
}
