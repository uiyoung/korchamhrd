#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct _Player
{
    int xPos;
    int yPos;
    int hp;
} Player;

void DrawMap(int **map, int row, int col, Player p);
void InitPlayer(Player *p, int **map, int row, int col);
void Move(int **map, Player *p, int direction, int row, int col);
void Damage(Player *p);
void CheckDeath(Player p);

int main()
{
    int col, row;
    int choice;

    FILE * fp;
    int **map;  //map[row][col]

    //level:hard
    row = 20;
    col = 20;
    fp = fopen("hard.txt", "r");

    // int*형의 원소를 row개 가지는 1차원배열 생성
    map = (int **)malloc(sizeof(int *) * row);

    // 각 행을 동적할당하여 포인터배열에 연결
    for(int i=0;i<row;i++)
        map[i] = (int *)malloc(sizeof(int) * col);

    // load map from txt file 
    for(int i=0;i<row;i++)
        for(int j=0;j<col;j++)
            fscanf(fp, "%d", &map[i][j]);

    // init player
    Player p;
    InitPlayer(&p, map, row, col);

    int destX;
    int destY;

    while(1)
    {
        DrawMap(map, row, col, p);
        printf("(%d, %d), hp:%d\n", p.xPos, p.yPos, p.hp);
        puts("[1]상 [2]하 [3]좌 [4]우");
        scanf("%d", &choice);

        if(choice >4 || choice <1)
            break;

        Move(map, &p, choice, row, col);
        CheckDeath(p);
    }

    fclose(fp);

    // 각 행의 동적할당 영역 반환
    for(int i=0;i<row;i++)
        free(map[i]);

    // 포인터배열처럼 사용하는 동적할당 영역 반환
    free(map);

    return 0;
}

void DrawMap(int **map, int row, int col, Player p) 
{
    system("clear");

    for(int i=0;i<row;i++)
    {
        for(int j=0;j<col;j++)
        {
            if(map[i][j] == 0)
                printf("  ");
            else if(map[i][j] == 1)
                printf("■ ");
            else if(map[i][j] ==3)
                printf("@ ");
            else if(map[i][j] == 4)
                printf("★ ");
        }
        putchar('\n');
    }
}

void InitPlayer(Player *p, int **map, int row, int col)
{
    p->hp = 100;
    for(int i=0;i<row;i++)
    {
        for(int j=0;j<col;j++)
        {
            if(map[i][j]==3)
            {
                p->yPos = i;
                p->xPos = j;
                return;
            }
        }
    }
}

void Move(int **map, Player *p, int direction, int row, int col)
{
    // 이동 전 위치는 0으로 변경
    map[p->yPos][p->xPos] = 0;

    switch(direction)
    {
        case 1:
            p->yPos--;

            if(p->yPos<0)
                p->yPos = 0;

            break;
        case 2:
            p->yPos++;

            if(p->yPos>col-1)
                p->yPos = col-1;

            break;
        case 3:
            p->xPos--;

            if(p->xPos<0)
                p->xPos = 0;

            break;
        case 4:
            p->xPos++;

            if(p->xPos>row-1)
                p->xPos = row-1;

            break;
    }

    if(map[p->yPos][p->xPos]==1)
        Damage(p);

    if(map[p->yPos][p->xPos]==4)
    {
        puts("clear");
        exit(1);
    }

    // 이동 후 위치 3으로 변경
    map[p->yPos][p->xPos] = 3;
}

void Damage(Player *p)
{
    p->hp -= 10;
    puts("불에 닿아 10만큼의 데미지를 입었습니다.");
}

void CheckDeath(Player p)
{
    if(p.hp <=0)
    {
        puts("사망");
        exit(0);
    }
}

