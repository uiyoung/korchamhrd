#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *arr = (int*)malloc(sizeof(int));
    int idx = 0;
    int size = 1;
    int num;

    while(1)
    {
        printf(">>");
        scanf("%d", &num);

        if(num==0)
            break;

        size++;
        arr = (int*)realloc(arr, sizeof(int)*size);
        arr[idx++] = num; 
    }

    for(int i=0;i<idx;i++)
        printf("i : %d\n", arr[i]);

    free(arr);

    return 0;
}
