#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <time.h>
#include <semaphore.h>
#include <stdio_ext.h>

#define BUFFSIZE 100
#define NAMESIZE 20

#define RED1 printf("%c[1;31m", 27);
#define DEF1 printf("%c[0m", 27);
#define BLUE1 printf("%c[34m", 27);
#define GREEN1 printf("%c[32m", 27);
#define YELLOW1 printf("%c[33m", 27);
#define PURPLE1 printf("%c[35m", 27);


#define RED     "\x1b[91m"
#define GREEN   "\x1b[92m"
#define YELLOW  "\x1b[93m"
#define BLUE    "\x1b[94m"
#define MAGENTA "\x1b[95m"
#define CYAN    "\x1b[96m"
#define GRAY	"\x1b[90m"
#define DEF   	"\x1b[0m"
#define ROW 30 // 맵의 세로   default: 30
#define COL 100 // 맵의 가로  default: 120
#define COLOR printf("\x1b[38;2;%d;%d;%dm",col->r,col->g,col->b); // 불 색깔 RGB

typedef struct _color
{
    int r, g, b; // 불 색상
}color;

struct timer{
    int mi;
    double s;
    int hp;
    int tot;///////////////////////////////////////
};
typedef struct GameImfo
{
    int score[4];                       //실시간 점수
    int destence[4];                    //실시간 거리
    int time[4];                        //실시간 시간
    char play_name[4][NAMESIZE];        //실시간 플레이어 이름
    
}GI;

typedef struct _RankData
{
    char name[NAMESIZE];
    int score;
    int timeRecord;
    int distance;
    char date[20];
} RankData;

typedef struct client
{
    int gameOn;                 //게임 시작 유무
    int sock;                   //클라이언트 소켓
    char name[NAMESIZE];        //이름 배열
    char message[BUFFSIZE];     //메세지 배열
    GI I;

    int x, y; // 캐릭터 좌표
    int hp;
    int hp_max;///////////////////////////////////////////////////////////////////
    int item[6]; // x
    int hdl; // 장애물 나오는 개수 설정
    int ch_stat; // 1: 걷기[1] 2: 걷기[2] 3: 공중(점프 상태)
    int ch_movcnt; // 걷기[1], 걷기[2] 스위칭
    int ch_select; // 캐릭터 선택
    int jmp; // 점프 개수 0이면 점프 못함
    int jmp_cnt; // 점프 구현
    int jmp_snd; // 2단 점프 전용 

	int dis_cnt; // 거리 카운트 
	int distanse; // 거리 
    int score; 
    int score_up;//점수 두배관련
    int invincible;//무적여부					
    int speed_up;//스피드..
	int h_index;	// 멀티 방해아이템1 시간
	int number[4];		// 사람 숫자
	char atk[NAMESIZE];
	int d_time; //죽은 시간 저장
	
}Clnt;

typedef struct server
{
    int serv_sock;                  //서버 소켓
    int clnt_sock;                  //클라 소켓
    int clnt_number;                //인원수
    int clnt_socks[10];             //크라 소켓 저장 공간
    int ready[4];                   //준비 상태 체크
    char playername[4][NAMESIZE];   //플레이어 이름 저장 배열
    int ex_number;                  //강퇴 번호
    pthread_mutex_t mutx;
	
}Serv;

//게임
void game(void *P);                            //게임 시작
void init_map(int map[ROW][COL]); // 맵 초기화
void draw_map(Clnt *p, int map[ROW][COL], struct timer *ti_s, color *col); // 배열 실시간 출력
void draw_char(Clnt *p, int map[ROW][COL]); // 플레이어 화면에 출력
void hurdle(Clnt *p, int map[ROW][COL], int *cnt,int* h_cnt, int* b_cnt,int*h_shape, int*item_random); // 장애물 생성
void clear_char(Clnt *p, int map[ROW][COL]); // 점프시 캐릭터 잔상 제거
void jmp_char(Clnt *p, int map[ROW][COL]); // 점프하는 함수
void mov_char(Clnt *p, int map[ROW][COL]); // 캐릭터 모션
void collp_char(Clnt *p, int map[ROW][COL],struct timer *ti_s); // 캐릭터와 물체 상호작용
int getch(void); // 키보드의 값을 입력 받음
int kbhit(void); // 키보드를 눌렀는지 확인
void gotoxy(int x, int y); // 커서 이동함수
void end_game(color *col); // 게임 끝
void intro(void); // 게임 인트로 
//타이머 스레드//
void *t_func(void *data);
pthread_mutex_t mutx;
//캐릭터스킬관련
void ch_skill(struct timer* ti_s,Clnt * p);
void get_score(Clnt *p,int map[ROW][COL]);//점수=(거리*플레이어위치효과)+장애물 넘은 여부
void buff_recv(Clnt *p, struct timer *ti_s);//보너스 시간지나면 돌아오게.

///// 버블 정렬
void bubble_sort(void *p);
void i_swap(int *a, int *b);

///////서버클라

void Server(Serv *sev);         //서버
void *clnt_connection(void *arg);   //메세지 수신 및 접속
void *clnt_exit(void *vp);          //강퇴 기눙
void s_send_message(char* message,int len,Serv *sev); //메세지 전송
void error_handling(char *message);

void *c_send_message(void *vp);     //클라 메세지 전송
void *c_recv_message(void *vp);     //클라 메세지 수신
void Client(Clnt *clt);             //클라이언트
void manue(void);                   //서버 매뉴
void menu2();
void *g_start(void *vp);//메시지 전송 쓰레드 실행 함수
void c_menu(Clnt *clt);             //채팅 매뉴

// ranking
void RecieveRanking();
void SaveRanking(char* str);
void PrintRanking(int sortby);
void QuickSort(RankData* rd, int left, int right, int sortby);
void Swap(RankData* rd, int a, int b);
char* SimpleRanking(RankData* rd);

int main(void)
{
    Serv sev;
    Clnt clt;
    sev.clnt_number=0;
    clt.gameOn=0;

    srand(time(NULL));
    //변수 초기화
     for(int i=0;i<4;i++)
    {
        for(int j=0;j<NAMESIZE;j++)
        {
            sev.playername[i][j]='\0';
            clt.I.play_name[i][j]='\0';
        }
        clt.I.play_name[i][0]='0';
        clt.I.score[i]=0;
        sev.ready[i]=0;
        sev.clnt_socks[i]=0;
    }

    int choice;
    //서버 클라 선택
    manue();
    scanf("%d",&choice); 
    switch (choice)
    {
        case 1:
            Server(&sev);
            break;
        case 2:
            Client(&clt);
            break;
        default:
            break;
    }

    return 0;
}


void Server(Serv *sev)
{

    struct sockaddr_in serv_addr;
    struct sockaddr_in clnt_addr;
    int clnt_addr_size;
    pthread_t thread;
    pthread_t thread2;
    char sev_port[10];


    if(pthread_mutex_init(&sev->mutx,NULL))
        error_handling("mutex init error");

    sev->serv_sock=socket(PF_INET,SOCK_STREAM,0);//서버 소켓 생성
    if(sev->serv_sock==-1)
        error_handling("socket() error");

    GREEN1
        printf("=========*====*====*===============\n");
    DEF1
        printf(" 방 번호를 입력해주세요.(2000~9999)\n");

    GREEN1 
        printf("=========*====*====*===============\n");
    DEF1
        printf(" >>");	
    scanf("%s",sev_port);
    printf(" 방번호는 %s 입니다.\n",sev_port);
    GREEN1
        printf("=========*====*====*===============\n");
    DEF1
        //주소 정보 구조체 변수 초기화 시작
        memset(&serv_addr,0,sizeof(serv_addr));
    serv_addr.sin_family=AF_INET;
    serv_addr.sin_addr.s_addr=htonl(INADDR_ANY);//자기 자신의 IP 가져옴
    serv_addr.sin_port=htons(atoi(sev_port));   //방번호(포트번호)
    //주소 정보 구조체 변수 초기화 끝

    if(bind(sev->serv_sock,(struct sockaddr*)&serv_addr,sizeof(serv_addr))==-1)//소켓에 주소 할당
        error_handling("이미 생성된 방번호 입니다.\n");

    if(listen(sev->serv_sock,4)==-1)                    //연결 요청 대기 상태로 진입 큐의 크기 5
        error_handling("listen() error");
    while(1)
    {
        clnt_addr_size=sizeof(clnt_addr);
        //인원수 제한 
        if(sev->clnt_number>4)
        {
            continue;
        }
        sev->clnt_sock=accept(sev->serv_sock,(struct sockaddr*)&clnt_addr,&clnt_addr_size);   //연결 요청 수락

        pthread_mutex_lock(&sev->mutx);
        sev->clnt_socks[sev->clnt_number++]=sev->clnt_sock;
        pthread_mutex_unlock(&sev->mutx);
        pthread_create(&thread,NULL,clnt_connection,(void*)sev);        //수신쓰레드 생성
        pthread_create(&thread2,NULL,clnt_exit, (void*)sev);        //강퇴쓰레드 생성
        usleep(50000);
        YELLOW1
            printf("새로운 연결,클라이언트 IP : %s 소켓 번호:%d 참여 인원수 : %d 닉네임 : %s \n",inet_ntoa(clnt_addr.sin_addr),sev->clnt_sock,sev->clnt_number,sev->playername[sev->clnt_number-1]);
        DEF1
    }
}



void *clnt_connection(void *vp)
{
    Serv *sev = (Serv*)vp;
    int clnt_sock=sev->clnt_sock;
    int str_len=0;
    char message[BUFFSIZE];
    int i;
    int count=0;
    //접속시 네임 배열에 이름 초기화
    read(sev->clnt_sock,message,sizeof(message));
    //이름이 같으면(1) 추가
    for(i=0;i<sev->clnt_number;i++)
    {
        if(!strcmp(sev->playername[i],message))
        {
            sprintf(message,"%s(1)",message);
        }
    }
    str_len=sizeof(message);
    write(sev->clnt_socks[sev->clnt_number-1],message,str_len); //클라이언트에 이름 전송
    strcpy(sev->playername[sev->clnt_number-1],message);    //처음 보내온 이름메시지를 이름 배열에 저장
    sev->ready[sev->clnt_number-1]=1;           //레디 1로 만들어줌 (준비 전)

    //strcpy(message,"\0");

    while((str_len=read(clnt_sock,message,sizeof(message)))!=0) //메세지 전송받으면 
    {
        

        for(i=0;i<4;i++)
        {   
            if(!strcmp(message,sev->playername[i])) //전종된 이름이 배열의 이름과 같으면
            {
                if(sev->ready[i]==0)            //준비 완료 일때
                {
                    sev->ready[i]=1;
                    sprintf(message,"[%s] ready X\n",sev->playername[i]);
                    str_len=sizeof(message);   
                }
                else if(sev->ready[i]==1)       //준비 전일때
                {
                    sev->ready[i]=0;
                    sprintf(message,"[%s] ready O\n",sev->playername[i]);
                    str_len=sizeof(message);
                    usleep(1000);
                }
            }
        }
        
        if(!strncmp(message,"*",1))
        {
            SaveRanking(message);
        }
        

        //모두 ready 시 게임 시작
        if((sev->ready[0]+sev->ready[1]+sev->ready[2]+sev->ready[3])==0)
        {
            sprintf(message,"game_start\n");
            str_len=sizeof(message);
             for(i=0; i<sev->clnt_number; i++)
            {
                sev->ready[i]=1;
            }
        }
        //게임 종료시 ready 초기화
        if(!strcmp(message,"end\n"))
        {
            for(i=0; i<sev->clnt_number; i++)
            {
                sev->ready[i]=1;
            }
        }
        // rank 입력시
        if(strstr(message, "rank")!=NULL)
        {
            RankData rd[5];
            char rankMessage[500];
            sprintf(rankMessage, "\n\n%s", SimpleRanking(rd)); 
            s_send_message(rankMessage,sizeof(rankMessage), sev);//메세지 전송
        }

        printf("%s",message);
        s_send_message(message,str_len,sev);//메세지 전송
        //버퍼 초기화
        for(int i=0;i<BUFFSIZE;i++)
        {
            message[i]='\0';
        }

    }
    pthread_mutex_lock(&sev->mutx);
    //강퇴시or 종료시 배열 정렬
   sev->clnt_socks[sev->ex_number-1]=0;
	for(i=0 ;i < sev->clnt_number;i++)
	{
		if(sev->clnt_socks[i]==0)
		{
			sev->clnt_socks[i]=sev->clnt_socks[i+1];
			sev->clnt_socks[i+1]=0;
			strcpy(sev->playername[i]," ");
			strcpy(sev->playername[i],sev->playername[i+1]);
			strcpy(sev->playername[i+1]," ");
			sev->ready[i]=0;
			sev->ready[i]=sev->ready[i+1];
			sev->ready[i+1]=0;
		}
	}
	usleep(100000);
	sev->clnt_number--;
	printf("\n (채팅자 (%d/4))", sev->clnt_number);
	printf(" 클라이언트가 접속 종료 되었습니다.\n");
    pthread_mutex_unlock(&sev->mutx);

    close(sev->clnt_sock);
    return 0;
}

void s_send_message(char* message,int len, Serv *sev)       //메세지 전송
{
    int i;

    pthread_mutex_lock(&sev->mutx);         
    for(i=0; i<sev->clnt_number; i++)
        write(sev->clnt_socks[i],message,len);
    pthread_mutex_unlock(&sev->mutx);
}


void *clnt_exit(void *vp)
{
    Serv *sev = (Serv*)vp;
    int clnt_sock=sev->clnt_sock;
    char message[BUFFSIZE];
    int d=1;

    while(1) 
    {
        int choice;

        menu2();
        puts("[1] 강퇴 [2] 랭킹");
        scanf("%d", &choice);

        if(choice == 1) 
        {
            printf("\n<현재 접속 인원>\n\n");
            printf("강퇴를 원하시면 해당 유저의 번호를 입력해 주세요. \n");
            for(int i=0; i<sev->clnt_number; i++)
            {
                printf("%d번 > 소켓 번호 : %d , 닉네임 : %s \n", d++, sev->clnt_socks[i], sev->playername[i]);
            }

            scanf("%d", &sev->ex_number);

            for(int i=0; i<sev->clnt_number; i++)
            {
                if(sev->clnt_socks[i]==sev->clnt_socks[sev->ex_number-1])
                {
                    printf("소켓 번호 : %d , 닉네임 : %s 를 강퇴합니다.\n\n", sev->clnt_socks[i], sev->playername[i]);
                    sprintf(message,"%s", sev->playername[i]);
                    printf("%s 데이터를 전송합니다.\n",message);
                    pthread_mutex_lock(&sev->mutx); 
                    for(i=0; i<sev->clnt_number; i++)
                    {
                        write(sev->clnt_socks[i],message,strlen(message));
                    }
                    for(int i=0;i<BUFFSIZE;i++)
                    {
                        message[i]='\0';
                    }
                    pthread_mutex_unlock(&sev->mutx);

                    break;
                }
            }
            d=1;
        }
        else if(choice == 2)
        {
            PrintRanking(1);
        }
   }

    return 0;
}
//클라
void Client(Clnt *clt)
{
    struct sockaddr_in serv_addr;
    pthread_t snd_thread,rcv_thread,game_start;
    void *thread_result;
    char c_port[10],c_ip[30]="10.10.20.253"; //아이피 포트번호


    GREEN1 
        printf("=========*====*====*===============\n");
    DEF1
        printf(" 방 번호를 입력 해주세요(2000~9999)\n");
    GREEN1 
        printf("=========*====*====*===============\n");
    DEF1
        printf(" >>");
    scanf("%s",c_port);
    printf(" 닉네임을 입력해 주세요\n");
    GREEN1
        printf("=========*====*====*===============\n ");
    DEF1
        printf(" >>");
        scanf("%s",clt->name);
        //명령어 이름 설정 금지
        if(strcmp(clt->name,"ready")==0||strcmp(clt->name,"end")==0||strcmp(clt->name,"game_start")==0||strcmp(clt->name,"rank")==0)
        {
            printf("명령어는 닉네임으로 설정 할 수 없습니다.\n >>");
            scanf("%s",clt->name);
        }
    getchar();

    clt->sock=socket(PF_INET,SOCK_STREAM,0);         //서버 접속을 위한 소켓 생성
    if(clt->sock==-1)
        error_handling("socket() error");
    //연결 요청전 구조체 초기화(연결 요처을 할 서버의 주소 정보를 가지고 구조체 변수를 초기화)
    memset(&serv_addr,0,sizeof(serv_addr));
    serv_addr.sin_family=AF_INET;
    serv_addr.sin_addr.s_addr=inet_addr(c_ip);
    serv_addr.sin_port=htons(atoi(c_port));

    if(connect (clt->sock,(struct sockaddr*)&serv_addr,sizeof(serv_addr))==-1)//서버로 연결 요청
        error_handling("connent() error!");

    //전송 수신 쓰레드 생성
    pthread_create(&snd_thread,NULL,c_send_message,(void*)clt);			// 보내는거 상시 대기
    pthread_create(&rcv_thread,NULL,c_recv_message,(void*)clt);			// 받는거 상시 대기
    pthread_create(&game_start,NULL,g_start,(void*)clt);				// o,1 검사 

    pthread_join(snd_thread,&thread_result);
    pthread_join(rcv_thread,&thread_result);
    pthread_join(game_start,&thread_result);
    close(clt->sock);                                //연결 종료
}

void *c_send_message(void *vp)//메시지 전송 쓰레드 실행 함수
{
    Clnt *clt=(Clnt*)vp;
    char s_name_message[NAMESIZE+BUFFSIZE];
    int sendOn=0; 
	int str_len;
    //sprintf(name_message,"%s",clt->name);
    //이름 서버로 전송
	write(clt->sock,clt->name,strlen(clt->name));
    str_len=read(clt->sock,s_name_message,NAMESIZE+BUFFSIZE-1);       //서버에서 이름수신(중복 체크)
    strcpy(clt->name,s_name_message);                               //서버에서 온 이름 저장
    while (1)
    {
        if(clt->gameOn==0)
        {
            fgets(clt->message,BUFFSIZE,stdin);
            if(!strcmp(clt->message,"q\n"))//q입력시 종료
            {
                close(clt->sock);
                exit(0);
            }
            //레디 입력시
            if(!strcmp(clt->message,"ready\n"))
            {
                sprintf(s_name_message,"%s",clt->name); //이름을 저장
                write(clt->sock,s_name_message,strlen(s_name_message));//이름을 보내줌
                for(int i=0;i<BUFFSIZE+BUFFSIZE;i++)        //메시지 배열 초기화
                {
                    s_name_message[i]='\0';
                }
                usleep(10000);
                continue;
            }
            sprintf(s_name_message,"[%s] %s",clt->name,clt->message);   //이름 +메세지 저장
            write(clt->sock,s_name_message,strlen(s_name_message));     //이름+메세지 전송
            for(int i=0;i<BUFFSIZE+BUFFSIZE;i++)                    //메세지 버퍼 초기화
            {
                s_name_message[i]='\0';
            }
        }
        else if(clt->gameOn==1)//
        {

			// 멀티아이템 1번 send
            if(clt->item[0]!=0)
            {
                clt->item[0]=0;
                sprintf(s_name_message,"%s item\n",clt->name);//아이템 사용시 아이템글자전달
                write(clt->sock,s_name_message,strlen(s_name_message));//보내줌
                for(int i=0;i<BUFFSIZE+BUFFSIZE;i++)
                {
                    s_name_message[i]='\0';
                }
            }
			// 멀티 아이템 2번 send
			if(clt->item[2]!=0)
            {
                clt->item[2]=0;
                sprintf(s_name_message,"%s item2\n",clt->name);//아이템 사용시 아이템글자전달
                write(clt->sock,s_name_message,strlen(s_name_message));//보내줌
                for(int i=0;i<BUFFSIZE+BUFFSIZE;i++)
                {
                    s_name_message[i]='\0';
                }
            }
            //스코어
            usleep(500000);
            sprintf(s_name_message,"%s %d \n",clt->name,clt->score);
            write(clt->sock,s_name_message,strlen(s_name_message));
             for(int i=0;i<BUFFSIZE+BUFFSIZE;i++)
                {
                    s_name_message[i]='\0';
                }
        }
		if(clt->hp==-100) // 죽었을때 최종 메세지 전송<!>
		{	
			clt->hp==0;	
			sprintf(s_name_message,"* %s %d %d %d",clt->name, clt->d_time, clt->score, clt->distanse);//아이템 사용시 아이템글자전달
            write(clt->sock,s_name_message,strlen(s_name_message));//보내줌
            for(int i=0;i<BUFFSIZE+BUFFSIZE;i++)
            {
                    s_name_message[i]='\0';
            }
		}
		
		
    }
}



void *c_recv_message(void *vp)
{
    Clnt *clt=(Clnt*)vp;
    c_menu(clt);

    char name_message[NAMESIZE+BUFFSIZE];
    int str_len;
    int y=1;

    while(1)
    {
        str_len=read(clt->sock,name_message,NAMESIZE+BUFFSIZE-1);       //서버에서 메세지 수신
		if(clt->gameOn==0&&strncmp(name_message,"*",1))
        {

            if(!strcmp(name_message,"game_start\n"))                    //받은 메시지가 gamestart면 게임 시작
            {
                clt->gameOn=1;
                continue;
            }

            if(!strcmp(name_message,clt->name))
            {
                printf("강퇴됨 너는\n");
                close(clt->sock);
                exit(0);
            }
        
            name_message[str_len]=0;
            gotoxy(0,y+22);                                                //채팅 시작 위치 조정
            GREEN1
                fputs(name_message,stdout);                                 //수신한 메세지 화면에 출력
            y+=1;
            DEF1
                if(y==20)
                {
                   c_menu(clt);

                    y=1;
                }
            for(int i=0;i<BUFFSIZE+NAMESIZE;i++)
            {
                name_message[i]='\0';
            }

        }
        else if(clt->gameOn==1&&strncmp(name_message,"*",1))//
        {
			
             if(strncmp(name_message,"[",1)&&strncmp(name_message,"game",4)&&strncmp(name_message,"end",3))
            {
			    char *ptr = strtok(name_message," ");
				if(strcmp(ptr+1,"item\n")&&strcmp(ptr+1,"item2\n"))
                {
                    //실시간 스코어 
                    for(int i=0;i<4;i++)
                    {
                        if(clt->I.play_name[i][0]=='0')
                        {
                            strcpy(clt->I.play_name[i],ptr);
                            clt->I.score[i]=atoi(ptr+(strlen(clt->I.play_name[i])+1));
                            break;
                        }
                        else if(!strcmp(clt->I.play_name[i],ptr))
                        {
                            clt->I.score[i]=atoi(ptr+(strlen(clt->I.play_name[i])+1));
                            break;
                        }
                    }
                }
                //실시간 아이탬 사용
				strcpy(clt->atk, ptr);			
				if(strcmp(ptr,clt->name)&&(strcmp(ptr+strlen(ptr)+1,"item\n")==0))
				{
					clt->item[1]=1;
				}
				
				if(strcmp(ptr,clt->name)&&strcmp(ptr+strlen(ptr)+1,"item2\n")==0)
				{
					clt->item[3]=1;				
				}
            }
            for(int i=0;i<BUFFSIZE+NAMESIZE;i++)
            {
                name_message[i]='\0';
            }
        }
    }
}

void error_handling(char *message)
{
    fputs(message,stderr);
    fputc('\n',stderr);
    exit(1);
}

void manue(void)                                            //서버 매뉴 츌력
{
    system("clear");
    RED1     
    printf(" () () *╦═╗╔═╗╔╦╗╔╦╗╔═╗╔═╗╔╦╗*() ()\n");
    printf(" ('Y') *╠╦╝║╣  ║║ ║ ║╣ ╠═╣║║║*(':')\n");
    printf(" q . p *╩╚═╚═╝═╩╝ ╩ ╚═╝╩ ╩╩ ╩*d . b\n");
    printf(" ()_() ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■  ()_()\n");
    DEF1   
        GREEN1
        printf("=========*====*====*===============\n");
    DEF1                      

        YELLOW1
        printf("1.방생성 | 2.접 속  | 3.이상.종료\n");
    DEF1 

        GREEN1 
        printf("=========*====*====*===============\n");
    DEF1
        printf(" >>");
}

void menu2()
{
    system("clear");
    GREEN1
        printf("=========*====*====*===============\n");
    RED1     
        printf(" () () *╦═╗╔═╗╔╦╗╔╦╗╔═╗╔═╗╔╦╗*() ()\n");
    printf(" ('Y') *╠╦╝║╣  ║║ ║ ║╣ ╠═╣║║║*(':')\n");
    printf(" q . p *╩╚═╚═╝═╩╝ ╩ ╚═╝╩ ╩╩ ╩*d . b\n");
    printf(" ()_() ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■  ()_()\n");
    DEF1   
        GREEN1
        printf("=========*====*====*===============\n");
    DEF1  
}

void c_menu(Clnt *clt)      //채팅 매뉴출력
{
    system("clear");
    gotoxy(1,0);
    GREEN1
        printf("*■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■\n");
    printf("╔═╗┬ ┬┌─┐┌┬┐┌┬┐┬┌┐┌┌─┐*********************************************\n");
    printf("║  ├─┤├─┤ │  │ │││││ ┬☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ \n");
    printf("╚═╝┴ ┴┴ ┴ ┴  ┴ ┴┘└┘└─┘\n");
    DEF1
        YELLOW1
        printf("    _.________   \n");
    printf("    | _______ |\n");
    printf("    ||,-----.||       1.상대방을 모욕하는 욕설을 사용하지맙시다.\n");
    printf("    |||     |||       2.인터넷  뒤에 사람이  있음을  명심합시다.\n");
    printf("    |||_____|||       3.상업용 광고나 도배를  자제하도록 합시다.\n");
    printf("    |`-------'| red           0/    *   *   .   .  *  .   .  * \n");
    printf("    | +     O | 2019         /7   .   *   .     *  .   .     . \n");
    printf("    |      O  |             '(     .  .    .  *   .  *    .     *\n ");
    printf("   | / /  ##,*             / \n");
    printf("     `------*  ----------------------------------------------------\n");
    DEF1
        BLUE1
        printf(" 명령어 : 1.[ready] 2.[rank] 3.[q(종료)]     *N a m e : %s\n",clt->name);
        GREEN1
    printf(" () () *╦═╗╔═╗╔╦╗╔╦╗╔═╗╔═╗╔╦╗*() ()\n");
    printf(" ('Y') *╠╦╝║╣  ║║ ║ ║╣ ╠═╣║║║*(':')☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ ☆ ★ \n");
    printf(" q . p *╩╚═╚═╝═╩╝ ╩ ╚═╝╩ ╩╩ ╩*d . b*********************************\n");
    printf("*()_() ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■  ()_() ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■\n");
    DEF1 
        printf("\n");
    printf("\n");
    printf("\n");
}




































void *g_start(void *vp)//메시지 전송 쓰레드 실행 함수
{
    Clnt *clt=(Clnt*)vp;
    char name_message[NAMESIZE+BUFFSIZE];
    int str_len;
    while (1)
    {
        if(clt->gameOn==1)
        {
            game(clt);
			
            sprintf(name_message,"end\n");                          //게임 끝나면 end를 메시지에 저장
            write(clt->sock,name_message,strlen(name_message));    //게임 끝나면 end를 서버에 보냄
            for(int i=0;i<BUFFSIZE+BUFFSIZE;i++)
                name_message[i]='\0';
            clt->gameOn=0;
			/*
            for(int i=0;i<4;i++)
            {
                printf("%s [%d]",clt->I.play_name[i],clt->I.score[i]);
            }
			*/ //<!>
        }
    }


}

void game(void *P) // 메인 함수
{
    int map[ROW][COL] = {0};
    int cnt = 0;//바닥/////////////////////////////////////////////////////////////
    int h_cnt = 0;//장애물//////////////////////////////////////////////////////
    int b_cnt = 0;//배경 ///////////////////////////////////////////////////////
    int h_shape = 0;
	int item_random;	// 아이템 생성 확률 
    int random; // 캐릭터 랜덤 하게 만들기
	
    Clnt *p=(Clnt*)P;
    color col; // 불 색상

    init_map(map);
    p->x = 10;
    p->y = 50;
    p->hdl = 0;
    p->ch_stat = 0;
    p->jmp = 0;
    p->hp = 50;
    p->score=0;
    p->score_up=0;
    p->speed_up=40000;//usleep
    p->jmp_snd = 0; // 점프 임시값 저장
    col.r = 255; // 빨강
    col.g = 0; // 초록
    col.b = 0; // 파랑
    // 타이머
    struct timer *ti_s;
    ti_s=malloc(sizeof(struct timer));
    ti_s->mi=0;
    ti_s->s=0;
    ti_s->tot=0;

    pthread_t t_id;
    int state;
    void *thr_id;
	
	//intro();
	/*
	system("clear"); //<!>
    printf("\t\t\t\t\t\n\n\n\n\n\n\n\n\n");
    printf("\t\t\t1. 쥐 2. 나비 3. 개 4. 병아리 \n"); 
    printf("\t\t\t캐릭터를 선택해주세요. (번호 입력)\n");
    printf("\t\t\t> ");
    scanf("%d", &(p->ch_select));
	*/
	
    random = rand() % 100; 
    if(random >= 1 && random < 25)
    {
        p->ch_select = 1;
    }
    else if(random >= 26 && random < 50)
    {
        p->ch_select = 2;
    }
    else if(random >= 51 && random < 75)
    {
        p->ch_select = 3;
    }
    else if(random > 76 && random < 100)
    {
        p->ch_select = 4;
    }
    else
    {
        p->ch_select = 0;
    }

    if(p->ch_select==0) p->hp_max=80;
    else p->hp_max=50;
	
    ti_s->hp=p->hp;
    pthread_create(&t_id, NULL, t_func, (void*)ti_s);
    while(1)
    {
		//if(p->ch_select == 0) {p->x = -10; p->y = 50; p->hp = 5000;} (테스트)
        collp_char(p, map,ti_s);
        draw_char(p, map);
        bubble_sort(p);
        draw_map(p, map, ti_s, &col);
        hurdle(p, map, &cnt,&h_cnt,&b_cnt,&h_shape,&item_random);////////
		
        ti_s->hp=p->hp;
        ch_skill(ti_s,p);////////
        get_score(p,map);
        buff_recv(p,ti_s);
        item_random = rand()%2000;
        // 타이머 스레드
        if(p->hp <= 0)
        {
			p->hp=-100;
			p->d_time = ti_s->tot; // 죽은시간 <!>
			end_game(&col);
            break;
        }

    }

    pthread_join(t_id, (void**)&thr_id);
}

void init_map(int map[ROW][COL]) // 맵 초기화 
{
    int i, j;
    for(i=0; i<ROW; i++)
    {
        for(j=0; j<COL; j++)
        {
            if(i == 0)
            {
                map[i][0] = 1;
                map[i][j] = 2;
                map[i][COL-1] = 3;
            }
            else if(i == ROW-1)
            {
                map[i][0] = 4;
                map[i][j] = 2;
                map[i][COL-1] = 5;
            }
            else if(j == 0 || j == COL-1)
            {
                map[i][j] = 6;
            }	
            else if(i == ROW-5 && j != 1)
            {
                map[i][j] = 2;
            }
            else
            {
                map[i][j] = 0;
            }
        }
    }
}

void draw_map(Clnt *p, int map[ROW][COL], struct timer *ti_s, color *col) // 배열 실시간 출력
{
    int i, j;
    if(col->g <= 256 && col->g >= 0) // 불색상 변화
    {
        if(col->g >= 255)
        {
            col->g = 0;
        }
        else
        {
            col->g += 2;
        }
    }
	printf("\x1b[H\x1b[J");
    printf("\n");

   for (int i =0; i<4; i++){
			printf("%d 등 : [%s]  - %d\t",i+1,p->I.play_name[i],p->I.score[i]);
		}
	puts("");
    for(i=0; i<ROW; i++)
    {
        for(j=0; j<COL; j++)
        {
            if(p->ch_select==1&&map[i][j]>50&&map[i][j]<=90&&ti_s->tot%400==0)
            {
                map[i][j]=0;
            }
            else
            {
                if((j < COL -1 && i < ROW -1) && (j > 2 && i > 1 )) // 테두리 안에 있는 물체를 왼쪽으로 쉬프트
                {
                    map[i][j-1] = map[i][j];
                    map[i][1] = 0; // 물체 삭제
                    if(map[i][j] > 20&&map[i][j]<51)// 플레이어 밀리는 잔상 제거
                    {
                        map[i][p->y-3] = 0;
                    }
                }

                switch(map[i][j]) // map[i][j]에 있는 정수를 출력
                {
                    case 0: printf(" "); break;
                    case 1: printf(GREEN"┌"DEF); break;
                    case 2: printf(GREEN"─"DEF); break;
                    case 3: printf(GREEN"┐"DEF); break;
                    case 4: printf(GREEN"└"DEF); break;
                    case 5: printf(GREEN"┘"DEF); break;
                    case 6: printf(GREEN"│"DEF); break;
                    case 7: printf(GREEN"┴"DEF); break;
                    case 11: printf("_"); break;
                    case 12: printf("("); break;
                    case 13: printf(")"); break;
                    case 14: printf(" "); break;
                    case 15: printf("│"); break;
                    case 16: printf("/"); break;
                    case 20: printf("\\"); break;
                    case 21: printf("_"); break;
                    case 22: printf("("); break;
                    case 23: printf(")"); break;
                    case 24: printf("'"); break;
                    case 25: printf(";"); break;
                    case 26: printf("/"); break;
                    case 27: printf(","); break;
                    case 28: printf("`"); break;
                    case 29: printf("-"); break;
                    case 30: printf("\\"); break;
                    case 31: printf("┛"); break;
                    case 32: printf("┐"); break;
                    case 33: printf("│"); break;
                    case 34: printf("Q"); break;
                    case 35: printf("\""); break;			
                    case 36: printf(">"); break;
                    case 37: printf("└"); break;
                    case 38: printf("&"); break;
                    case 39: printf("┌"); break;	
                    case 40: printf("├"); break;
                    case 41: printf("^"); break;
                    case 42: printf("."); break;
                    case 43: printf("┠"); break;
                    case 44: printf("┯"); break;
                    case 45: printf("╋"); break;
                    case 46: printf("o"); break;
                    case 47: printf("┗"); break;
                    case 48: printf("~"); break;
                    case 49: printf("^"); break;
                    case 50: printf(" "); break;			
                             //////////////////////////////////21번의 반복.(이동 해야하는 장애물)
                    case 51: printf("_"); break;
                    case 52: printf("("); break;
                    case 53: printf(")"); break;
                    case 54: printf("'"); break;
                    case 55: printf(";"); break;
                    case 56:  printf("/"); break;
                    case 57: printf(","); break;
                    case 58: printf("`"); break;
                    case 59: printf("-"); break;
                    case 60:  printf("\\"); break;
                    case 61: printf("┛"); break;
                    case 62: printf("┐"); break;
                    case 63: printf("│"); break; 
                    case 65: printf("\""); break;			
                    case 66: printf(">"); break;
                    case 67: printf("└"); break;
                    case 68: printf("&"); break;
                    case 69: printf("┌"); break;	
                    case 70: printf("├"); break;
                    case 71: printf("^"); break;
                    case 72: printf("."); break;
                    case 73: printf("┠"); break;
                    case 74: printf("┯"); break;
                    case 75: printf("╋"); break;
                    case 76: printf("o"); break;
                    case 77: printf("┗"); break;
                    case 78: printf("~"); break;
                    case 79: printf("^"); break;
                    case 80: printf(" "); break;
                             // 빛나는 불 //
                    case 81: COLOR printf("_"DEF); break;
                    case 82: COLOR printf("("DEF); break;
                    case 83: COLOR printf(")"DEF); break;
                    case 84: COLOR printf("/"DEF); break;
                    case 85: COLOR printf("\\"DEF); break;
                    case 86: COLOR printf("│"DEF); break;
                             // 아이템 관련 //
					case 91: printf(RED"♥"DEF); break;		// hp
					case 92: printf(YELLOW"☀"DEF); break;	// 무적
					case 93: printf(BLUE"◀"DEF); break;	// slow
					case 94: printf(GREEN"$"DEF); break;	// 점수 보너스
					case 95: printf("■"); break;			// 구덩이 확률
					case 96: printf(RED"▶"DEF); break;		// fast							
                }
            }
        }
        printf("\n");
    }
     printf("\t체력: [%d]\t| \t점수 [%d] \t| \t속도 ", p->hp, p->score);
	if(p->speed_up <= 50000 && p->speed_up >= 40000 ) printf(BLUE"[느림]"DEF);
	else if( p->speed_up <= 39999 && p->speed_up >= 30000 ) printf(GREEN"[보통]"DEF);
	else if( p->speed_up <= 29999 && p->speed_up >= 20000 ) printf(RED"[빠름]"DEF);
	printf("\t| \t점프 [%d]\n\n", p->jmp);   
    printf("\t\t시간 [%d 분][%.1lf 초] \t\t\t\t거리 [%d] cm\n\n", ti_s->mi, ti_s->s, p->distanse);
	printf("\t효과 :\t"); // 
    if(p->score_up!=0)  {printf(GREEN"$"DEF);printf(" %d초|",(p->score_up-ti_s->tot)/10);}
	if(p->invincible!=0){printf(YELLOW"☀"DEF);printf(" %d초|",(p->invincible-ti_s->tot)/10);} 
	printf("%s 님이 공격하셨습니다.", p->atk);
	printf("\n\n");
	switch(p->ch_select)
	{
		case 0:
		printf("\t무민 : [skill] 30초마다 체력 30획득                [skill2] 30초 마다 전진\n");
		break;
		case 1:
		printf("\t쥐 : [skill] 30초마다 3초간 무적                  [skill2] 40초마다 불구름, 맹수 제거\n");
		break;
		case 2:
		printf("\t나비 : [skill] 2단점프 가능                      [skill2] 30초 마다 랜덤 아이템 획득\n");
		break;
		case 3:
		printf("\t강아지 : [skill] 30초 마다 전진                   [skill2] 30초마다 5초간 점수 2배\n");
		break;
		case 4:
		printf("\t병아리 : [skill] 2단 점프 가능 장애물 피격시           [skill2] 25%%확률로 체력 감소 무효\n");
		break;
	}
	printf("\n\n\n");
	printf("체력회복:"RED"♥\t"DEF"무적:"YELLOW"☀\t    "DEF"속도감소:"BLUE"◀\t    "DEF"점수 2배:"GREEN"$\t    "DEF"장애물 증가:""■\t   ""속도증가:"RED"▶\t    "DEF);
    printf("\n");
    usleep(p->speed_up); //4만: 보통, 6만: 느려짐, 2만: 빨라짐

}

void draw_char(Clnt *p, int map[ROW][COL]) // 플레이어 화면에 출력
{
    int key; // 키 입력

    if( !((p->x == ROW-1) || (p->y < 2)) )
    {

        if(map[p->x][p->y+3] == 6) // 장애물에 닿으면 밀린다.
        {
            if(!(p->y == 1)) // 1이 아닐때까지 밀린다.
            {
                p->y--;
            }
        }

		if( (map[p->x+1][p->y+4] == 1) || (map[p->x+1][p->y+4] == 2) || (map[p->x+1][p->y+4] == 3) ||
				(map[p->x+1][p->y-1] == 1) || (map[p->x+1][p->y-1] == 2) || (map[p->x+1][p->y-1] == 3) || // 
                (map[p->x+1][p->y-2] == 1) || (map[p->x+1][p->y-2] == 2) || (map[p->x+1][p->y-2] == 3) ||
                (map[p->x+1][p->y+2] == 1) || (map[p->x+1][p->y+2] == 2) || (map[p->x+1][p->y+2] == 3) || 
				(map[p->x+1][p->y+3] == 1) || (map[p->x+1][p->y+3] == 2) || (map[p->x+1][p->y+3] == 3) ||
				(map[p->x+1][p->y+1] == 1) || (map[p->x+1][p->y+1] == 2) || (map[p->x+1][p->y+1] == 3) ) // 바닥이 있을 경우 떨어지지 않는다.(캐릭터의 끝과 끝점) 
        {
            if(p->ch_movcnt < 5) // 착지할때 모션
            {
                p->ch_stat = 1;
            }
            else if (p->ch_movcnt < 2)
            {
                p->ch_stat = 2;
            }

            if(p->ch_movcnt % 10 == 5) // 걷기[1], 걷기[2] 출력
            {
                p->ch_stat = 1;
            }
            else if(p->ch_movcnt % 10 == 0)
            {
                p->ch_stat = 2;
            }

            if(p->ch_select==2||p->ch_select==4)/////////////////
            {
                p->jmp = 2; // 2단 점프 캐릭터 
            }
            else
            {
                p->jmp = 1; // 1단 점프 캐릭터
            }
        }
        else // 바닥이 없을 경우 떨어짐.
        {
            p->ch_stat = 3; // 점프 모션
            p->ch_movcnt = 0;
            if(p->ch_stat == 3)
            {
                map[p->x-3][p->y] = 0;
                map[p->x-3][p->y-1] = 0;
                map[p->x-3][p->y+1] = 0;
                map[p->x-3][p->y+2] = 0;
                p->x++; // 떨어짐
            }	
        }

        if(p->jmp_cnt != 0) // 점프카운트가 0이 아닐때까지 점프 못함
        {
            jmp_char(p, map);
        }

        if(kbhit() != 0) // 키를 누르면 점프 카운트 증가
        {
            key = getch();
            if(key == 65 && p->jmp > 0)
            {
               if(p->ch_select == 1 || p->ch_select == 3 || p->ch_select == 0  )  p->jmp_cnt = 15; // jmp_cnt * 2의 높이 
               else p->jmp_cnt = 19; // 나비, 병아리 점프력 
			   p->jmp--;// 점프 가능횟수 -1
			   p->jmp_snd = p->jmp; // 점프 가능횟수 버그가 있어서 추가
			   printf("\a");
			}
        }
    }
    mov_char(p, map);
}

void hurdle(Clnt *p, int map[ROW][COL], int *cnt,int *h_cnt, int *b_cnt, int *h_shape, int * item_random) // 장애물
{ 
 if(*b_cnt==0) *b_cnt=15;
    if(*b_cnt>0)
    {
        switch(*b_cnt) // 배경(불) 
        {
            case 15: break;
            case 14: break;
            case 13:
                map[5][COL-3]=82;
                map[4][COL-3]=80;
                map[3][COL-3]=80;
                map[2][COL-3]=80;
                map[1][COL-3]=80;

                break;
            case 12:
                map[5][COL-3]=82;
                map[4][COL-3]=83;
                map[3][COL-3]=82;
                map[2][COL-3]=80;
                map[1][COL-3]=80;
                break;
            case 11:
                map[5][COL-3]=81;
                map[4][COL-3]=82;
                map[3][COL-3]=80;
                map[2][COL-3]=80;
                map[1][COL-3]=80;
                break;
            case 10:
                map[5][COL-3]=83;
                map[4][COL-3]=81;
                map[3][COL-3]=84;
                map[2][COL-3]=83;
                map[1][COL-3]=80;

                break;
            case 9:
                map[5][COL-3]=81;
                map[4][COL-3]=83;
                map[3][COL-3]=82;
                map[2][COL-3]=80;
                map[1][COL-3]=80;
                break;
            case 8:
                map[5][COL-3]=80;
                map[4][COL-3]=83;
                map[3][COL-3]=80;
                map[2][COL-3]=80;
                map[1][COL-3]=80;
                break;
            case 7:
                map[5][COL-3]=86;
                map[4][COL-3]=82;
                map[3][COL-3]=80;
                map[2][COL-3]=82;
                map[1][COL-3]=80;
                break;
            case 6:
                map[5][COL-3]=80;
                map[4][COL-3]=82;
                map[3][COL-3]=83;
                map[2][COL-3]=80;
                map[1][COL-3]=80;
                break;
            case 5:
                map[5][COL-3]=86;
                map[4][COL-3]=81;
                map[3][COL-3]=85;
                map[2][COL-3]=84;
                map[1][COL-3]=80;
                break;
            case 4:
                map[5][COL-3]=82;
                map[4][COL-3]=83;
                map[3][COL-3]=82;
                map[2][COL-3]=82;
                map[1][COL-3]=83;
                break;
            case 3:
                map[5][COL-3]=81;
                map[4][COL-3]=85;
                map[3][COL-3]=83;
                map[2][COL-3]=80;
                map[1][COL-3]=80;
                break;
            case 2:
                map[5][COL-3]=83;
                map[4][COL-3]=80;
                map[3][COL-3]=83;
                map[2][COL-3]=80;
                map[1][COL-3]=80;
                break;
            case 1: break;

        }
        --*b_cnt;
    }

    if(rand()%50==0&&*cnt==0&&*h_cnt==0)
    {
        *cnt=12;//함정칸수(10)+모서리
    }
    if(*cnt>0)
    {
        switch(*cnt)
        {
            case 12://구멍시작
                map[ROW-5][COL-3] = 3;
                map[ROW-4][COL-3] = 6;
                map[ROW-3][COL-3] = 6;
                map[ROW-2][COL-3] = 6;
                map[ROW-1][COL-3] = 7;
                break;
            case 1://구멍끝
                map[ROW-5][COL-3] = 1;
                map[ROW-4][COL-3] = 6;
                map[ROW-3][COL-3] = 6;
                map[ROW-2][COL-3] = 6;
                map[ROW-1][COL-3] = 7;				
                break;
            default://구멍
                map[ROW-5][COL-3] = 0;
                map[ROW-4][COL-3] = 0;
                map[ROW-3][COL-3] = 0;
                map[ROW-2][COL-3] = 0;
                map[ROW-1][COL-3] = 2;
                break;

        }
        --(*cnt);
    }
    else //그냥땅
    {
        map[ROW-5][COL-3] = 2;
        map[ROW-4][COL-3] = 0;
        map[ROW-3][COL-3] = 0;
        map[ROW-2][COL-3] = 0;
        map[ROW-1][COL-3] = 2;
    }
    if(rand()%100==0&&*cnt==0&&*h_cnt==0)///////동물 장애물
    {
		if(p->h_index!=0)*h_cnt=15;
        else *h_cnt=30;
        *h_shape=rand()%3;
    }
    switch(*h_shape)
    {
        case 0:
            if(*h_cnt>0)
            {
                switch(*h_cnt)
                {
                    case 14: break;
                    case 13:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=80;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=77;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 12:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=80;
                        map[ROW-8][COL-3]=63;
                        map[ROW-9][COL-3]=63;
                        map[ROW-10][COL-3]=72;
                        break;
                    case 11:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=80;
                        map[ROW-8][COL-3]=51;
                        map[ROW-9][COL-3]=72;
                        map[ROW-10][COL-3]=60;
                        break;
                    case 10:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=80;
                        map[ROW-8][COL-3]=56;
                        map[ROW-9][COL-3]=80;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 9:
                        map[ROW-6][COL-3]=63;
                        map[ROW-7][COL-3]=60;
                        map[ROW-8][COL-3]=52;
                        map[ROW-9][COL-3]=66;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 8:
                        map[ROW-6][COL-3]=63;
                        map[ROW-7][COL-3]=51;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=59;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 7:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=51;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=59;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 6:
                        map[ROW-6][COL-3]=63;
                        map[ROW-7][COL-3]=57;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=59;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 5:
                        map[ROW-6][COL-3]=63;
                        map[ROW-7][COL-3]=53;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=59;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 4:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=54;
                        map[ROW-8][COL-3]=53;
                        map[ROW-9][COL-3]=60;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 3:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=80;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=51;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 2:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=80;
                        map[ROW-8][COL-3]=53;
                        map[ROW-9][COL-3]=80;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 1: break;
                    default: break;
                }

                --(*h_cnt);
            }
            break;
        case 1:
            if(*h_cnt>0)
            {
                switch(*h_cnt)
                {
                    case 14: break;
                    case 13:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=80;
                        map[ROW-8][COL-3]=52;
                        map[ROW-9][COL-3]=63;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 12:
                        map[ROW-6][COL-3]=54;
                        map[ROW-7][COL-3]=60;
                        map[ROW-8][COL-3]=72;
                        map[ROW-9][COL-3]=60;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 11:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=56;
                        map[ROW-8][COL-3]=72;
                        map[ROW-9][COL-3]=56;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 10:
                        map[ROW-6][COL-3]=51;
                        map[ROW-7][COL-3]=60;
                        map[ROW-8][COL-3]=53;
                        map[ROW-9][COL-3]=63;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 9:
                        map[ROW-6][COL-3]=56;
                        map[ROW-7][COL-3]=51;
                        map[ROW-8][COL-3]=78;
                        map[ROW-9][COL-3]=51;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 8:
                        map[ROW-6][COL-3]=56;
                        map[ROW-7][COL-3]=51;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=51;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 7:
                        map[ROW-6][COL-3]=51;
                        map[ROW-7][COL-3]=63;
                        map[ROW-8][COL-3]=60;
                        map[ROW-9][COL-3]=80;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 6:
                        map[ROW-6][COL-3]=56;
                        map[ROW-7][COL-3]=80;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=80;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 5:
                        map[ROW-6][COL-3]=56;
                        map[ROW-7][COL-3]=60;
                        map[ROW-8][COL-3]=63;
                        map[ROW-9][COL-3]=80;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 4:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=63;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=80;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 3: break;
                    case 2: break;
                    case 1: break;
                    default: break;
                }

                --(*h_cnt);
            }
            break;
        case 2:
            if(*h_cnt>0)
            {
                switch(*h_cnt)
                {
                    case 14:
                        break;
                    case 13:
                        map[ROW-6][COL-3]=52;
                        map[ROW-7][COL-3]=80;
                        map[ROW-8][COL-3]=60;
                        map[ROW-9][COL-3]=56;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 12:
                        map[ROW-6][COL-3]=51;
                        map[ROW-7][COL-3]=63;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=72;
                        map[ROW-10][COL-3]=72;
                        break;
                    case 11:
                        map[ROW-6][COL-3]=51;
                        map[ROW-7][COL-3]=63;
                        map[ROW-8][COL-3]=56;
                        map[ROW-9][COL-3]=72;
                        map[ROW-10][COL-3]=72;
                        break;
                    case 10:
                        map[ROW-6][COL-3]=54;
                        map[ROW-7][COL-3]=63;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=60;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 9:
                        map[ROW-6][COL-3]=80;
                        map[ROW-7][COL-3]=51;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=51;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 8:
                        map[ROW-6][COL-3]=52;
                        map[ROW-7][COL-3]=51;
                        map[ROW-8][COL-3]=80;
                        map[ROW-9][COL-3]=51;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 7:
                        map[ROW-6][COL-3]=51;
                        map[ROW-7][COL-3]=63;
                        map[ROW-8][COL-3]=60;
                        map[ROW-9][COL-3]=80;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 6:
                        map[ROW-6][COL-3]=63;
                        map[ROW-7][COL-3]=63;
                        map[ROW-8][COL-3]=76;
                        map[ROW-9][COL-3]=80;
                        map[ROW-10][COL-3]=80;
                        break;
                    case 5: break;
                    case 4: break;
                    case 3: break;
                    case 2: break;
                    case 1: break;
                    default: break; 
                }
                --(*h_cnt);
            }
            break;
    }
	// 아이템 확률 // 
	if(*item_random >= 100 && *item_random <= 101) map[ROW-12][COL-3] = 91;			// hp
	else if(*item_random >= 250 && *item_random <= 251) map[ROW-12][COL-3] = 92;	// 무적
	else if(*item_random >= 400 && *item_random <= 401) map[ROW-12][COL-3] = 93;	// slow
	else if(*item_random >= 550 && *item_random <= 551) map[ROW-12][COL-3] = 94;	// 보너스 
	else if(*item_random >= 700 && *item_random <= 701) map[ROW-12][COL-3] = 95;	// 멀티, 구덩이증가
	else if(*item_random >= 850 && *item_random <= 851) map[ROW-12][COL-3] = 96;	// 멀티, 속도증가
 
}

void clear_char(Clnt *p, int map[ROW][COL]) // 점프시 캐릭터 잔상 제거
{
    map[p->x+2][p->y] = 0;
    map[p->x+2][p->y-1] = 0;
    map[p->x+2][p->y-2] = 0;
    map[p->x+2][p->y+1] = 0;
    map[p->x+2][p->y+2] = 0;
    map[p->x+2][p->y+3] = 0;

    map[p->x+1][p->y] = 0;
    map[p->x+1][p->y-1] = 0;
    map[p->x+1][p->y-2] = 0;
    map[p->x+1][p->y+1] = 0;
    map[p->x+1][p->y+2] = 0;
    map[p->x+1][p->y+3] = 0;

    map[p->x][p->y] = 0;
    map[p->x][p->y-1] = 0;
    map[p->x][p->y-2] = 0;
    map[p->x][p->y+1] = 0;
    map[p->x][p->y+2] = 0;
    map[p->x][p->y+3] = 0;

    map[p->x-1][p->y] = 0;
    map[p->x-1][p->y-1] = 0;
    map[p->x-1][p->y-2] = 0;
    map[p->x-1][p->y+1] = 0;
    map[p->x-1][p->y+2] = 0;
    map[p->x-1][p->y+3] = 0;

    map[p->x-2][p->y] = 0;
    map[p->x-2][p->y-1] = 0;
    map[p->x-2][p->y-2] = 0;
    map[p->x-2][p->y+1] = 0;
    map[p->x-2][p->y+2] = 0;
    map[p->x-2][p->y+3] = 0;
}

void jmp_char(Clnt *p, int map[ROW][COL]) // 점프하는 함수
{
    int key;

    if(p->x>5)
    {
        p->jmp = p->jmp_snd;// jmp카운트 버그 대체용 
        if(p->jmp_cnt==1||p->jmp_cnt==2||p->jmp_cnt==3||p->jmp_cnt==4||p->jmp_cnt==5||p->jmp_cnt==6)
        {
            p->x += -1;
        }
        else
        {
            p->x += -2;
        }

        usleep(200);
        clear_char(p, map);
        p->jmp_cnt--;
    }
}		

void mov_char(Clnt *p, int map[ROW][COL]) // 캐릭터 모션
{
    p->ch_movcnt++; // 걷기[1], 걷기[2] 스위칭 

    switch(p->ch_select)
    {
        case 0:
            if(p->ch_stat == 1)
            {
                //무민1
                map[p->x][p->y-2] 	= 50; map[p->x-1][p->y-2] = 50;
                map[p->x][p->y-1] 	= 37; map[p->x-1][p->y-1] = 33;
                map[p->x][p->y]   	= 37; map[p->x-1][p->y]   = 26;
                map[p->x][p->y+1] 	= 50; map[p->x-1][p->y+1] = 50;
                map[p->x][p->y+2] 	= 50; map[p->x-1][p->y+2] = 23;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 50; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 33; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 50; map[p->x-3][p->y]   = 41;
                map[p->x-2][p->y+1] = 35; map[p->x-3][p->y+1] = 41;
                map[p->x-2][p->y+2] = 21; map[p->x-3][p->y+2] = 21;
                map[p->x-2][p->y+3] = 23; map[p->x-3][p->y+3] = 50;  
            }
            else if(p->ch_stat == 2)
            {
                //무민2
                map[p->x][p->y-2] 	= 50; map[p->x-1][p->y-2] = 50;
                map[p->x][p->y-1] 	= 37; map[p->x-1][p->y-1] = 33;
                map[p->x][p->y]   	= 50; map[p->x-1][p->y]   = 50;
                map[p->x][p->y+1] 	= 37; map[p->x-1][p->y+1] = 30;
                map[p->x][p->y+2] 	= 50; map[p->x-1][p->y+2] = 23;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 50; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 33; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 50; map[p->x-3][p->y]   = 41;
                map[p->x-2][p->y+1] = 35; map[p->x-3][p->y+1] = 41;
                map[p->x-2][p->y+2] = 21; map[p->x-3][p->y+2] = 21;
                map[p->x-2][p->y+3] = 23; map[p->x-3][p->y+3] = 50;
            }
            else if(p->ch_stat == 3)
            {
                //무민3
                map[p->x][p->y-2] 	= 50; map[p->x-1][p->y-2] = 50;
                map[p->x][p->y-1] 	= 37; map[p->x-1][p->y-1] = 33;
                map[p->x][p->y]   	= 50; map[p->x-1][p->y]   = 50;
                map[p->x][p->y+1] 	= 37; map[p->x-1][p->y+1] = 30;
                map[p->x][p->y+2] 	= 50; map[p->x-1][p->y+2] = 23;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 50; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 33; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 50; map[p->x-3][p->y]   = 41;
                map[p->x-2][p->y+1] = 35; map[p->x-3][p->y+1] = 41;
                map[p->x-2][p->y+2] = 21; map[p->x-3][p->y+2] = 21;
                map[p->x-2][p->y+3] = 23; map[p->x-3][p->y+3] = 50;
            }
            break;

        case 1:
            if(p->ch_stat == 1)
            {
                //쥐1
                map[p->x][p->y-2] 	= 22; map[p->x-1][p->y-2] = 33;
                map[p->x][p->y-1] 	= 21; map[p->x-1][p->y-1] = 21;
                map[p->x][p->y]   	= 23; map[p->x-1][p->y]   = 21;
                map[p->x][p->y+1] 	= 35; map[p->x-1][p->y+1] = 34;
                map[p->x][p->y+2] 	= 36; map[p->x-1][p->y+2] = 34;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 50; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 50; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 50; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 50; map[p->x-3][p->y+1] = 50;
                map[p->x-2][p->y+2] = 50; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 50; map[p->x-3][p->y+3] = 50;
            }
            else if(p->ch_stat == 2)
            {
                //쥐2
                map[p->x][p->y-2] 	= 22; map[p->x-1][p->y-2] = 33;
                map[p->x][p->y-1] 	= 21; map[p->x-1][p->y-1] = 21;
                map[p->x][p->y]   	= 23; map[p->x-1][p->y]   = 21;
                map[p->x][p->y+1] 	= 35; map[p->x-1][p->y+1] = 34;
                map[p->x][p->y+2] 	= 36; map[p->x-1][p->y+2] = 34;

                map[p->x-2][p->y-2] = 50; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 50; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 50; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 50; map[p->x-3][p->y+1] = 50;
                map[p->x-2][p->y+2] = 50; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 50; map[p->x-3][p->y+3] = 50;           
            }
            else if(p->ch_stat == 3)
            {
                //쥐3
                map[p->x][p->y-2] 	= 26; map[p->x-1][p->y-2] = 22;
                map[p->x][p->y-1] 	= 26; map[p->x-1][p->y-1] = 21;
                map[p->x][p->y]   	= 50; map[p->x-1][p->y]   = 23;
                map[p->x][p->y+1] 	= 24; map[p->x-1][p->y+1] = 35;
                map[p->x][p->y+2] 	= 24; map[p->x-1][p->y+2] = 36;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 33; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 21; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 21; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 34; map[p->x-3][p->y+1] = 50;
                map[p->x-2][p->y+2] = 34; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 50; map[p->x-3][p->y+3] = 50;
            }
            break;

        case 2:
            if(p->ch_stat == 1)
            {
                //나비1
                map[p->x][p->y-2] 	= 50; map[p->x-1][p->y-2] = 50;
                map[p->x][p->y-1] 	= 43; map[p->x-1][p->y-1] = 30;
                map[p->x][p->y]   	= 44; map[p->x-1][p->y]   = 33;
                map[p->x][p->y+1] 	= 45; map[p->x-1][p->y+1] = 21;
                map[p->x][p->y+2] 	= 46; map[p->x-1][p->y+2] = 26;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 30; map[p->x-3][p->y-2] = 42;
                map[p->x-2][p->y-1] = 50; map[p->x-3][p->y-1] = 29;
                map[p->x-2][p->y] 	= 33; map[p->x-3][p->y]   = 42;
                map[p->x-2][p->y+1] = 42; map[p->x-3][p->y+1] = 50;
                map[p->x-2][p->y+2] = 29; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 42; map[p->x-3][p->y+3] = 50;     
            }
            else if(p->ch_stat == 2)
            {
                //나비2
                map[p->x][p->y-2] 	= 50; map[p->x-1][p->y-2] = 50;
                map[p->x][p->y-1] 	= 43; map[p->x-1][p->y-1] = 30;
                map[p->x][p->y]   	= 44; map[p->x-1][p->y]   = 50;
                map[p->x][p->y+1] 	= 45; map[p->x-1][p->y+1] = 21;
                map[p->x][p->y+2] 	= 46; map[p->x-1][p->y+2] = 26;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 30; map[p->x-3][p->y-2] = 42;
                map[p->x-2][p->y-1] = 50; map[p->x-3][p->y-1] = 29;
                map[p->x-2][p->y] 	= 50; map[p->x-3][p->y]   = 42;
                map[p->x-2][p->y+1] = 50; map[p->x-3][p->y+1] = 21;
                map[p->x-2][p->y+2] = 33; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 42; map[p->x-3][p->y+3] = 50;
            }
            else if(p->ch_stat == 3)
            {
                //나비3
                map[p->x][p->y-2] 	= 50; map[p->x-1][p->y-2] = 50;
                map[p->x][p->y-1] 	= 43; map[p->x-1][p->y-1] = 30;
                map[p->x][p->y]   	= 44; map[p->x-1][p->y]   = 33;
                map[p->x][p->y+1] 	= 45; map[p->x-1][p->y+1] = 21;
                map[p->x][p->y+2] 	= 46; map[p->x-1][p->y+2] = 26;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 30; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 50; map[p->x-3][p->y-1] = 21;
                map[p->x-2][p->y] 	= 33; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 42; map[p->x-3][p->y+1] = 50;
                map[p->x-2][p->y+2] = 29; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 42; map[p->x-3][p->y+3] = 50;
            }
            break;

        case 3:
            if(p->ch_stat == 1)
            {
                //개1
                map[p->x][p->y-2] 	= 30; map[p->x-1][p->y-2] = 26;
                map[p->x][p->y-1] 	= 30; map[p->x-1][p->y-1] = 27;
                map[p->x][p->y]   	= 29; map[p->x-1][p->y]   = 50;
                map[p->x][p->y+1] 	= 30; map[p->x-1][p->y+1] = 50;
                map[p->x][p->y+2] 	= 30; map[p->x-1][p->y+2] = 26;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 28;

                map[p->x-2][p->y-2] = 22; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 21; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 22; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 23; map[p->x-3][p->y+1] = 21;
                map[p->x-2][p->y+2] = 24; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 25; map[p->x-3][p->y+3] = 50;            
            }
            else if(p->ch_stat == 2)
            {
                //개2
                map[p->x][p->y-2] 	= 26; map[p->x-1][p->y-2] = 33;
                map[p->x][p->y-1] 	= 26; map[p->x-1][p->y-1] = 27;
                map[p->x][p->y]   	= 29; map[p->x-1][p->y]   = 50;
                map[p->x][p->y+1] 	= 30; map[p->x-1][p->y+1] = 50;
                map[p->x][p->y+2] 	= 30; map[p->x-1][p->y+2] = 26;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 28;

                map[p->x-2][p->y-2] = 22; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 21; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 22; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 23; map[p->x-3][p->y+1] = 21;
                map[p->x-2][p->y+2] = 24; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 25; map[p->x-3][p->y+3] = 50;           
            }
            else if(p->ch_stat == 3)
            {
                //개3
                map[p->x][p->y-2] 	= 26; map[p->x-1][p->y-2] = 33;
                map[p->x][p->y-1] 	= 31; map[p->x-1][p->y-1] = 27;
                map[p->x][p->y]   	= 29; map[p->x-1][p->y]   = 50;
                map[p->x][p->y+1] 	= 30; map[p->x-1][p->y+1] = 50;
                map[p->x][p->y+2] 	= 32; map[p->x-1][p->y+2] = 26;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 28;

                map[p->x-2][p->y-2] = 22; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 21; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 22; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 23; map[p->x-3][p->y+1] = 21;
                map[p->x-2][p->y+2] = 24; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 25; map[p->x-3][p->y+3] = 50;
            }
            break;

        case 4:
            if(p->ch_stat == 1)
            {
                //병아리1
                map[p->x][p->y-2] 	= 50; map[p->x-1][p->y-2] = 22;
                map[p->x][p->y-1] 	= 37; map[p->x-1][p->y-1] = 21;
                map[p->x][p->y]   	= 37; map[p->x-1][p->y]   = 26;
                map[p->x][p->y+1] 	= 50; map[p->x-1][p->y+1] = 21;
                map[p->x][p->y+2] 	= 50; map[p->x-1][p->y+2] = 23;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 50; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 21; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 22; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 24; map[p->x-3][p->y+1] = 21;
                map[p->x-2][p->y+2] = 23; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 36; map[p->x-3][p->y+3] = 50;     
            }
            else if(p->ch_stat == 2)
            {
                //병아리2
                map[p->x][p->y-2] 	= 50; map[p->x-1][p->y-2] = 22;
                map[p->x][p->y-1] 	= 37; map[p->x-1][p->y-1] = 21;
                map[p->x][p->y]   	= 50; map[p->x-1][p->y]   = 26;
                map[p->x][p->y+1] 	= 37; map[p->x-1][p->y+1] = 21;
                map[p->x][p->y+2] 	= 50; map[p->x-1][p->y+2] = 23;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 50; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 21; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 22; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 24; map[p->x-3][p->y+1] = 21;
                map[p->x-2][p->y+2] = 23; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 36; map[p->x-3][p->y+3] = 50;
            }
            else if(p->ch_stat == 3)
            {
                //병아리3
                map[p->x][p->y-2] 	= 50; map[p->x-1][p->y-2] = 26;
                map[p->x][p->y-1] 	= 37; map[p->x-1][p->y-1] = 21;
                map[p->x][p->y]   	= 37; map[p->x-1][p->y]   = 26;
                map[p->x][p->y+1] 	= 50; map[p->x-1][p->y+1] = 21;
                map[p->x][p->y+2] 	= 50; map[p->x-1][p->y+2] = 23;
                map[p->x][p->y+3] 	= 50; map[p->x-1][p->y+3] = 50;

                map[p->x-2][p->y-2] = 50; map[p->x-3][p->y-2] = 50;
                map[p->x-2][p->y-1] = 21; map[p->x-3][p->y-1] = 50;
                map[p->x-2][p->y] 	= 22; map[p->x-3][p->y]   = 50;
                map[p->x-2][p->y+1] = 24; map[p->x-3][p->y+1] = 21;
                map[p->x-2][p->y+2] = 23; map[p->x-3][p->y+2] = 50;
                map[p->x-2][p->y+3] = 36; map[p->x-3][p->y+3] = 50;
            }
            break;		
    }
}	

void collp_char(Clnt*p, int map[ROW][COL],struct timer *ti_s) // 캐릭터와 물체 상호작용
{
	
    if(p->y-4 == map[p->x][1] || p->y-3 == map[p->x][1]) // 화면 끝까지 밀려나면 사망 
    {
        p->hp = 0;
    }
    if(p->invincible == 0)
    {
        if((map[p->x][p->y+4] >= 20 &&map[p->x][p->y+4]<=90)||(map[p->x-1][p->y+4] >= 20 &&map[p->x-1][p->y+4]<=90)||(map[p->x-2][p->y+4] >= 20 &&map[p->x-2][p->y+4]<=90)||(map[p->x-3][p->y+4] >= 20 &&map[p->x-3][p->y+4]<=90)|| // 캐릭터 전방
		(map[p->x-4][p->y+3] >= 20 &&map[p->x-4][p->y+3]<=90)||(map[p->x-4][p->y+2] >= 20 &&map[p->x-4][p->y+2]<=90)||(map[p->x-4][p->y+1] >= 20 &&map[p->x-4][p->y+1]<=90)||(map[p->x-4][p->y-1] >= 20 &&map[p->x-4][p->y-1]<=90)|| // 캐릭터 상단
		(map[p->x+1][p->y+3] >= 20 &&map[p->x+1][p->y+3]<=90)||(map[p->x+1][p->y+2] >= 20 &&map[p->x+1][p->y+2]<=90)||(map[p->x+1][p->y+1] >= 20 &&map[p->x+1][p->y+1]<=90)||(map[p->x+1][p->y-1] >= 20 &&map[p->x+1][p->y-1]<=90)) // 캐릭터 하단 
        { // 장애물과 충돌시 체력 소모 
            if(p->ch_select==4&&rand()%3==0);
            else p->hp--;
        }
    }
	if(			map[p->x][p->y+4] == 91 || map[p->x-1][p->y+4] == 91 || map[p->x-2][p->y+4] == 91 || map[p->x-3][p->y+4] == 91 || map[p->x-4][p->y+4] == 91 || map[p->x+1][p->y+4] == 91 ||// 캐릭터 전방
                map[p->x-4][p->y+3] == 91 || map[p->x-4][p->y+2] == 91 || map[p->x-4][p->y+1] ==91 || map[p->x-4][p->y-1] == 91 || map[p->x-4][p->y+4] == 91 || map[p->x-4][p->y-2] == 91 || map[p->x-4][p->y-3] == 91 ||// 캐릭터 상단
                map[p->x+1][p->y+3] == 91 || map[p->x+1][p->y+2] == 91 || map[p->x+1][p->y+1] == 91 || map[p->x+1][p->y-1] == 91 || map[p->x+1][p->y+4] == 91 || map[p->x+1][p->y-2] == 91 || map[p->x+1][p->y-3] == 91 
				) // 캐릭터 하단 
	{
		// 라이프, 임시
		
		if(map[p->x-4][p->y+4] == 91)
		map[p->x-4][p->y+4] = 0;
	
		if(p->hp+30>=p->hp_max)p->hp=p->hp_max;
		else p->hp += 30;
		
	}
	
	if(map[p->x][p->y+4] == 92 || map[p->x-1][p->y+4] == 92 || map[p->x-2][p->y+4] == 92 || map[p->x-3][p->y+4] == 92 || map[p->x-4][p->y+4] == 92 || map[p->x+1][p->y+4] == 92 ||// 캐릭터 전방
                map[p->x-4][p->y+3] == 92 || map[p->x-4][p->y+2] == 92 || map[p->x-4][p->y+1] ==92 || map[p->x-4][p->y-1] == 92 || map[p->x-4][p->y+4] == 92 || map[p->x-4][p->y-2] == 92 || map[p->x-4][p->y-3] == 92 ||// 캐릭터 상단
                map[p->x+1][p->y+3] == 92 || map[p->x+1][p->y+2] == 92 || map[p->x+1][p->y+1] == 92 || map[p->x+1][p->y-1] == 92 || map[p->x+1][p->y+4] == 92 || map[p->x+1][p->y-2] == 92 || map[p->x+1][p->y-3] == 92) // 캐릭터 하단   
	{
		// 무적
		
		if(map[p->x-4][p->y+4] == 92)
		map[p->x-4][p->y+4] = 0;
	
		p->invincible = ti_s->tot+100;	
		// 2. 있는 시간에서 +a 80(8초)까지 무적을 부여한다.
	}
	
	if(map[p->x][p->y+4] == 93 || map[p->x-1][p->y+4] == 93 || map[p->x-2][p->y+4] == 93 || map[p->x-3][p->y+4] == 93 || map[p->x-4][p->y+4] == 93 || map[p->x+1][p->y+4] == 93 ||// 캐릭터 전방
                map[p->x-4][p->y+3] == 93 || map[p->x-4][p->y+2] == 93 || map[p->x-4][p->y+1] ==93 || map[p->x-4][p->y-1] == 93 || map[p->x-4][p->y+4] == 93 || map[p->x-4][p->y-2] == 93 || map[p->x-4][p->y-3] == 93 ||// 캐릭터 상단
                map[p->x+1][p->y+3] == 93 || map[p->x+1][p->y+2] == 93 || map[p->x+1][p->y+1] == 93 || map[p->x+1][p->y-1] == 93 || map[p->x+1][p->y+4] == 93 || map[p->x+1][p->y-2] == 93 || map[p->x+1][p->y-3] == 93) // 캐릭터 하단  
	{
		//속도 느리게, (423), +5000, 40000이면 변동없음, 최대 6만
		
		if(map[p->x-4][p->y+4] == 93)
		map[p->x-4][p->y+4] = 0;
	
		if(p->speed_up >= 40000)	// 40000보다 크거나 같으면 4만, 아니면 +5천
			p->speed_up = 40000;
		else p->speed_up += 5000;
	}
	
	if(map[p->x][p->y+4] == 94 || map[p->x-1][p->y+4] == 94 || map[p->x-2][p->y+4] == 94 || map[p->x-3][p->y+4] == 94 || map[p->x-4][p->y+4] == 94 || map[p->x+1][p->y+4] == 94|| // 캐릭터 전방
                map[p->x-4][p->y+3] == 94 || map[p->x-4][p->y+2] == 94 || map[p->x-4][p->y+1] ==94 || map[p->x-4][p->y-1] == 94 || map[p->x-4][p->y+4] == 94 || map[p->x-4][p->y-2] == 94 || map[p->x-4][p->y-3] == 94 ||// 캐릭터 상단
                map[p->x+1][p->y+3] == 94 || map[p->x+1][p->y+2] == 94 || map[p->x+1][p->y+1] == 94 || map[p->x+1][p->y-1] == 94 || map[p->x+1][p->y+4] == 94 || map[p->x+1][p->y-2] == 94 || map[p->x+1][p->y-3] == 94) // 캐릭터 하단 
	{
		//점수
		
		if(map[p->x-4][p->y+4] == 94)
		map[p->x-4][p->y+4] = 0;
	
		p->score_up=ti_s->tot+100;
	}
	// 멀티 아이템1 먹음
	if(map[p->x][p->y+4] == 95 || map[p->x-1][p->y+4] == 95 || map[p->x-2][p->y+4] == 95 || map[p->x-3][p->y+4] == 95 || map[p->x-4][p->y+4] == 95 || map[p->x+1][p->y+4] == 95 ||// 캐릭터 전방
                map[p->x-4][p->y+3] == 95 || map[p->x-4][p->y+2] == 95 || map[p->x-4][p->y+1] ==95 || map[p->x-4][p->y-1] == 95 || map[p->x-4][p->y+4] == 95 || map[p->x-4][p->y-2] == 95 || map[p->x-4][p->y-3] == 95 ||// 캐릭터 상단
                map[p->x+1][p->y+3] == 95 || map[p->x+1][p->y+2] == 95 || map[p->x+1][p->y+1] == 95 || map[p->x+1][p->y-1] == 95 || map[p->x+1][p->y+4] == 95 || map[p->x+1][p->y-2] == 95 || map[p->x+1][p->y-3] == 95) // 캐릭터 하단  
	{
		
		if(map[p->x-4][p->y+4] == 95)
		map[p->x-4][p->y+4] = 0;
	
		p->item[0]=1;
	}

	// 멀티 아이템2 먹음
	if(map[p->x][p->y+4] == 96 || map[p->x-1][p->y+4] == 96 || map[p->x-2][p->y+4] == 96 || map[p->x-3][p->y+4] == 96 || map[p->x-4][p->y+4] == 96 || map[p->x+1][p->y+4] == 96 ||// 캐릭터 전방
                map[p->x-4][p->y+3] == 96 || map[p->x-4][p->y+2] == 96 || map[p->x-4][p->y+1] ==96 || map[p->x-4][p->y-1] == 96 || map[p->x-4][p->y+4] == 96 || map[p->x-4][p->y-2] == 96 || map[p->x-4][p->y-3] == 96 ||// 캐릭터 상단
                map[p->x+1][p->y+3] == 96 || map[p->x+1][p->y+2] == 96 || map[p->x+1][p->y+1] == 96 || map[p->x+1][p->y-1] == 96 || map[p->x+1][p->y+4] == 96 || map[p->x+1][p->y-2] == 96 || map[p->x+1][p->y-3] == 96) // 캐릭터 하단 
	{
		//멀티, 속도 빠르게, -10000
		
		if(map[p->x-4][p->y+4] == 96)
		map[p->x-4][p->y+4] = 0;
		
		p->item[2]=1;
	}
	
	// 멀티아이템 1효과
	if(p->item[1]!=0)	
	{
		p->item[1]=0;
		p->h_index = ti_s->tot+100;
	}
	// 멀티아이템 2효과
	if(p->item[3]!=0)	
	{
		if(p->speed_up-7000<20000)
			p->speed_up=20000;
		else if(p->speed_up>=27000)
			p->speed_up-=7000;
		p->item[3]=0;
	}
}

int getch(void) // 키보드의 값을 입력 받음
{
    int ch;
    struct termios buf;
    struct termios save;

    tcgetattr(0,&save);
    buf=save;
    buf.c_lflag&=~(ICANON|ECHO);
    buf.c_cc[VMIN]=1;
    buf.c_cc[VTIME]=0;
    tcsetattr(0,TCSAFLUSH,&buf);
    ch=getchar();
    tcsetattr(0,TCSAFLUSH,&save);

    return ch;
}

int kbhit(void) // 키보드를 눌렀는지 확인
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if(ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }
}

void gotoxy(int x, int y) // 커서 이동
{
    printf("\033[%d;%df",y,x);
    fflush(stdout);
}

void *t_func(void *data)
{
    struct timer *c=(struct timer*)data;
    c->mi=0;
    c->s=0;
    c->tot=0;
    int id;
    int i=0;

    while(!(c->hp <= 0))
    {

        c->s=c->s+0.1;
        c->tot+=1;
        if(c->s>59.9)
        {
            c->s=0;
            c->mi+=1;
        }
        usleep(100000);   
    }

}
void ch_skill(struct timer* ti_s,Clnt * p)
{
    if(p->ch_select==0)//무민(끝)
    {
		if(ti_s->tot!=0&&ti_s->tot%300==0&&(p->y<49)) p->y+=2;//30초마다 전진(밀렸을시)
        if(ti_s->tot!=0&&ti_s->tot%300==0)
		{
			if(p->hp+15>p->hp_max)p->hp=p->hp_max;
			else p->hp+=15;                //30초마다 hp30 회복
		}
    }
    if(p->ch_select==1)//쥐(끝)
    {
        if(ti_s->tot!=0&&ti_s->tot%300==0)p->invincible=ti_s->tot+30;//30초마다 3초 무적
    }
    if(p->ch_select==2)//나비
    {
		int tmp = 5; // 나비 랜덤 아이템 효과
		if(ti_s->tot!=0&&ti_s->tot%300==0) tmp=rand()% 3;
		switch(tmp)
		{
			case 0:
				if(p->speed_up-7000<20000)
					p->speed_up=20000;
				else if(p->speed_up>=27000)
					p->speed_up-=7000;
			break;
			case 1:
				if(p->hp+30>=p->hp_max)p->hp=p->hp_max;
				else p->hp += 30;
		
			break;
			case 2:
				p->invincible = ti_s->tot+100;	
		
			break;
			case 3:
				p->score_up=ti_s->tot+100;
			break;
			default:
			break;
		}
    }
    if(p->ch_select==3)//개 (끝)
    {   
        if(ti_s->tot!=0&&ti_s->tot%300==0) p->score_up=ti_s->tot+50;//30초마다 5초 점수보너스
		if(ti_s->tot!=0&&ti_s->tot%300==0&&(p->y<49)) p->y+=2;//30초마다 전진(밀렸을시)
	}
}
void get_score(Clnt *p, int map[ROW][COL])//점수=(거리*플레이어위치효과)+장애물 넘은 여부
{
    if(p->score_up!=0) p->score+=1*2;//점수보너스시 2배
	//else if(p->y <= 50 && p->y > 40) p->score+=;
    else p->score+=1;//플레이어위치(밀려죽기직전? 난이도)에 따른 배율 점수 부여 (거리에 따른 점수 부여 설정 필요)
	
	if(map[ROW-6][p->y]>50)//플레이어 위치보다 하단에 장애물이 있었다면20점 증가
	{
		if(p->score_up!=0) p->score+=20;
		else p->score+=20;
	}
			// 카운터가 0이 되면 거리 증가횟수 down //
	if(p->dis_cnt > 100) p->dis_cnt = 0;
	else p->dis_cnt += 1;
	
	switch(p->y)
	{
		case 50: if(p->dis_cnt % 50 != 0) p->distanse += 1; break; 
		case 49: if(p->dis_cnt % 51 != 0) p->distanse += 1; break; 
		case 48: if(p->dis_cnt % 52 != 0) p->distanse += 1; break; 
		case 47: if(p->dis_cnt % 53 != 0) p->distanse += 1; break; 
		case 46: if(p->dis_cnt % 54 != 0) p->distanse += 1; break; 
		case 45: if(p->dis_cnt % 55 != 0) p->distanse += 1; break; 
		case 44: if(p->dis_cnt % 56 != 0) p->distanse += 1; break; 
		case 43: if(p->dis_cnt % 57 != 0) p->distanse += 1; break; 
		case 42: if(p->dis_cnt % 58 != 0) p->distanse += 1; break; 
		case 41: if(p->dis_cnt % 59 != 0) p->distanse += 1; break; 
		case 40: if(p->dis_cnt % 60 != 0) p->distanse += 1; break;
		case 39: if(p->dis_cnt % 61 != 0) p->distanse += 1; break; 
		case 38: if(p->dis_cnt % 62 != 0) p->distanse += 1; break; 
		case 37: if(p->dis_cnt % 63 != 0) p->distanse += 1; break; 
		case 36: if(p->dis_cnt % 64 != 0) p->distanse += 1; break; 
		case 35: if(p->dis_cnt % 65 != 0) p->distanse += 1; break; 
		case 34: if(p->dis_cnt % 66 != 0) p->distanse += 1; break; 
		case 33: if(p->dis_cnt % 67 != 0) p->distanse += 1; break; 
		case 32: if(p->dis_cnt % 68 != 0) p->distanse += 1; break; 
		case 31: if(p->dis_cnt % 69 != 0) p->distanse += 1; break; 
		case 30: if(p->dis_cnt % 70 != 0) p->distanse += 1; break; 
		case 29: if(p->dis_cnt % 71 != 0) p->distanse += 1; break; 
		case 28: if(p->dis_cnt % 72 != 0) p->distanse += 1; break; 
		case 27: if(p->dis_cnt % 73 != 0) p->distanse += 1; break; 
		case 26: if(p->dis_cnt % 74 != 0) p->distanse += 1; break; 
		case 25: if(p->dis_cnt % 75 != 0) p->distanse += 1; break; 
		case 24: if(p->dis_cnt % 76 != 0) p->distanse += 1; break; 
		case 23: if(p->dis_cnt % 77 != 0) p->distanse += 1; break; 
		case 22: if(p->dis_cnt % 78 != 0) p->distanse += 1; break; 
		case 21: if(p->dis_cnt % 79 != 0) p->distanse += 1; break; 
		case 20: if(p->dis_cnt % 80 != 0) p->distanse += 1; break; 
		case 19: if(p->dis_cnt % 81 != 0) p->distanse += 1; break; 
		case 18: if(p->dis_cnt % 82 != 0) p->distanse += 1; break; 
		case 17: if(p->dis_cnt % 83 != 0) p->distanse += 1; break; 
		case 16: if(p->dis_cnt % 84 != 0) p->distanse += 1; break; 
		case 15: if(p->dis_cnt % 85 != 0) p->distanse += 1; break; 
		case 14: if(p->dis_cnt % 86 != 0) p->distanse += 1; break; 
		case 13: if(p->dis_cnt % 87 != 0) p->distanse += 1; break; 
		case 12: if(p->dis_cnt % 88 != 0) p->distanse += 1; break; 
		case 11: if(p->dis_cnt % 89 != 0) p->distanse += 1; break; 
		case 10: if(p->dis_cnt % 90 != 0) p->distanse += 1; break; 
		case 9: if(p->dis_cnt % 91 != 0) p->distanse += 1; break; 
		case 8: if(p->dis_cnt % 92 != 0) p->distanse += 1; break; 
		case 7: if(p->dis_cnt % 93 != 0) p->distanse += 1; break; 
		case 6: if(p->dis_cnt % 94 != 0) p->distanse += 1; break; 
		case 5: if(p->dis_cnt % 95 != 0) p->distanse += 1; break; 
		case 4: if(p->dis_cnt % 96 != 0) p->distanse += 1; break; 
		case 3: if(p->dis_cnt % 97 != 0) p->distanse += 1; break; 
		case 2: if(p->dis_cnt % 98 != 0) p->distanse += 1; break; 		
	}
}

void buff_recv(Clnt *p, struct timer *ti_s)//점수보너스 시간지나면 돌아오게.
{
    if(p->score_up<=ti_s->tot)   p->score_up=0;    //점수보너스 제거
    if(p->invincible<=ti_s->tot) p->invincible=0;  //무적 제거
	if(p->h_index<=ti_s->tot)	 p->h_index=0;	   // 장애물 출현빈도 시간 제거
}
void bubble_sort(void *p)
{
	// i = player의 넘버
	Clnt *clt = (Clnt*)p;
	
	char t_name[NAMESIZE];
	
	for (int i=0; i<4; i++){
		for (int j=0; j<3-i; j++){
			if(clt->I.score[j] < clt->I.score[j+1]){
				i_swap(&clt->I.score[j],&clt->I.score[j+1]);	// 점수
				
				strcpy(t_name, clt->I.play_name[j+1]);  // 이름
				strcpy(clt->I.play_name[j+1], clt->I.play_name[j]);
				strcpy(clt->I.play_name[j], t_name);
			}
		}
	}
}
// 값의 순서를 바꿔줌
void i_swap(int *a, int *b)
{
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}
void end_game(color *col) // 게임 끝
{
	system("clear");
	printf("\n\n\n\n\n\n\n\n");
	COLOR
	printf("\t\t██╗   ██╗ ██████╗ ██╗   ██╗    ██████╗ ██╗███████╗██████╗     ██╗\n");
	printf("\t\t╚██╗ ██╔╝██╔═══██╗██║   ██║    ██╔══██╗██║██╔════╝██╔══██╗    ██║\n");
	printf("\t\t ╚████╔╝ ██║   ██║██║   ██║    ██║  ██║██║█████╗  ██║  ██║    ██║\n");
	printf("\t\t  ╚██╔╝  ██║   ██║██║   ██║    ██║  ██║██║██╔══╝  ██║  ██║    ╚═╝\n");
	printf("\t\t   ██║   ╚██████╔╝╚██████╔╝    ██████╔╝██║███████╗██████╔╝    ██╗\n");
	printf("\t\t   ╚═╝    ╚═════╝  ╚═════╝     ╚═════╝ ╚═╝╚══════╝╚═════╝     ╚═╝\n");
	printf("\x1b[0m");
    return;                                                
}

void intro(void)
{
	int i, j;
	
	system("clear");
	for(i=0; i<55; i++)
	{
		gotoxy(i, 20);
		printf(RED"불"DEF);printf("이야! ");printf(RED"불"DEF);printf("이야!\n");
		printf("\x1b[H\x1b[J");
		usleep(50000);
	}
	system("clear");
	
	for(i=100; i>=40; i--)
	{
		gotoxy(54, 20);
		printf(RED"불"DEF);printf("이야! ");printf(RED"불"DEF);printf("이야!\n");
		gotoxy(i, 21);
		printf("넥순 별장의 ");printf(RED"불"DEF);printf("이 번져서 산에 옮겨 붙었다!\n");
		printf("\x1b[H\x1b[J");
		usleep(50000);
	}
	
	for(i=0; i<45; i++)
	{
		gotoxy(54, 20);
		printf(RED"불"DEF);printf("이야! ");printf(RED"불"DEF);printf("이야!\n");
		gotoxy(40, 21);
		printf("넥순 별장의 ");printf(RED"불"DEF);printf("이 번져서 산에 옮겨 붙었다!\n");
		gotoxy(i, 22);
		printf("불쌍한 동물들의 탈출을 도와주세요!\n");
		printf("\x1b[H\x1b[J"); 
		usleep(50000);
	}
	sleep(2);
	gotoxy(40, 22);
	printf(GREEN"각 캐릭터 마다 고유 능력이 있고, 각 아이템을 먹으면 효과를 얻습니다.\n"DEF);
	usleep(1500000);
	gotoxy(40, 23);
	printf(GREEN"구덩이에 빠지면 좌측으로 밀려나게 되고 캐릭터가 좌측에 닿았을 시 게임이 끝납니다.\n"DEF);
	usleep(1500000);
	gotoxy(40, 24); 
	printf(GREEN"점프 키는 위쪽 방향키 입니다.\n"DEF);
	sleep(3); 
	system("clear");
	return;
}


char* SimpleRanking(RankData* rd)
{
    char* result = (char*)malloc(sizeof(char)*100);

    int idx = 0;
    int arrLength = 20;  // 초기 RankData배열 크기
    rd = (RankData*)malloc(sizeof(RankData)*arrLength);
    FILE* fp = fopen("ranking.txt", "r");

    if(fp == NULL)
    {
        return "file open error";
    }

    while(!feof(fp))
    {
        if(idx >= arrLength)
        {
            // 재할당
            arrLength+=5;
            rd = (RankData*)realloc(rd, sizeof(RankData)*arrLength);
        }

        // RankData 구조체에 저장
        char temp[3];
        fscanf(fp, "%s %s %d %d %d %s\n", temp, rd[idx].name, &rd[idx].timeRecord, &rd[idx].score, &rd[idx].distance, rd[idx].date);
        idx++;
    }

    // quick sort
    QuickSort(rd, 0, idx-1, 1);

    char temp[100];

    for(int i=0;i<5;i++)
    {
        sprintf(temp, "%2d\t%s\t\t%d\t\t%d\t\t%d\t\t%s\n", i+1, rd[i].name, rd[i].timeRecord, rd[i].score, rd[i].distance, rd[i].date);
        strcat(result, temp); 
    }

    return result;
}


void PrintRanking(int sortby)
{
    int idx = 0;
    int arrLength = 20;  // 초기 RankData배열 크기
    RankData* rd = (RankData*)malloc(sizeof(RankData)*arrLength);
    FILE* fp = fopen("ranking.txt", "r");

    if(fp == NULL)
    {
        puts("file open error");
        return;
    }

    while(!feof(fp))
    {
        if(idx >= arrLength)
        {
            // 재할당
            arrLength+=5;
            rd = (RankData*)realloc(rd, sizeof(RankData)*arrLength);
        }

        // RankData 구조체에 저장
        char temp[3];
        fscanf(fp, "%s %s %d %d %d %s\n", temp, rd[idx].name, &rd[idx].timeRecord, &rd[idx].score, &rd[idx].distance, rd[idx].date);
        idx++;
    }

    // quick sort
    QuickSort(rd, 0, idx-1, sortby);

    int maxLine = idx >= 20 ? 20 : idx;  // 출력할 라인 수

    __fpurge(stdin);    // buffer clear
    system("clear");

    RED1
    printf("    |**********************██████╗  █████╗ ███╗   ██╗██╗  ██╗*******************| \n");
    printf("    [                      ██╔══██╗██╔══██╗████╗  ██║██║ ██╔╝                  .]\n");
    printf("    [ *      *    .      * ██████╔╝███████║██╔██╗ ██║█████╔╝ *     *      .     ]\n");
    printf("    [    .            .    ██╔══██╗██╔══██║██║╚██╗██║██╔═██╗    .       .       ]\n");
    printf("    [                      ██║  ██║██║  ██║██║ ╚████║██║  ██╗                 * ]\n");
    printf("    '**********************╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝*******************'\n");
    puts("rank\tname\t\ttime\t\tscore\t\tdistance\tdate");
    DEF1

        for(int i=0;i<maxLine;i++)
        {
            printf("%2d\t%s\t\t%d\t\t%d\t\t%d\t\t%s\n", i+1, rd[i].name, rd[i].timeRecord, rd[i].score, rd[i].distance, rd[i].date);
        }

    putchar('\n');
    puts("         [1]시간 순 정렬         [2]점수 순 정렬       [3]거리 순 정렬     ");
    YELLOW1
        printf("\n");
    printf("\n");
    puts("                              < 돌아가기[enter]              ");
    DEF1

    free(rd);
    fclose(fp);

    int key = getch();
    if(key == '1')
        PrintRanking(1);
    else if(key == '2')
        PrintRanking(2);
    else if(key == '3')
        PrintRanking(3);
    else if(key == '\n')
        system("clear");
        return;
}

void QuickSort(RankData* rd, int left, int right, int sortby)
{
    int pivot = left;
    int j = pivot;

    // 데이터가 2개 이상일때 정렬 실행
    if(left<right)
    {
        for(int i=left+1;i<=right;i++)
        {
            switch(sortby)
            {
                case 1: // 시간 순 정렬
                    if(rd[i].timeRecord > rd[pivot].timeRecord)
                    {
                        j++;
                        Swap(rd, i, j);
                    }
                    break;
                case 2: // 점수 순 정렬
                    if(rd[i].score> rd[pivot].score)
                    {
                        j++;
                        Swap(rd, i, j);
                    }
                    break;
                case 3: // 거리 순 정렬
                    if(rd[i].distance> rd[pivot].distance)
                    {
                        j++;
                        Swap(rd, i, j);
                    }
                    break;
            }
        }
        Swap(rd, left, j);

        pivot = j;
        QuickSort(rd, left, pivot-1, sortby);
        QuickSort(rd, pivot+1, right, sortby);
    }
}

void Swap(RankData* rd, int a, int b)
{
    RankData temp = rd[a];
    rd[a] = rd[b];
    rd[b] = temp;
}

void RecieveRanking(char ip[30], char port[10])
{
    int sd;
    FILE* fp;

    char buf[BUFFSIZE];
    int read_cnt;
    struct sockaddr_in serv_adr;

    // 수신한 데이터를 저장할 파일 오픈
    fp = fopen("ranking.txt", "w"); 

    // 서버 접속을 위한 소켓 생성
    sd = socket(PF_INET, SOCK_STREAM, 0);
    if (sd == -1)
        error_handling("socket() error");

    memset(&serv_adr, 0, sizeof(serv_adr));
    serv_adr.sin_family = AF_INET;
    serv_adr.sin_addr.s_addr = inet_addr(ip);
    serv_adr.sin_port = htons(atoi(port));

    if (connect(sd, (struct sockaddr*)&serv_adr, sizeof(serv_adr)) == -1)
        error_handling("connect() error");

    // EOF가 전송될 때 까지 데이터를 수신받아 파일에 저장
    while ((read_cnt = read(sd, buf, BUFFSIZE)) != 0) 
        fwrite((void*)buf, 1, read_cnt, fp);

    puts("Received file data");

    // 서버에 감사 메세지 전달
    write(sd, "Thank You", 10);

    fclose(fp);
    close(sd);
}

void SaveRanking(char* str)
{
    FILE* fp = fopen("ranking.txt", "a");
    const time_t timer = time(NULL);
    struct tm* t = localtime(&timer);

    int year = t->tm_year + 1900;
    int month = t->tm_mon + 1;
    int day = t->tm_mday;
    int dayOfWeek = t->tm_wday;
    char dayNames[][4] = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};
    char date[20];

    // year, month, day, daynames 한문자열로 합쳐서 date에 저장
    sprintf(date, "%d-%d-%d(%s)", year, month, day, dayNames[dayOfWeek]);


    fprintf(fp, "%s %s\n", str, date);

    fclose(fp);
}