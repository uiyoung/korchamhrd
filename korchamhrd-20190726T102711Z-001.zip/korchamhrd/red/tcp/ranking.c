#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <termios.h>

#define NAMESIZE 20

typedef struct _Player
{
    char name[NAMESIZE];
    int timeRecord;
    int score;
    int distance;
} Player;

typedef struct _RankData
{
    char name[NAMESIZE];
    int score;
    int timeRecord;
    int distance;
    char date[20];
} RankData;

void SaveRanking(Player p);
void PrintRanking(int sortby);
void QuickSort(RankData* rd, int left, int right, int sortby);
void Swap(RankData* rd, int a, int b);
int getch();

int main()
{
    srand(time(NULL));

    Player p1;
    /* test data */
    strcpy(p1.name, "suy");
    p1.timeRecord = rand() % 100; 
    p1.score = rand()%100;
    p1.distance = rand()%100; 
    /* end of test data*/

    //    SaveRanking(p1);
    PrintRanking(1);

    return 0;
}

void SaveRanking(Player p)
{
    FILE* fp = fopen("ranking.txt", "a");
    const time_t timer = time(NULL);
    struct tm* t = localtime(&timer);

    int year = t->tm_year + 1900;
    int month = t->tm_mon + 1;
    int day = t->tm_mday;
    int dayOfWeek = t->tm_wday;
    char dayNames[][4] = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};
    char date[20];

    // year, month, day, daynames 한문자열로 합쳐서 date에 저장
    sprintf(date, "%d-%d-%d(%s)", year, month, day, dayNames[dayOfWeek]);

    fprintf(fp, "%s %d %d %d %s\n", p.name, p.timeRecord, p.score, p.distance, date);

    fclose(fp);
}

void PrintRanking(int sortby)
{
    int idx = 0;
    int arrLength = 20;  // 초기 RankData배열 크기
    RankData* rd = (RankData*)malloc(sizeof(RankData)*arrLength);
    FILE* fp = fopen("ranking.txt", "r");

    if(fp == NULL)
    {
        puts("file open error");
        exit(1);
    }

    while(!feof(fp))
    {
        if(idx >= arrLength) 
        {
            // 재할당
            arrLength+=5;
            rd = (RankData*)realloc(rd, sizeof(RankData)*arrLength);
        }

        // RankData 구조체에 저장
        fscanf(fp, "%s %d %d %d %s\n", rd[idx].name, &rd[idx].timeRecord, &rd[idx].score, &rd[idx].distance, rd[idx].date);
        idx++;
    }

    // quick sort
    QuickSort(rd, 0, idx-1, sortby);

    int maxLine = idx >= 20 ? 20 : idx;  // 출력할 라인 수

    system("clear");
    puts("Ranks");
    puts("rank\tname\t\ttime\t\tscore\t\tdistance\tdate");

    for(int i=0;i<maxLine;i++)
    {
        printf("%2d\t%s\t\t%d\t\t%d\t\t%d\t\t%s\n", i+1, rd[i].name, rd[i].timeRecord, rd[i].score, rd[i].distance, rd[i].date);
    }

    putchar('\n');
    puts("[1]시간 순 정렬 [2]점수 순 정렬 [3]거리 순 정렬");
    puts("< 이전 메뉴로[enter]");

    int key = getch();
    if(key == '\n')
        return;
    else if(key == '1')
        PrintRanking(1);
    else if(key == '2')
        PrintRanking(2);
    else if(key == '3')
        PrintRanking(3);

    free(rd);
    fclose(fp);
}

void QuickSort(RankData* rd, int left, int right, int sortby)
{
    int pivot = left;
    int j = pivot;

    // 데이터가 2개 이상일때 정렬 실행
    if(left<right)
    {
        for(int i=left+1;i<=right;i++)
        {
            switch(sortby)
            {
                case 1: // 시간 순 정렬
                    if(rd[i].timeRecord > rd[pivot].timeRecord)
                    {
                        j++;
                        Swap(rd, i, j);
                    }
                    break;
                case 2: // 점수 순 정렬
                    if(rd[i].score> rd[pivot].score)
                    {
                        j++;
                        Swap(rd, i, j);
                    }
                    break;
                case 3: // 거리 순 정렬
                    if(rd[i].distance> rd[pivot].distance)
                    {
                        j++;
                        Swap(rd, i, j);
                    }
                    break;
            }
        }
        Swap(rd, left, j);

        pivot = j;
        QuickSort(rd, left, pivot-1, sortby);
        QuickSort(rd, pivot+1, right, sortby);
    }
}

void Swap(RankData* rd, int a, int b)
{
    RankData temp = rd[a];
    rd[a] = rd[b];
    rd[b] = temp;
}

int getch(void)
{
    int ch;
    struct termios buf;
    struct termios save;

    tcgetattr(0,&save);
    buf=save;
    buf.c_lflag&=~(ICANON|ECHO);
    buf.c_cc[VMIN]=1;
    buf.c_cc[VTIME]=0;
    tcsetattr(0,TCSAFLUSH,&buf);
    ch=getchar();
    tcsetattr(0,TCSAFLUSH,&save);

    return ch;
}
