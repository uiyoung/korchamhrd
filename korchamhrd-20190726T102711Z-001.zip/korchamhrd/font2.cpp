#include <iostream>
#include <vector>

using namespace std;

ostream& style_off(ostream& os)
{
    return os << "\e[0m";
}

ostream& bold_on(ostream& os)
{
    return os << "\e[1m";
}

ostream& italic_on(ostream& os)
{
    return os << "\e[3m";
}

ostream& underline_on(ostream& os)
{
    return os << "\e[4m";
}

ostream& curly_underline_on(ostream& os)
{
    return os << "\e[4:3m";
}

ostream& strike_on(ostream& os)
{
    return os << "\e[9m";
}

ostream& reverse_on(ostream& os)
{
    return os << "\e[7m";
}



int main()
{
    vector<string> v;
    v.push_back("The quick brown fox jumps over the lazy dog.");
    v.push_back("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.");
    v.push_back("Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.");
    v.push_back("Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.");
    v.push_back("Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.");

    for(vector<string>::size_type i=0;i<v.size();i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;

    while(true)
    {
        int choice;
        cout << "\n[1]bold [2]italic [3]underline [4]curly underline [5]strike [6]reverse [0]exit\n>>";
        cin >> choice;

        switch(choice)
        {
            case 1:
                cout << bold_on;
                break;
            case 2:
                cout << italic_on;
                break;
            case 3:
                cout << underline_on;
                break;
            case 4:
                cout << curly_underline_on;
                break;
            case 5:
                cout << strike_on;
                break;
            case 6:
                cout << reverse_on;
                break;
            case 0:
                return 0;
        }

        for(vector<string>::size_type i=0;i<v.size();i++)
        {
            cout << v[i] << " ";
        }
        cout << style_off << endl;
    }

    return 0;
}
