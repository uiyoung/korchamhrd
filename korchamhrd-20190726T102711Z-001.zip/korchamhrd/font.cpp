#include <iostream>

std::ostream& style_off(std::ostream& os)
{
    return os << "\e[0m";
}

std::ostream& bold_on(std::ostream& os)
{
    return os << "\e[1m";
}

std::ostream& italic_on(std::ostream& os)
{
    return os << "\e[3m";
}

std::ostream& underline_on(std::ostream& os)
{
    return os << "\e[4m";
}

std::ostream& curly_underline_on(std::ostream& os)
{
    return os << "\e[4:3m";
}

std::ostream& strike_on(std::ostream& os)
{
    return os << "\e[9m";
}

std::ostream& reverse_on(std::ostream& os)
{
    return os << "\e[7m";
}

using namespace std;

int main()
{
    string str = "The quick brown fox jumps over the lazy dog";

    cout << str << endl;
    cout << bold_on << str << style_off<< endl; 
    cout << italic_on << str << style_off<< endl; 
    cout << underline_on<< str << style_off<< endl; 
    cout << curly_underline_on<< str << style_off<< endl; 
    cout << strike_on<< str << style_off<< endl; 
    cout << reverse_on<< str << style_off<< endl; 

    return 0;
}