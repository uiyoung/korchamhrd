#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>

int main()
{
    int fdes1, fdes2, fdes3;

    // socket 생성
    fdes1 = socket(PF_INET, SOCK_STREAM, 0);
    // file 생성
    fdes2 = open("test.dat", O_CREAT);
    // socket 생성
    fdes3 = socket(PF_INET, SOCK_DGRAM, 0);

    printf("첫 번째 file descriptor : %d\n", fdes1);
    printf("두 번째 file descriptor : %d\n", fdes2);
    printf("세 번째 file descriptor : %d\n", fdes3);

    close(fdes1);
    close(fdes2);
    close(fdes3);

    return 0;
}


