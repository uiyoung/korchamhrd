﻿//UI.h
#ifndef UI_H
#define UI_H
using namespace std;
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <thread>
#include <mutex>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>
//김태완 
#include "Notepad.cpp"
#include "Gotoxy.cpp"
#include "Menu.cpp"
//문선철 
#include "Mode.cpp"

//오지구
#include "Cursor.cpp"


#endif

