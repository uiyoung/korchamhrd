﻿//Language.cpp
#include "UI.h"
#ifndef LANGUAGE_H
#define LANGUAGE_H

class Language
{
	private:
			
	public:
		string mode;
		void print(int i)
		{
			if(i==0)
				mode = "가";
			else if(i==1)
				mode = "A";
			cout << " | 한/영   "<< mode;		
		}
};
#endif
