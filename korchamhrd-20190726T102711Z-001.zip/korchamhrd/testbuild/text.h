#ifndef TEXT_H
#define TEXT_H
#include <iostream>
#include <vector>

#define ORIGIN_POS_X 25	// 커서의 X좌표 원점 
#define ORIGIN_POS_Y 4 // 커서의 Y좌표 원점 
#define WIDTH_LIMIT 50	// UI에서 출력 가능한 문자 한도 수 
#define HEIGHT_LIMIT 29	// UI에서 출력 가능한 라인 한도 수 

class Text{
	private:
		std::vector <std::string> textBuffer;
		int cursorPos_y;
		int cursorPos_x;
		int bufferIndex_y;
		int bufferIndex_x;
		int boundaryOfIndex_y;
	public:	
		Text();
		~Text();
		int GetCursor_xPos();
		int GetCursor_yPos();
		int GetBuffer_xIndex();
		int GetBuffer_yIndex();
		int GetBoundary_yIndex();
		void SetCursor_xPos(int value);
		void SetCursor_yPos(int value);
		void SetBuffer_xIndex(int value);
		void SetBuffer_yIndex(int value);
		void SetBoundary_yIndex(int value);
		std::vector <std::string> *GetText();
};

#endif