#include "gui.h"

void Gui::MakeBox(int width, int height, int boxPos_x, int boxPos_y, std::vector <std::string> &strs, int strPos_x, int strPos_y )
{
	if ( strPos_y == TOP)
		strPos_y = boxPos_y +1;
	else
		strPos_y = boxPos_y+1 + height/2;
	
	if (strPos_x == CENTER)
		strPos_x = boxPos_x+1 + width/2;
	else 
		strPos_x = boxPos_x + 2;
	
	int i, numOfCharacter;
	gotoxy(boxPos_x,boxPos_y);
	std::cout<<"┏";
	inputLine("━", width);
	std::cout<<"┓";
	for(i =1; i<=height; i++)
	{
		gotoxy(boxPos_x,boxPos_y+i);
		std::cout<< "┃";
		inputLine(" ", width);
		std::cout<< "┃";
	}
	gotoxy(boxPos_x,boxPos_y+i);
	std::cout<<"┗";
	inputLine("━", width);
	std::cout<<"┛";
	
	for(int i=0; i<strs.size(); i++)
	{
		numOfCharacter = countCharacter(strs[i]);
		
		gotoxy(strPos_x - numOfCharacter/2, strPos_y +i);
		std::cout<< strs[i];
		
	}
}

void Gui::MakeBox(int width, int height, int boxPos_x, int boxPos_y, std::string str, int strPos_x, int strPos_y)
{	
	if ( strPos_y == TOP) 
		strPos_y = boxPos_y +1;
	else 
		strPos_y =  boxPos_y+1+ height/2;
	
	if (strPos_x == CENTER) 
		strPos_x = boxPos_x+1 + width/2;
	else 
		strPos_x = boxPos_x + 2;
	
	int i, numOfCharacter;
	gotoxy(boxPos_x,boxPos_y);
	std::cout<<"┏";
	inputLine("━", width);
	std::cout<<"┓";
	for(i =1; i<=height; i++)
	{
		gotoxy(boxPos_x,boxPos_y+i);
		std::cout<< "┃";
		inputLine(" ", width);
		std::cout<< "┃";
	}
	gotoxy(boxPos_x,boxPos_y+i);
	std::cout<<"┗";
	inputLine("━", width);
	std::cout<<"┛";
	
	numOfCharacter = countCharacter(str);
	gotoxy(strPos_x - numOfCharacter/2, strPos_y);
	std::cout <<str;
}

void Gui::MakeTable(std::vector <std::string> *text, int currentLine)
{		

	char input;
	int rowNum, colNum, colSize;
	std::vector <std::string> inputList{" [ 표 그리기 ] ", "행 갯수 :         ", "열 갯수 :         ",  "사이즈 :         ", "취소 [ q ]"}; 
	
	MakeBox(WIDTH_LIMIT-10, inputList.size()+1, ORIGIN_POS_X+3, ORIGIN_POS_Y+4, inputList, CENTER, TOP);
	gotoxy(ORIGIN_POS_X+15, ORIGIN_POS_Y+5);
	
	for(int i =0; i<3; )
	{
		gotoxy(ORIGIN_POS_X+27, ORIGIN_POS_Y+6+i);
		input = getch();
		
		// 아스키 코드 1~ 9
		if(input >=49 && input <58)
		{
			if(i==0)  rowNum = input-48;
			else if(i ==1) 
			{
				colNum = input-48;
				if(colNum >4) colNum = 4;
			}
			else colSize = (input-48) * 3; // 한글을 기준으로 하여 사이즈 1(문자 1개 ) 당 *3을 곱한다
			
			std::cout << input;
			i++;
		}
		else if (input == 'q') return;
		else
		{
			gotoxy(ORIGIN_POS_X+16, ORIGIN_POS_Y+11);
			inputLine(" ", 8);
			gotoxy(ORIGIN_POS_X+16, ORIGIN_POS_Y+11);
			std::cout<<"숫자만 입력가능 합니다";
		}
	}
	
	int tableWidthLimit = WIDTH_LIMIT - 2;
	//				사이즈에 따른 문자수 * 열 갯수 + 열 구분 선 + 좌 우측 끝 선 
	int tableWidth = ( ((colSize/3)*2) * colNum) + colNum-1 + 2;
	if(tableWidth > tableWidthLimit  )
	{		
		colSize = (tableWidthLimit - (colNum-1) *3) /colNum;
		colSize -= colSize%3;
		tableWidth = ( ((colSize/3)*2) * colNum) + colNum-1 + 2;
	}	
	
	std::string topLine, middleLine, fillLine;
	
	
	/*
	for(int i = 0; i<tableWidth; i++)
	{
		if(i ==0 ) topLine += "┌";
		else if (i == tableWidth-1 ) topLine += "┐";
		else topLine += "─";
	}
	text->insert(text->begin()+currentLine, topLine);
	
	
	for(int i = 0; i<tableWidth; i++)
	{
		if(i==0 || i == tableWidth -1 ) middleLine +=  "│";
		else middleLine += "─";
	}
	 
	
	std::string toFill;
	int row = 1;
	for(int i = 1; i <= rowNum*2; i++)
	{
		if( i%2 == 0)
			text->insert(text->begin() + currentLine + i, middleLine);
		else
		{
			for(int col = 1; col<=colNum; col++)
			{
				std::string temp = std::to_string(row) + "행" + std::to_string(col)+ "열 값 입력 : ";
				
				MakeBox(WIDTH_LIMIT-10, 5, ORIGIN_POS_X+3, ORIGIN_POS_Y+4, temp , CENTER, MIDDLE);
				gotoxy( ORIGIN_POS_X+20, ORIGIN_POS_Y+8);
				
				getline(std::cin, toFill);
				
				correctionString(colSize, toFill);
				toFill.replace(toFill.size(),3,  "│");
				
				fillLine += toFill;
			}
			fillLine.replace(0,0, "│");
			text->insert(text->begin() + currentLine + i, fillLine);
			fillLine.clear();
			row++;
		}
		if( i == rowNum*2) 
		{
			(*text)[currentLine + i].replace(0,3, "└");
			(*text)[currentLine + i].replace((*text)[currentLine + i].size()-3,3, "┘");
		}
		
	}
	*/
	for(int i = 0; i<tableWidth; i++)
	{
		if(i ==0 ) topLine += " ";
		else if (i == tableWidth-1 ) topLine += " ";
		else topLine += "-";
	}
	text->insert(text->begin()+currentLine, topLine);
	
	
	for(int i = 0; i<tableWidth; i++)
	{
		if(i==0 || i == tableWidth -1 ) middleLine +=  "|";
		else middleLine += "-";
	}
	 
	
	std::string toFill;
	int row = 1;
	for(int i = 1; i <= rowNum*2; i++)
	{
		if( i%2 == 0)
			text->insert(text->begin() + currentLine + i, middleLine);
		else
		{
			for(int col = 1; col<=colNum; col++)
			{
				std::string temp = std::to_string(row) + "행" + std::to_string(col)+ "열 값 입력 : ";
				
				MakeBox(WIDTH_LIMIT-10, 5, ORIGIN_POS_X+3, ORIGIN_POS_Y+4, temp , CENTER, MIDDLE);
				gotoxy( ORIGIN_POS_X+20, ORIGIN_POS_Y+8);
				
				getline(std::cin, toFill);
				
				correctionString(colSize, toFill);
				toFill.replace(toFill.size(),0,  "|");
				
				fillLine += toFill;
			}
			fillLine.replace(0,0, "|");
			text->insert(text->begin() + currentLine + i, fillLine);
			fillLine.clear();
			row++;
		}
		
		if( i == rowNum*2) 
		{
			(*text)[currentLine + i].replace(0,1, " ");
			(*text)[currentLine + i].replace((*text)[currentLine + i].size()-1,1, " ");
		}
		
	}
	
}

int Gui::countCharacter(std::string &text)
{
	int asciiCount = 0, koreanCount = 0;
	
	for(int i =0; i< text.size(); i++)
	{
		if( text[i] & 0x80) koreanCount++;
		else asciiCount++;
	}
	return asciiCount + ((koreanCount/3)*2);
}
void Gui::correctionString(int colSize, std::string &str)
{
	int asciiCount = 0, koreanCount = 0, numOfStrChar = 0;
	int allowedNumOfChar = (colSize/3) *2;

	numOfStrChar = countCharacter(str);
	
	if(allowedNumOfChar < numOfStrChar) 
	{
		if( str.size() > colSize ) str.resize(colSize);
		while(countCharacter(str) != allowedNumOfChar)
			str.resize(str.size()-1);
	
		koreanCount = 0;
		for(int j= 0; j< str.size(); j++)
			if(str[j] & 0x80) koreanCount++;
		
		if(koreanCount %3 !=0) str.resize(str.size() - koreanCount%3);
		
	}
	
	
	gotoxy(20 , 1);
	std::cout << "pass";
	gotoxy(0 , 10);
	numOfStrChar = countCharacter(str);
	
	if ( numOfStrChar < allowedNumOfChar)
	{
		for(int i=1; i<= allowedNumOfChar - numOfStrChar; i++)
		{	
			if(i%2== 0) str.replace(0,0, " ");
			else str.replace(str.size(), 0, " ");
		}
	}
	gotoxy(20 , 1);
	std::cout << "       ";
	gotoxy(0 , 10);
	gotoxy(20 , 1);
	std::cout << "pass2";
	gotoxy(0 , 10);

}