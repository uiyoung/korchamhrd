﻿//Caps.cpp
#include "UI.h"
#ifndef CAPS_H
#define CAPS_H

using namespace std;

class Caps
{
	private:
			
	public:
		string mode;
		void print(int i)
		{
			if(i==0)
				mode = "ON) | ";
			else if(i==1)
				mode = "OFF) | ";
			cout << "| Caps(" << mode;	
		}
};
#endif
