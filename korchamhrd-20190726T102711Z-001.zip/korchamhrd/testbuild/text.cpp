#include "text.h"

Text::Text()
: cursorPos_y(ORIGIN_POS_Y), cursorPos_x(ORIGIN_POS_X), bufferIndex_y(0), 
bufferIndex_x(0), boundaryOfIndex_y(0)
{
}
Text::~Text()
{
	
}

int Text::GetCursor_xPos()
{
	return cursorPos_x;
}
int Text::GetCursor_yPos()
{
	return cursorPos_y;
}

int Text::GetBuffer_xIndex()
{
	return bufferIndex_x;
}
int Text::GetBuffer_yIndex()
{
	return bufferIndex_y;
}

int Text::GetBoundary_yIndex()
{
	return boundaryOfIndex_y;
}


void Text::SetCursor_xPos(int value)
{
	cursorPos_x = value;
}


void Text::SetCursor_yPos(int value)
{
	cursorPos_y = value;
}
void Text::SetBuffer_xIndex(int value)
{
	bufferIndex_x = value;
}
void Text::SetBuffer_yIndex(int value)
{
	bufferIndex_y = value;
}
void Text::SetBoundary_yIndex(int value)
{
	boundaryOfIndex_y = value;
}

std::vector <std::string> *Text::GetText()
{
	return &textBuffer;
}

