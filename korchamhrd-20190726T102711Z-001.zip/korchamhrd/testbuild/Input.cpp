//Input.cpp
#include "UI.h"
#ifndef INPUT_H
#define INPUT_H
#define I_X 19
#define I_Y 4
#define VERT_LEN 30

class Input_{
	
private:
	Gotoxy gt;
	string input;
	
public:
	void Input(void)
	{
		gt.Setxy(I_X,I_Y);
		cout<<"내용을 입력하세요"<<endl;
		gt.Setxy(I_X,I_Y+1);
		int input;
		cin>>input;

	}
};
#endif
