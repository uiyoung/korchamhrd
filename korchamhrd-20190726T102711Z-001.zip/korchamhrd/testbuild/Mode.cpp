﻿//Mode.cpp
#include "UI.h"
#ifndef MODE_H
#define MODE_H

class Edit
{
	private:
			
	public:
		string mode;
		void print(int i)
		{
			if(i==1)
				mode = "입력";
			else if(i==2)
				mode = "메뉴";
			else if(i==3)
				mode = "블럭";
			cout << "모드(입력/메뉴/블럭) " << " (" << mode << ")"; 
		}
};
#endif
