#include "editor.h"

Editor::Editor(std::vector <std::string> *text, std::mutex *mutx)
: textBuffer(text), timer_mutx(mutx), 
modeList({" [ 편집모드 선택 ] ","입력 [ i ]","복사 [ c ]", "잘라내기 [ x ]",
		  "붙여넣기 [ p ]", "찾아서 바꾸기 [ r ]", "찾기 [ f ]", "표 그리기 [ o ]","편집모드 나가기 [ q ]"} )

{	}

Editor::~Editor()
{
	
}
void Editor::ModeSelect(Text &text)
{
	char choice;
	
	DEF
	cursorPos_y = text.GetCursor_yPos();
	cursorPos_x = text.GetCursor_xPos();
	bufferIndex_y = text.GetBuffer_yIndex();
	bufferIndex_x = text.GetBuffer_xIndex();
	boundaryOfIndex_y = text.GetBoundary_yIndex();
	
	timer_mutx->lock();
	while(1)
	{
		writeText(text);
		gui.MakeBox(WIDTH_LIMIT-10, modeList.size()+2, ORIGIN_POS_X+3, ORIGIN_POS_Y+4, modeList);
		
		gotoxy(ORIGIN_POS_X+17, ORIGIN_POS_Y+12);
		
		choice = getch();
		
		if(choice & 0x80) 
			for( int i=0; i<2; i++)
				choice = getch();
		
		switch(choice)
		{
			case 'i' : writeText(text); break;
			case 'c' : copyText(); break;
			case 'x' : cutText(); break;
			case 'p' : pasteText(); break;
			case 'r' : findAndReplace(); break;
			case 'f' : findString(); break;
			case 'o' : gui.MakeTable(textBuffer, bufferIndex_y); break;
			case 'q' : 
				system("clear"); 
				text.SetCursor_yPos(cursorPos_y);
				text.SetCursor_xPos(cursorPos_x);
				text.SetBuffer_yIndex(bufferIndex_y);
				text.SetBuffer_xIndex(bufferIndex_x);
				text.SetBoundary_yIndex(boundaryOfIndex_y);
				timer_mutx->unlock();
			return;
			
			
			default:  break;
			
		}
		
	}
	
}


void Editor::makeBox(int width, int height, int xPos, int yPos, std::string title)
{		
	int i;
	gotoxy(xPos,yPos);
	std::cout<<"┏";
	inputLine("━", width);
	std::cout<<"┓";
	for(i =1; i<=height; i++)
	{
		gotoxy(xPos,yPos+i);
		std::cout<< "┃";
		inputLine(" ", width);
		std::cout<< "┃";
	}
	gotoxy(xPos,yPos+i);
	std::cout<<"┗";
	inputLine("━", width);
	std::cout<<"┛";

	gotoxy(ORIGIN_POS_X+13, ORIGIN_POS_Y+5);
	std::cout <<title;
}


void Editor::writeText(Text &text)
{
	RefreshText(WHOLE_TEXT);


	if(textBuffer->empty())
		textBuffer->push_back("");
	
	
	gotoxy(cursorPos_x, cursorPos_y);
	
	while(1)
    {
		key = static_cast<char>(getch() );
		
        if(key[0] == '`') break; 
		
		else if(key[0] == ENTER) // 엔터  
			handlePressEnter(); 
		
		else if(key[0] == 27 ) // 방향키 입력 
			handleCursorMoving();		
			
		else if(key[0] == 127 || key[0] == 8) // 백스페이스 
			deleteCharacter(); 
        
		else if( key[0] & 0x80 ) // 입력한 문자가 한글인 경우
        	handleKorean();
        
		else if( key[0] != '`' )   // 영어를 입력한 경우
			handleEnglish();	
    }
	
	/*
	std::cout<< std::endl<< std::endl;
    for(auto &tmp: *textBuffer)
    	std::cout << tmp<< std::endl;
	*/
	
}

// 함수를 호출할떄 매개변수 size, line 값을 입력하지 않으면 디폴트 값으로 -1이 입력된다(editor.h 파일에 정의됨)
int Editor::countCharacter(int size, int line)
{
	int asciiCount = 0, koreanCount = 0;
	// 매개변수 값을 별도로 입력하지 않고 함수를 호출한 경우 현재 라인의 전체 문자 갯수를 카운트하여 리턴한다
	if(size == -1) size = (*textBuffer)[bufferIndex_y].size();
	if(line == -1) line = bufferIndex_y;
	
	for(int i =0; i< size; i++)
	{
		if( (*textBuffer)[line][i] & 0x80) koreanCount++;
		else asciiCount++;
	}
	return asciiCount + ((koreanCount/3)*2);
}

// 특정 텍스트의 전체 문자 갯수를 카운트할 수 있도록 다중 정의
int Editor::countCharacter(std::string &text)
{
	int asciiCount = 0, koreanCount = 0;
	
	for(int i =0; i< text.size(); i++)
	{
		if( text[i] & 0x80) koreanCount++;
		else asciiCount++;
	}
	return asciiCount + ((koreanCount/3)*2);
}


void Editor::deleteCharacter()
{
	if(markedBlockIndex_x != NONE_BLOCK) 
	{
		if( blockStartLine == blockEndLine)
			(*textBuffer)[blockStartLine].erase(blockStartIndex_x, blockEndIndex_x- blockStartIndex_x);		
		else
		{
			(*textBuffer)[blockStartLine].resize(blockStartIndex_x);
			(*textBuffer)[blockEndLine].erase(0, blockEndIndex_x);
			(*textBuffer)[blockStartLine] += (*textBuffer)[blockEndLine];
		}
		
		for (int i = blockStartLine; i < blockEndLine; i++)
			textBuffer->erase(textBuffer->begin()+blockStartLine+1);
		
		bufferIndex_x = blockStartIndex_x, bufferIndex_y = blockStartLine;
		correctionBufferIndex_x();
	
		markedBlockIndex_x = NONE_BLOCK, markedBlockIndex_y = NONE_BLOCK;
		RefreshText(WHOLE_TEXT);
	}
	// 벡스페이스를 눌렀을 때 bufferIndex_x(커서가) 해당 라인의 시작 위치에 있었을 경우
	else if(bufferIndex_x==0 && (bufferIndex_y-1 >=0))
	{
		// 바로 윗 라인에 저장된 텍스트 제일 끝으로 이동
		bufferIndex_y--;
		bufferIndex_x = (*textBuffer)[bufferIndex_y].size();

		// 이동 후 아래 라인 전체 텍스트를 윗 라인에 복사해서 붙이고 아래 라인을 삭제
		(*textBuffer)[bufferIndex_y] += (*textBuffer)[bufferIndex_y+1] ;
		textBuffer->erase(textBuffer->begin() + bufferIndex_y+1);

		// y값 이동에 따른 boundaryOfIndex_y값을 보정
		if(bufferIndex_y == boundaryOfIndex_y-1 && boundaryOfIndex_y-1 >=0 ) 
			boundaryOfIndex_y--;
			
		// 전체 텍스트를 갱신하여 WIDTH_LIMIT을 초과한 부분은 보정시킨다
		RefreshText(WHOLE_TEXT);
	}
	else
	{
		// bufferIndex_x 의 위치를 기준으로 바로 뒤칸에 저장된 문자가 한글일 경우
		if( (*textBuffer)[bufferIndex_y][bufferIndex_x-1] & 0x80)
		{
			if(bufferIndex_x-KOREAN_BYTE >= 0) 
			{
				bufferIndex_x -= KOREAN_BYTE;
				for(int j=0; j<KOREAN_BYTE; j++)        // bufferIndex_x 를 기준으로 3칸을 제거 
					(*textBuffer)[bufferIndex_y].replace(bufferIndex_x, 1,"");
			}
		}
		else // 영문일 경우
		{
			if(bufferIndex_x-1 >= 0)
			{	
				bufferIndex_x--;
				(*textBuffer)[bufferIndex_y].replace(bufferIndex_x ,1,"");
			}
		}
		RefreshText(CURRENT_LINE); 
	}
	cursorPos_y = ORIGIN_POS_Y + bufferIndex_y - boundaryOfIndex_y;
	cursorPos_x = ORIGIN_POS_X + countCharacter(bufferIndex_x);

	gotoxy(cursorPos_x,cursorPos_y);
}


void Editor::handlePressEnter()
{
	markedBlockIndex_x = NONE_BLOCK, markedBlockIndex_y = NONE_BLOCK;
	
	std::string temp;
	// 현재 타이핑중인 라인의 바로 아래 라인에 빈 라인을 만든다 
	textBuffer->insert(textBuffer->begin()+bufferIndex_y+1, temp);
	// 엔터를 입력한 커서(=버퍼인덱스 x) 위치를 기준으로 오른쪽에 위치한 텍스트를 아래 라인에 복사 
	(*textBuffer)[bufferIndex_y+1] = (*textBuffer)[bufferIndex_y].substr(bufferIndex_x);
	// 기존 라인에 잘라낸 부분을 없애주기 위해 버퍼 인덱스 x 크기만큼 리사이즈 
	(*textBuffer)[bufferIndex_y].resize(bufferIndex_x);

	bufferIndex_x = 0;
	bufferIndex_y++;
    
	cursorPos_x = ORIGIN_POS_X; 
	
	if(bufferIndex_y-boundaryOfIndex_y == HEIGHT_LIMIT) boundaryOfIndex_y++;
	cursorPos_y = ORIGIN_POS_Y + bufferIndex_y - boundaryOfIndex_y;
	
	RefreshText(WHOLE_TEXT);
	gotoxy(cursorPos_x, cursorPos_y);
}

// 한글 입력 처리 
void Editor::handleKorean()
{
	correctionBufferIndex_x();
	
	(*textBuffer)[bufferIndex_y].replace(bufferIndex_x, 0, key);
	key = static_cast<char>(getch() );
    (*textBuffer)[bufferIndex_y].replace(bufferIndex_x+1, 0, key);
	key = static_cast<char>(getch() );
    (*textBuffer)[bufferIndex_y].replace(bufferIndex_x+2, 0, key);

    bufferIndex_x += KOREAN_BYTE;
	cursorPos_x =  ORIGIN_POS_X+ countCharacter(bufferIndex_x);

	if(countCharacter() > WIDTH_LIMIT) 
		handleExceedWidthLimit();
	else RefreshText(CURRENT_LINE);
	
	gotoxy(cursorPos_x, cursorPos_y);
}

// 영문 입력 처리 
void Editor::handleEnglish()
{
	correctionBufferIndex_x();
	
	(*textBuffer)[bufferIndex_y].replace(bufferIndex_x, 0, key);
    bufferIndex_x++;
	cursorPos_x =  ORIGIN_POS_X+ countCharacter(bufferIndex_x);
	
	if(countCharacter() > WIDTH_LIMIT) 
		handleExceedWidthLimit();
	else RefreshText(CURRENT_LINE);
	gotoxy(cursorPos_x, cursorPos_y);
}

void Editor::correctionBufferIndex_x()
{
	if(bufferIndex_x > (*textBuffer)[bufferIndex_y].size())
	    bufferIndex_x = (*textBuffer)[bufferIndex_y].size();
	
	int koreanCount= 0;
	for(int i= bufferIndex_x-1; i>=0; i--)
		if((*textBuffer)[bufferIndex_y][i] & 0x80) koreanCount++;
	
	if(koreanCount %3 !=0) bufferIndex_x -= koreanCount%3;
	
}


void Editor::handleExceedWidthLimit()
{
	int endOfIndex_x = (*textBuffer)[bufferIndex_y].size()-1;
	
	if(bufferIndex_y+1 == textBuffer->size() )
		textBuffer->push_back("");
	
	if(bufferIndex_x >= endOfIndex_x)
	{
		if( (*textBuffer)[bufferIndex_y][endOfIndex_x] & 0x80)
			bufferIndex_x = 3;
		else bufferIndex_x = 1;
		
		bufferIndex_y++;
		cursorPos_x =  ORIGIN_POS_X+ countCharacter(bufferIndex_x);
		
		if(bufferIndex_y-boundaryOfIndex_y == HEIGHT_LIMIT) boundaryOfIndex_y++;	
		cursorPos_y = ORIGIN_POS_Y + bufferIndex_y - boundaryOfIndex_y;
	}
	else
	{
		std::string temp;
		temp = static_cast<char> ( (*textBuffer)[bufferIndex_y][endOfIndex_x] );
		(*textBuffer)[bufferIndex_y+1].replace(0,0, temp);
		
		
		if((*textBuffer)[bufferIndex_y+1][0] & 0x80)
		{
			for(int i=1; i<3; i++)
			{
				temp = static_cast<char> ( (*textBuffer)[bufferIndex_y][endOfIndex_x-i] );
				(*textBuffer)[bufferIndex_y+1].replace(0,0, temp);
			}
			(*textBuffer)[bufferIndex_y].resize(endOfIndex_x-2);
		}
		else (*textBuffer)[bufferIndex_y].resize(endOfIndex_x);
	
	}
		
	RefreshText(WHOLE_TEXT);
	
}


void Editor::handleCursorMoving()
{
	checkCtrlKey = getch();
	key = static_cast<char>(getch() );
	
	if(checkCtrlKey == PRESSED_CTRL && markedBlockIndex_x == NONE_BLOCK )
		markedBlockIndex_x = bufferIndex_x, markedBlockIndex_y = bufferIndex_y;
	else if( checkCtrlKey != PRESSED_CTRL)
	{
		markedBlockIndex_x = NONE_BLOCK, markedBlockIndex_y = NONE_BLOCK;
		RefreshText(WHOLE_TEXT);
	}
	
	switch(key[0])
	{
		case LEFT:
			if( (*textBuffer)[bufferIndex_y][bufferIndex_x-1] & 0x80) // 바로 뒤 문자가 한글인지 검사	
				bufferIndex_x-= KOREAN_BYTE;
		    else 
				bufferIndex_x--;
			
			if(bufferIndex_x < 0 && bufferIndex_y-1 >=0) 
			{
				bufferIndex_y--;
				if(bufferIndex_y == boundaryOfIndex_y-1 && boundaryOfIndex_y-1 >=0 ) 
				{
					boundaryOfIndex_y--;
					RefreshText(WHOLE_TEXT);
				}
				bufferIndex_x = (*textBuffer)[bufferIndex_y].size();
			}
			else if( bufferIndex_x <0 ) bufferIndex_x = 0;
			
			break;
		case RIGHT:
			if( (*textBuffer)[bufferIndex_y][bufferIndex_x] & 0x80) // 현위치 문자가 한글인지 검사	
				bufferIndex_x+=KOREAN_BYTE;
		    else 
				bufferIndex_x++;
			
			if(bufferIndex_x >= (*textBuffer)[bufferIndex_y].size() &&
				bufferIndex_y+1 < textBuffer->size() ) 
			{
				bufferIndex_y++;
				if(bufferIndex_y - boundaryOfIndex_y >= HEIGHT_LIMIT) 
				{
					boundaryOfIndex_y++;
					RefreshText(WHOLE_TEXT);
				} 
				bufferIndex_x = 0;
			}
			else if( bufferIndex_x >= (*textBuffer)[bufferIndex_y].size() )
				bufferIndex_x = (*textBuffer)[bufferIndex_y].size();

			break;
		case UP: 
			if(bufferIndex_y-1 >= 0 ) 
			{
				// 위쪽라인으로 이동
				bufferIndex_y--;
				// countCharacter 함수에 bufferIndex_x 값, 이동 전 라인을 가리키는 bufferIndex_y+1 값을 인자로 넘기면
				// 이동 전 라인에서 bufferIndex_x 값을 기준으로 한글과 영문이 총 몇글자인지 리턴받게 된다
				// getIndex_xByNumOfChar 함수는 해당 글자 수 만큼 현재(이동한) 라인에서 동일한 글자수에 해당하는 bufferIndex_x
				// 값을 리턴한다
				
				int numOfPrevLineChar = countCharacter(bufferIndex_x, bufferIndex_y+1);
				
				bufferIndex_x = getIndex_xByNumOfChar(numOfPrevLineChar, bufferIndex_y);
				
				if(bufferIndex_y == boundaryOfIndex_y-1 && boundaryOfIndex_y-1 >=0 ) 
				{
					boundaryOfIndex_y--;
					RefreshText(WHOLE_TEXT);
				}
			}
			break;
		case DOWN :
			if(bufferIndex_y+1 < textBuffer->size() ) 
			{
				bufferIndex_y++;
				// 커서가 아래쪽 라인으로 이동했을 떄 bufferIndex_x값을 보정
				int numOfPrevLineChar = countCharacter(bufferIndex_x, bufferIndex_y-1);
				
				bufferIndex_x = getIndex_xByNumOfChar(numOfPrevLineChar, bufferIndex_y);
				
				if(bufferIndex_y - boundaryOfIndex_y >= HEIGHT_LIMIT) 
				{
					boundaryOfIndex_y++;
					RefreshText(WHOLE_TEXT);
				} 
			}
			break;
			
		
	}
	
	if(markedBlockIndex_x != NONE_BLOCK) 
		RefreshText(WHOLE_TEXT);
	
	cursorPos_y = ORIGIN_POS_Y + bufferIndex_y - boundaryOfIndex_y;
	cursorPos_x = ORIGIN_POS_X + countCharacter(bufferIndex_x);
	gotoxy(cursorPos_x, cursorPos_y);

}

// line의 위치에서 numOfCharacter(문자수)에 해당하는 bufferIndex_x값을 반환
int Editor::getIndex_xByNumOfChar(int numOfCharacter, int line)
{
	int i = 0,  asciiCount = 0, koreanCount = 0, numOfCurrLineChar;
	
	for(i = 0; i< (*textBuffer)[line].size(); i++)
	{
		numOfCurrLineChar = asciiCount + ((koreanCount/3)*2);
		if(numOfCharacter <= numOfCurrLineChar) 
		{
			if(numOfCharacter < numOfCurrLineChar) i -= 3;
			break;
		}
		if( (*textBuffer)[line][i] & 0x80) koreanCount++;
		else asciiCount++;
	}
	return i;
}


void Editor::RefreshText(int mode)
{
	if(mode == WHOLE_TEXT || mode == PASTE_MODE ) // mode 가 0이 아니면 화면상에 텍스트가 들어가는 영역 전체를 갱신 
	{
		int numOfTexts = textBuffer->size()-1, tempIndex_x;
		
		// 전체 라인을 검사하여 문자수가 width_limit을 초과하는 라인은 width_line에 맞게 조절한다.
		for(int line= 0; line <= numOfTexts; line++)
		{
			if( countCharacter((*textBuffer)[line].size(), line) > WIDTH_LIMIT)
			{
				if( line == numOfTexts) 
				{
					textBuffer->push_back("");
					numOfTexts++;
				}
				tempIndex_x = getIndex_xByNumOfChar(WIDTH_LIMIT, line);
				(*textBuffer)[line+1].replace(0,0, (*textBuffer)[line].substr(tempIndex_x) );
				(*textBuffer)[line].resize(tempIndex_x);
				
				if( (bufferIndex_x > tempIndex_x)  && (mode == PASTE_MODE) )
				{
					bufferIndex_y++;
					if(bufferIndex_y - boundaryOfIndex_y >= HEIGHT_LIMIT) 
						boundaryOfIndex_y++;
					
					bufferIndex_x = bufferIndex_x-tempIndex_x;
				}
			}
		}
		
		int tempIndex_y;
		
		for(int i = ORIGIN_POS_Y; i< ORIGIN_POS_Y+HEIGHT_LIMIT; i++)
		{
			tempIndex_y =i+boundaryOfIndex_y-ORIGIN_POS_Y;
			gotoxy(ORIGIN_POS_X-6, i);
			std::cout << "   ";
			gotoxy(ORIGIN_POS_X, i);
			inputLine(" ", WIDTH_LIMIT+1);
			
			if(tempIndex_y <= numOfTexts) 
			{
				gotoxy(ORIGIN_POS_X-6, i);
				std::cout.setf(std::ios::left);
				std::cout << tempIndex_y+1;
				gotoxy(ORIGIN_POS_X, i);
				std::cout << (*textBuffer)[ tempIndex_y ];
				
				if(markedBlockIndex_x != NONE_BLOCK) 
					blockText(tempIndex_y, i);
			}
		}
	}
	else // 타이핑 하고 있는 라인을 갱신
	{ 
	    gotoxy(ORIGIN_POS_X, cursorPos_y);
		inputLine(" ", WIDTH_LIMIT+1);
		gotoxy(ORIGIN_POS_X, cursorPos_y);
		std::cout << (*textBuffer)[bufferIndex_y];
		gotoxy(cursorPos_x, cursorPos_y);
	}
	
	
}


void Editor::findAndReplace()
{
	std::string toFind;
	std::string toReplace;
	int replaceCount = 0;
	
	RefreshText(WHOLE_TEXT);
	makeBox(WIDTH_LIMIT-10, 4, ORIGIN_POS_X+3, ORIGIN_POS_Y+4, " [ 찾아서 바꾸기 ] ");
	
	
	
	for (int i =0; i<2; i++)
	{
		gotoxy(ORIGIN_POS_X+12, ORIGIN_POS_Y+6+i);
		if( i==0)
		{
			std::cout << " 찾을 문자열 : ";
			getline(std::cin, toFind);
		}
		else
		{		
			std::cout <<" 바꿀 문자열 : ";
			getline(std::cin, toReplace);
		}
	}
	if(toFind.empty() || toReplace.empty()) return;
	
	// 종화 코드 
	size_t first = 0;   // string 처음부터 검사
	for(int i=0; i< textBuffer->size(); i++)
	{
		while((first = (*textBuffer)[i].find(toFind, first)) != std::string::npos)
		{
			(*textBuffer)[i].replace(first, toFind.length(),toReplace);		//바꿀 시작 인덱스, 인덱스 길이, 바꿀 문자 
			first += toReplace.length();	//시작 위치를 문자를 바꾼 후부터 진행되도록 더함 
			replaceCount++;
		}
		first=0;
	}
	
	std::string comment("[ 바뀐 문자열 수 : " + std::to_string(replaceCount) + " ]");
	makeBox(WIDTH_LIMIT-10, 4, ORIGIN_POS_X+3, ORIGIN_POS_Y+4, comment);	
	
	getchar();
	RefreshText(WHOLE_TEXT);
}

void Editor::findString()
{
	std::string toFind; // 검색할 문자열
	int cnt(0);
	
	int r_cnt(0); // 몇 개가 검색 되었는지?

	RefreshText(WHOLE_TEXT);
	makeBox(WIDTH_LIMIT-10, 4, ORIGIN_POS_X+3, ORIGIN_POS_Y+4, " [ 찾기 ] ");
	
	gotoxy(ORIGIN_POS_X+12, ORIGIN_POS_Y+6);
	std::cout << " 찾을 문자열 : ";
	getline(std::cin, toFind);
	
	
	std::string::size_type f_idx = bufferIndex_x;
	
	for(int i= bufferIndex_y; i<textBuffer->size(); i++)
	{
		if(i == bufferIndex_y )
		{
			f_idx = (*textBuffer)[i].find(toFind, f_idx);
			if(bufferIndex_x == f_idx )
			{
				f_idx+= toFind.size(), i--;
				continue;
			}
		}
		else f_idx = (*textBuffer)[i].find(toFind, 0);
		
		if( f_idx != std::string::npos)
		{
			bufferIndex_x = f_idx;
			bufferIndex_y = i;
			break;
		}

	}

	RefreshText(WHOLE_TEXT);
	cursorPos_y = ORIGIN_POS_Y + bufferIndex_y - boundaryOfIndex_y;
	cursorPos_x =  ORIGIN_POS_X+ countCharacter(bufferIndex_x);
	gotoxy(cursorPos_x, cursorPos_y);
	
}


void Editor::cutText()
{
	copyText();
	deleteCharacter();
}
void Editor::copyText()
{
	textToCopy.clear();

	if( blockStartLine == blockEndLine)
	{
		textToCopy += (*textBuffer)[blockStartLine].substr(blockStartIndex_x, blockEndIndex_x - blockStartIndex_x);
		return;
	}
	
	for (int i = blockStartLine; i <= blockEndLine; i++)
	{
		if( i == blockStartLine)
			textToCopy = (*textBuffer)[i].substr(blockStartIndex_x);
		else if (i == blockEndLine)
			textToCopy += (*textBuffer)[i].substr(0, blockEndIndex_x);
		else
			textToCopy += (*textBuffer)[i];
	}
	RefreshText(WHOLE_TEXT);
}

void Editor::pasteText()
{		
	(*textBuffer)[bufferIndex_y].replace(bufferIndex_x, 0, textToCopy);
	
	bufferIndex_x += textToCopy.size();
	
	// PASTE_MODE로 텍스트를 갱신하면 붙여넣기 한 만큼 WIDTH_LIMIT에 맞게 텍스트를 보정하고 
	// bufferIndex_x 값과 bufferIndex_y값을 이동 시킨다
	RefreshText(PASTE_MODE);
	
	// 이동된 bufferIndex_x 값을 텍스트의 range를 초과하지 않도록 보정시킨다
	correctionBufferIndex_x();
	
	// 보정된 bufferIndex_x, y값을 기준으로 커서를 이동시킨다
	cursorPos_y = ORIGIN_POS_Y + bufferIndex_y - boundaryOfIndex_y;
	cursorPos_x = ORIGIN_POS_X + countCharacter(bufferIndex_x);
}

// RefreshText 함수로부터 텍스트를 갱신하면서 블록처리 해야할 부분인지를 검사하고 블록 처리한 텍스트로 화면에 재출력한다
void Editor::blockText(int currentLine, int currentPos_y)
{
	blockStartLine = markedBlockIndex_y;
	blockEndLine = bufferIndex_y;
	blockStartIndex_x = markedBlockIndex_x; 
	blockEndIndex_x = bufferIndex_x;
			
	if( blockStartLine > blockEndLine)
	{
		std::swap(blockStartLine, blockEndLine);
		std::swap(blockStartIndex_x, blockEndIndex_x);
	}
	else if( (blockStartLine == blockEndLine) && (blockStartIndex_x > blockEndIndex_x) )  // 블록 시작 라인과 끝 라인이 동일한 경우
		std::swap(blockStartIndex_x, blockEndIndex_x);
	
	
	// 블록 시작과 끝 범위를 벗아난 라인 인 경우 아래 코드는 거치지 않고 즉시 되돌아 간다
	if( currentLine <blockStartLine || currentLine > blockEndLine) return;
	
	BGRAY
	BLACK
	
	int xPos;
	
	if ( currentLine == blockStartLine) 
		xPos = ORIGIN_POS_X + countCharacter(blockStartIndex_x, currentLine);
	else
		xPos = ORIGIN_POS_X;	
	gotoxy(xPos, currentPos_y);

	if( (currentLine == blockStartLine) && (currentLine== blockEndLine) )	
		std::cout<<(*textBuffer)[currentLine].substr(blockStartIndex_x, blockEndIndex_x-blockStartIndex_x);
	
	else if( currentLine == blockStartLine)
		std::cout<<(*textBuffer)[currentLine].substr(blockStartIndex_x);
	
	else if( currentLine == blockEndLine)
		std::cout<<(*textBuffer)[currentLine].substr(0, blockEndIndex_x);
	
	else if( (currentLine > blockStartLine ) && (currentLine < blockEndLine) )
		std::cout<<(*textBuffer)[currentLine];
	DEF
}


/*
void Editor::ReadText()
{
	
	std::ifstream rfile("test.txt");
	int row = 0;
	
	while(getline(rfile, textBuffer[row]))
	{
		row++;
	}
	
	for(int i =0; i<MAX_SIZE; i++)
	{
		if(countCharacterV2(i) > WIDTH_LIMIT)
		{
			
			std::string temp;
	
			// 현재 타이핑중인 라인의 바로 아래 라인에 빈 라인을 만든다 
			for(int j = i+1; j < MAX_SIZE; j++)
				swap(textBuffer[j], temp);
			
			// 엔터를 입력한 커서 위치를 기준으로 오른쪽에 위치한 텍스트를 아래 라인에 복사 
			textBuffer[i+1] = textBuffer[i].substr(WIDTH_LIMIT);
			// 기존 라인에 잘라낸 부분을 없애주기 위해 버퍼 인덱스 x 크기만큼 리사이즈 
			 textBuffer[i].resize(WIDTH_LIMIT);
		}
	}
	RefreshText(1);
}

int Editor::countCharacterV2(int row)
{
	int asciiCount = 0;
	int koreanCount = 0;
	
	for(int i =0; i< textBuffer[row].size(); i++)
	{
		if(textBuffer[row][i] & 0x80) koreanCount++;
		else asciiCount++;
	}
	
	return asciiCount + ((koreanCount/3)*2);
}
*/

/*
void Editor::gotoxy(int x, int y)
{
	printf("\033[%d;%df",y,x);

	fflush(stdout);
}

int Editor::getch()					// 키보드 이동키 함수
{
	int ch;
	struct termios buf;
	struct termios save;

	tcgetattr(0,&save);
	buf=save;
	buf.c_lflag&=~(ICANON|ECHO);
	buf.c_cc[VMIN]=1;
	buf.c_cc[VTIME]=0;
	tcsetattr(0,TCSAFLUSH,&buf);
	ch=getchar();
	tcsetattr(0,TCSAFLUSH,&save);

    return ch;
}

void Editor::inputLine(std::string str, int num)
{
    for(int i =0; i<num; i++)
        std::cout << str;
}
*/
