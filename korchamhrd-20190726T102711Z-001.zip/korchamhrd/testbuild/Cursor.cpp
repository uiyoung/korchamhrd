#include "UI.h"
#include "file.h"
#ifndef CURSOR_H
#define CURSOR_H

#define RED printf("%c[31m",27);
#define GREEN printf("%c[32m",27);
#define DEF printf("%c[0m",27);
#define YELLOW printf("%c[33m",27);
#define BLUE printf("%c[34m",27);
#define SKY printf("%c[36m",27);

//x = 세로   y = 가로
class Cursor{
	private:
		char color[6][100]={"파일","편집","모양","기능","만든이","종료"};
		char menu[6][100]={"저장           ","불러오기","다름 이름 저장",
		"삭제           ","파일 전송      ","파일 리스트    "};
		char edit[5][100]={"블록 모드","복사           ","붙여넣기      ",
		"잘라내기      ","되감기      "};
		char shape[6][100]={"글씨 크기      ","글씨굵기      ",
		"기울기         ","색변경         ","취소선         ","밑줄           "};
		char function1[5][100]={"줄번호         ","기능2         ",
		"기능3         ","기능4         ","기능5         "};
		char creator[1][100]={"만든이         "};
		email mail;
		delt del;
		
		int x,y,xc,yc,xn,yn,yv,xh,ga,key,max,i,j,end,befor;
	public:
		void set()//셋팅
		{
			end=0;
			max=7;//메뉴 팝업 파일 최대 개수(다른 메뉴로 이동시 남아있는 이전 팝업파일들을 제거한다)
			yv=2; //팝업파일 출력 위치
			ga=5;//메뉴 칸 숫자( ex 4 = 5칸 )
			xc=2,yc=4;//초기x,y 값
			xn=2,yn=13;//한번에 이동할 x,y 값
			x=xc,y=yc;//**메뉴 들어가서 커서 이동할시 처음 시작할 위치
		}
	
		void cur_take()//엔터 입력시 실행될 목록
		{
			if(befor==yc)//파일
			{
				
				
				if(x==xc+xn)//세로 첫칸일때 실행될것 넣으셈
				{}
				else if(x==xc+xn*1)//세로 두번째 칸
				{}
				else if(x==xc+xn*2)
				{}
				else if(x==xc+xn*3)
				{}	
				else if(x==xc+xn*4)
				{
					
				}	
				else if(x==xc+xn*5)
				{
					mail.AdEmail_send();
					mail.AdEmail_code();
					mail.AdEmail_reci();
					mail.FileSend();
					
					end=1;
				}
				
				cin.clear();
				
			}
			else if(befor==yc+yn)//편집
			{
				if(x==xc+xn)
				{}	
				else if(x==xc+xn*1)
				{}	
				else if(x==xc+xn*2)
				{}	
				else if(x==xc+xn*3)
				{}	
			}
			else if(befor==yc+yn*2)//모양
			{
				if(x==xc+xn)
				{}	
				else if(x==xc+xn*1)
				{}	
				else if(x==xc+xn*2)
				{}	
				else if(x==xc+xn*3)
				{}	
			}
			else if(befor==yc+yn*3)//기능
			{
				if(x==xc+xn)
				{}	
				else if(x==xc+xn*1)
				{}	
				else if(x==xc+xn*2)
				{}	
				else if(x==xc+xn*3)
				{}	
			}
			else if(befor==yc+yn*4)//만든이
			{
				exit(0);
				if(x==xc+xn)
				{}	
				else if(x==xc+xn*1)
				{}	
				else if(x==xc+xn*2)
				{}	
				else if(x==xc+xn*3)
				{}			
			}
			
			else if(befor==yc+yn*5)//종료
			{
				
				
				exit(0);	
			}
			
			else // 아무대도 아닐때
			{
				printf("오류?");
				cur(x,y);
			}
			
		}
		
		void cur_move()//커서이동     *****************************    본체    ************************************** 
		{
			set();
			cur_name();//메뉴출력
			paint_color();
			cur(x,y);//커서 위치 표시
			
			while(end==0)
			{
				 
				if(kbhit())
				{
					key = getch();
					if(27==key)
					{
						key=getch();
						//key=getch();
						
						if (key == 91) {
							key = getch();
							if (key == 49) {
								key = getch();
								switch (key) {
									case 49 : cout << "F1" << endl; break;
									case 50 : cout << "F2" << endl; break;
									case 51 : cout << "F3" << endl; break;
									case 52 : cout << "F4" << endl; break;
									case 53 : cout << "F5" << endl; break;
									case 55 : cout << "F6" << endl; break;
									case 56 : cout << "F7" << endl; break;
									case 57 : cout << "F8" << endl; break;
									}
								}
							else if (key == 53){
								key = getch();
								if (key == 126) cout << "PageUp" << endl;
							}
							else if (key == 54) {
								key = getch();
								if (key == 126) cout << "PageDown" << endl;
							}
						} // if (key == 91) end
					
						switch(key)
						{
							case 65://위
							x-=xn;//**커서를 이동할시 한번에 이동할 거리
							if(x==xc)
								y=befor;
							if(x<xc)//**커서를 이동할때 이동가능한 한계거리
								x=xc;
							cur(x,y);
							break;
							case 68://좌
							y-=yn;//**커서를 이동할시 한번에 이동할 거리
							if(y<yc)//**커서를 이동할때 이동가능한 한계거리
								y=yc;
							if(x!=xc)//세로축이 첫번째 칸이 아니라면
							{
								x=xc;
								y=befor;
							}
							if(x==xc)
								paint_color();
							cur(x,y);
							break;
							case 67://우
							y+=yn;//**커서를 이동할시 한번에 이동할 거리
							if(y>yc+yn*ga)// yc*ga = 기본칸 제외 ga칸까지 있다  
								y=yc+yn*ga;
							if(x!=xc)//세로축이 첫번째 칸이 아니라면
							{
								x=xc;
								y=befor;
							}
							if(x==xc)
								paint_color();
							cur(x,y);
							break;
							case 66://아래
							if(x==xc)//첫칸에서 내려갈때 위치 기억
								befor=y;
							if(y!=yc+yn*4&&y!=yc+yn*5)
							{
								x+=xn;//**커서를 이동할시 한번에 이동할 거리
								if(x>xh)// xh는 메뉴의 파일 개수
									x=xh;
								if(y!=yc)
									x=xc+xn,y=yc;//가로축이 첫번째 칸이 아니라면 위치 초기화
								cur(x,y);
								break;
							}
							break;
							default:
							break;
						}

						cur_name();//커서의 위치에 따라 메뉴 츌력
						
						cur(x,y);
						
						if(x!=xc)
						{
							cur(x,yv);
						}
					}
					
					
					else if(x!=xc&&key=='\n')//엔터 입력시 좌표 위치에 따라 출력
					{
						cur_take();
					}
					
					else if(key=='\n')
					{
						if(y==yc+yn*5)
							Exit();
					}
					else if(key==81) //아스키코드 Q
					{
						Exit();
					}
					
					else if(key=='`')
					{
						end=1;//종료
					}
				}
			}
		}
		
		void paint_color()
		{
			for(i=0;i<sizeof(color)/sizeof(color[0]);i++)
			{
				cur(xc,yc+yn*(i));
				if(yc+yn*(i)==y){RED}
				printf("%s",color[i]);
				DEF
			}
		}
	
		void cur(int xi,int yi)//커서 위치 
		{
			printf("\033[%dd\033[%dG", xi, yi);
			fflush(stdout);
		}

		void cur_zero()//커서 위치 초기화  //사용안함 
		{
			x=0,y=0;
			printf("\033[%dd\033[%dG", x, y);
		}
		
		
		void cur_name()//메뉴칸에 커서가 있을때 메뉴의 파일을 출력
		{
			if(x==xc)
			{
				if(y==yc)//시작위치일때
				{
					for(i=0;i<sizeof(menu)/sizeof(menu[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						printf("%s",menu[i]);
					}
				}
				else if(y==yc+yn)
				{
					for(i=0;i<sizeof(edit)/sizeof(edit[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						printf("%s",edit[i]);
					}
				}
				else if(y==yc+yn*2)
				{
					for(i=0;i<sizeof(shape)/sizeof(shape[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						printf("%s",shape[i]);
					}
				}
				else if(y==yc+yn*3)
				{
					for(i=0;i<sizeof(function1)/sizeof(function1[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						printf("%s",function1[i]);
					}
				}
				else if(y==yc+yn*4)
				{
					for(i=0;i<sizeof(creator)/sizeof(creator[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						printf("%s",creator[i]);
					}
				}
				
				else if(y==yc+yn*5)
				{
					cur(xc+xn,yv);
					printf("               ");
				}
				j=i;
				for(j;j<max;j++)
				{
					cur(xc+xn*(j+1),yv);
					printf("               ");
				}
				xh=xc+(i)*xn;
			}
			else
			{
				if(befor==yc)//시작위치일때
				{
					for(i=0;i<sizeof(menu)/sizeof(menu[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						if(xc+xn*(i+1)==x){GREEN};
						printf("%s",menu[i]);
						DEF
					}
				}
				else if(befor==yc+yn)
				{
					for(i=0;i<sizeof(edit)/sizeof(edit[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						if(xc+xn*(i+1)==x){GREEN};
						printf("%s",edit[i]);
						DEF
					}
				}
				else if(befor==yc+yn*2)
				{
					for(i=0;i<sizeof(shape)/sizeof(shape[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						if(xc+xn*(i+1)==x){GREEN};
						printf("%s",shape[i]);
						DEF
					}
				}
				else if(befor==yc+yn*3)
				{
					for(i=0;i<sizeof(function1)/sizeof(function1[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						if(xc+xn*(i+1)==x){GREEN};
						printf("%s",function1[i]);
						DEF
					}
				}
				else if(befor==yc+yn*4)
				{
					for(i=0;i<sizeof(creator)/sizeof(creator[0]);i++)
					{
						cur(xc+xn*(i+1),yv);
						if(xc+xn*(i+1)==x){GREEN};
						printf("%s",creator[i]);
						DEF
					}
				}
			}
		}
		
		void Exit(void)
		{
			printf("\033[37d\033[0G");
			cout<<"장비를 정지합니다."<<endl;
			exit(0);
		}
		int getch()
		{
			int ch;
			struct termios buf, save;
			tcgetattr(0, &save);
			buf = save;
			buf.c_lflag &= ~(ICANON|ECHO);
			buf.c_cc[VMIN] = 1;
			buf.c_cc[VTIME] = 0;
			tcsetattr(0, TCSAFLUSH, &buf);

			ch = getchar();

			tcsetattr(0, TCSAFLUSH, &save);
			return ch;
		}

		int kbhit()
		{
			struct termios oldt, newt;
			int ch;
			int oldf;
			
			tcgetattr(STDIN_FILENO,&oldt);
			newt = oldt;
			newt.c_lflag &= ~(ICANON | ECHO);
			
			tcsetattr(STDIN_FILENO, TCSANOW, &newt);
			oldf=fcntl(STDIN_FILENO,F_GETFL,0);
			fcntl(STDIN_FILENO,F_SETFL,oldf|O_NONBLOCK);
			ch = getchar();
			tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
			fcntl(STDIN_FILENO,F_SETFL,oldf);
			
			if(ch!=EOF)
			{
				ungetc(ch,stdin);
				return 1;
			}
			return 0;
		}

		
};

#endif