//
// Created by iotpc on 2019-07-20.
//

#ifndef FILE_H
#define FILE_H

#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <fstream>

using namespace std;

class email {
public:
    void FileSend(void);
    void AdEmail_send(void);
    void AdEmail_reci(void);
    void AdEmail_code(void);
};

class delt {
public:
    void FileDel(const char name[20]);
    void NameInput(const char name[20]);
private:
    char name_commend[80] = "rm /home/iot201901/memopjt/testbuild/";
};
/*
class save{
public:
    void save_mod(void);
};*/
#endif //IOTEAM_FILE_H
