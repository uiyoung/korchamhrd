﻿//Menu.cpp
#include "UI.h"
#ifndef MENU_H
#define MENU_H
//#define X 4 //x좌표 초깃값
//#define I 13 //간격

class Menu{
private:
	
public:
	void PrintMenu()
	{
		Gotoxy xy;
		for(int i=0;i<6;i++)
		{
			xy.Setxy(4+(13*i),2);
			if(i==0) cout<<"파일"<<endl;
			else if(i==1) cout<<"편집          "<<endl;
			else if(i==2) cout<<"모양"<<endl;
			else if(i==3) cout<<"기능"<<endl;
			else if(i==4) cout<<"만든이"<<endl;
			else if(i==5) cout<<"종료"<<endl;
		}
	}
};
#endif
