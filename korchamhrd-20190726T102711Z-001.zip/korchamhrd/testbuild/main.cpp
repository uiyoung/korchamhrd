//main_UI.cpp
#include "UI.h"
#include "editor.h"
#include "text.h"
#include "Timer.cpp"

#include "file.h"

void SaveText(std::vector <std::string> *text)
{
	ofstream wfile("test.txt");
	
	for(auto &line : *text)
		wfile << line<< "\n";
	
	wfile.close();
}

int main() 
{
	Notepad notePad;
	Menu menu;
	Timer timer;
	Cursor cursor;
	Text text;
	
	Editor editor(text.GetText(), timer.GetMutex() );
	thread t(&Timer::Print, &timer);
	
	while(1)
	{
		notePad.PrintNotepad();
		menu.PrintMenu();
		editor.RefreshText(WHOLE_TEXT);
		timer.SetMode(2);
		cursor.cur_move();
		timer.SetMode(1);
		editor.ModeSelect(text);
		SaveText(text.GetText() );
	}	
	
	t.join();
	
	return 0;
}


