// Waitingkey.cpp
#include "UI.h"
#ifndef WAITINGKEY_H
#define WAITINGKEY_H
#include "Getkey.cpp"

class inputWait{
private:
    int key;
    Getkey getkey;
public :
    void inputKey() {

        while (1) {
            if (getkey.kbhit()) {
                key = getkey.getch();

                if (key == 27) {
                    key = getkey.getch();
                    switch (key) {
                        case 49 : cout << "Alt + 1" << endl; break;
                        case 50 : cout << "Alt + 2" << endl; break;
                        case 51 : cout << "Alt + 3" << endl; break;
                        case 52 : cout << "Alt + 4" << endl; break;
                        case 53 : cout << "Alt + 5" << endl; break;
                        case 54 : cout << "Alt + 6" << endl; break;
                        case 55 : cout << "Alt + 7" << endl; break;
                        case 56 : cout << "Alt + 8" << endl; break;
                        case 57 : cout << "Alt + 9" << endl; break;
                    }

                    if (key == 91) {
                        key = getkey.getch();
                        if (key == 49) {
                            key = getkey.getch();
                            switch (key) {
                                case 49 : cout << "F1" << endl; break;
                                case 50 : cout << "F2" << endl; break;
                                case 51 : cout << "F3" << endl; break;
                                case 52 : cout << "F4" << endl; break;
                                case 53 : cout << "F5" << endl; break;
                                case 55 : cout << "F6" << endl; break;
                                case 56 : cout << "F7" << endl; break;
                                case 57 : cout << "F8" << endl; break;
                                }
                            }
                        else if (key == 53){
                            key = getkey.getch();
                            if (key == 126) cout << "PageUp" << endl;
                        }
                        else if (key == 54) {
                            key = getkey.getch();
                            if (key == 126) cout << "PageDown" << endl;
                        }
                    } // if (key == 91) end
                } // if (key == 27) end
            } // if (getkey.kbhit()) end
        } // while (1) end
    } // void inputKey() end
};
#endif