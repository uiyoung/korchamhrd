#ifndef EDITOR_H
#define EDITOR_H

#include <mutex>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include <termios.h>
#include <string>
#include <fstream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include "public_functions.h"
#include "text.h"
#include "Timer.cpp"
#include "gui.h"


#define KOREAN_BYTE 3 

#define UP 65
#define DOWN 66
#define LEFT 68
#define RIGHT 67
#define ENTER 10

#define CURRENT_LINE 0
#define WHOLE_TEXT 1
#define PASTE_MODE 2

#define PRESSED_CTRL 79
#define NONE_BLOCK -1

#define BGRAY printf("\x1b[47m");//하늘
#define BLACK printf("\x1b[30m"); //검정
//#define DEF printf("\x1b[0m");   //원래 
/*
#define ORIGIN_POS_X 19	// 커서의 X좌표 원점 
#define ORIGIN_POS_Y 4 // 커서의 Y좌표 원점 
#define WIDTH_LIMIT 50	// UI에서 출력 가능한 문자 한도 수 
#define HEIGHT_LIMIT 29	// UI에서 출력 가능한 라인 한도 수 
*/


using namespace publicfunctions;

class Editor{
	private:
		std::vector <std::string> *textBuffer;
		std::vector <std::string> modeList;
		std::string key;
		std::string textToCopy;
		std::mutex *timer_mutx;
		
		// 커서와 버퍼 인덱스 관련 변수들
		int cursorPos_y;
		int cursorPos_x;
		int bufferIndex_y;
		int bufferIndex_x;
		int boundaryOfIndex_y;
		
		// 블록처리 관련 변수들
		int markedBlockIndex_x;
		int markedBlockIndex_y;
		
		int blockStartLine;
		int blockEndLine;
		int blockStartIndex_x;
		int blockEndIndex_x;
		
		char checkCtrlKey;
		Gui gui;
		
		// private 함수들
		int countCharacter(int size=-1, int line=-1);
		int countCharacter(std::string &text);
		void handlePressEnter();
		void deleteCharacter();
		void handleKorean();
		void handleEnglish();
		void correctionBufferIndex_x();
		void handleExceedWidthLimit();
		void handleCursorMoving();
		int getIndex_xByNumOfChar(int numOfCharacter, int line);	
		void makeBox(int width, int height, int xPos, int yPos, std::string title);
		void writeText(Text &text);
		void findAndReplace();
		void copyText();
		void cutText();
		void pasteText();
		void blockText(int currentLine, int currentPos_y);
		void findString();
		//void ReadText();
		//int CountCharacterV2(int row);
	
	public:
		Editor(std::vector <std::string> *textBuffer, std::mutex *mutx);
		~Editor();
		void RefreshText(int mode);
		void ModeSelect(Text &text);
};

#endif