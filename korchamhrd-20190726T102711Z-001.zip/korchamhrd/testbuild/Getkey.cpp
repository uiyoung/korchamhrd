// Getkey.cpp
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

class Getkey{
public :

    int getch(void)					// 키보드 이동키 함수
    {
        int ch;
        struct termios buf;
        struct termios save;

        tcgetattr(0,&save);
        buf=save;
        buf.c_lflag&=~(ICANON|ECHO);
        buf.c_cc[VMIN]=1;
        buf.c_cc[VTIME]=0;
        tcsetattr(0,TCSAFLUSH,&buf);
        ch=getchar();
        tcsetattr(0,TCSAFLUSH,&save);

        return ch;
    }

    int kbhit(void) // 키보드를 눌렀는지 확인
    {
        struct termios oldt, newt;
        int ch;
        int oldf;

        tcgetattr(STDIN_FILENO, &oldt);
        newt = oldt;
        newt.c_lflag &= ~(ICANON | ECHO);
        tcsetattr(STDIN_FILENO, TCSANOW, &newt);
        oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
        fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

        ch = getchar();

        tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
        fcntl(STDIN_FILENO, F_SETFL, oldf);

        if(ch != EOF)
        {
            ungetc(ch, stdin);
            return 1;
        }
    }

};
