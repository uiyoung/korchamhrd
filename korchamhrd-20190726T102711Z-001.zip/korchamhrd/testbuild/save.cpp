//
// Created by iotpc on 2019-07-24.
//
#include "file.h"
void save::save_mod(void){

    string out_line; //입력
    char txt; //쓴 글을 저장받음
    char subject [300]; //저장할 때 제목을 쓰기 위해서

    cout<<"q를 입력받으면 종료됩니다"<<endl;
    cout<<"글을 입력 받습니다"<<endl;
    cout<< "최대 10000자까지 가능합니다"<<endl;

    for(int i=0;i<=10000;i++){
        cin>>txt;
        out_line+=txt;
        if(txt=='q') break;
    }
    cout<<"경로를 지정해주세요"<<endl;
    cin>>subject;
    ofstream out(subject);
    out<<out_line<<endl;
    out.close();
}


