﻿//Notepad.cpp
#include "UI.h"
#ifndef NOTEPAD_H
#define NOTEPAD_H
#define HORI 75
#define VERT 30

void Box(void);

class Notepad{
private:
public:
		void Box(void)
		{
			cout<<"┌";
			for(int i=0;i<HORI;i++) cout<<"─";
			cout<<"┐"<<endl<<PrintBlank()<<endl<<"└";
			for(int i=0;i<HORI;i++) cout<<"─";
			cout<<"┘"<<endl;
		}
		
		void PrintNotepad(void)
		{
			system("clear");
			Box();
			for(int i=0;i<VERT;i++) cout<<PrintBlank()<<endl;
			Box();
		}
		
		string PrintBlank(void)
		{
			string Blank="│\t\t│     │\t\t\t\t\t\t            │";
			return Blank;
		}
};
#endif
