﻿//Timer.cpp
#include "UI.h"
#ifndef TIMER_H
#define TIMER_H
#define Y 35 //Y좌표 초깃값
class Timer
{
	private:
		int hour;
		int min;
		
		int mod=1, lang=0, cps=0;
		 int be_mod, be_lang, be_cps=0; 
		int befor_min;
		
		string moon;
		Edit ed;
		Gotoxy gt;
		
		mutex timer_mutex;
		
	public:
		string result;
		
		void SetMode(int i)
		{
			mod=i;
		}
		
		void Print()
		{
			while(1){				
				befor_min=min; 
				time_t curr_time;
			 	struct tm *curr_tm;
				curr_time = time(NULL);
				curr_tm = localtime(&curr_time);  
				
				hour=curr_tm->tm_hour;
				min=curr_tm->tm_min;
				moon="AM ";
				
				if(hour>12)
				{
					moon.clear();
					hour%=12;
					moon="PM ";
				}
				string shour = to_string(hour);
				string smin = to_string(min);
				usleep(60000);
				
				if(befor_min!=min || be_cps != cps || be_mod != mod || be_lang != lang) { 
					timer_mutex.lock();
					gt.Setxy(3,Y);	
					ed.print(mod);
					
					//gt.Setxy(32,Y);
					//lan.print(lang);
					
					//gt.Setxy(47,Y);
					//cp.print(cps);
					
					result = "시간 " + shour + ":" + smin + " " + moon;
					gt.Setxy(57,Y-1);
					cout<<"┌"<<endl;
					gt.Setxy(57,Y);
					cout<<"│"<<endl;
					gt.Setxy(57,Y+1);
					cout<<"└"<<endl;
					gt.Setxy(60,Y);
					cout << result;
					cout<<""<<endl;
					timer_mutex.unlock();
				}
				be_cps = cps;
				be_lang = lang;
				be_mod = mod; 
			}
		}
		mutex *GetMutex()
		{
			return &timer_mutex;
		}
};
#endif
