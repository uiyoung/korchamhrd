import smtplib as sl
from email.mime.text import MIMEText as mt
from email.mime.base import MIMEBase as mb
from email import encoders as ec
import os


if __name__ == '__main__':
    email_bin1 = open('email_se.bin', 'rb')
    email_se = email_bin1.readline().decode('ascii')
    email_bin1.close()
    email_bin2 = open('email_co.bin', 'rb')
    email_co = email_bin2.readline().decode('ascii')
    email_bin2.close()
    email_bin3 = open('email_re.bin', 'rb')
    email_re = email_bin3.readline().decode('ascii')
    email_bin3.close()
    se = sl.SMTP('smtp.gmail.com', 587)
    se.starttls()
    se.login(email_se, email_co)    # dlsflwkuupxrfzma
    msg = mb('multipart', 'mixed')
    cont = mt('아요티 워드프로세서에서 텍스트가 전송되었습니다.', 'plain', 'utf-8')
    msg['Subject'] = '[IoTeam] - Text Delivery'
    cont['From'] = email_se
    cont['To'] = email_re
    msg.attach(cont)
    path = 'test.txt'   # linux : /home/iot201915/Cpp/IoTeam/test.txt
    part = mb("application", "octet-stream")
    part.set_payload(open(path, 'rb').read())
    ec.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(path))
    msg.attach(part)
    se.sendmail(email_se, email_re, msg.as_string())
    se.quit()
    print("email ok")


