//
// Created by iotpc on 2019-07-20.
//
#include "file.h"


void email::AdEmail_send(void){
    ofstream f1;
    char *mail_se = new(char);
    f1.open("email_se.bin", ostream::binary);
    cout << "보내는 사람 이메일 입력\n>> ";
    cin >> mail_se;
    f1 << mail_se;
    delete mail_se;
    f1.close();
}
void email::AdEmail_code(void){
    ofstream f3;
    char *mail_co = new(char);
    f3.open("email_co.bin", ostream::binary);
    cout << "지메일 SMTP 코드 입력\n>> ";
    cin >> mail_co;
    f3 << mail_co;
    delete mail_co;
    f3.close();
}

void email::AdEmail_reci(void) {
    ofstream f2;
    char *mail_re = new(char);
    f2.open("email_re.bin", ostream::binary);
    cout << "받는 사람 이메일 입력\n>> ";
    cin >> mail_re;
    f2 << mail_re;
    delete mail_re;
    f2.close();
}


void email::FileSend(void){
    system("python3 email_mod.py"); // linux : python3 ~/Cpp/IoTeam/email_mod.py
}

