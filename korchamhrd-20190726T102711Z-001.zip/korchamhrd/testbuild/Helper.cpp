#include "UI.h"
#ifndef HELPER_H
#define HELPER_H

class Helper{
private:
	
public:
	void PrintHelper(void)
	{
		
	}
	
};