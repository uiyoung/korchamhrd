//
// Created by iotpc on 2019-07-20.
//
#include "file.h"

void delt::FileDel(const char name[20]) {
    NameInput(name);
    cout << name_commend << endl;
    system(name_commend);
    cout << name <<" Delete!" << endl;
}

void delt::NameInput(const char name[20]) {
    strcat(name_commend, name);
}
