#ifndef GUI_H
#define GUI_H

#define TOP 0
#define MIDDLE 1

#define CENTER 0
#define LEFT_SIDE 1



#include "text.h"
#include "public_functions.h"
#include <iostream>
#include <vector>


using namespace publicfunctions;

class Gui{
	private:
		void correctionString(int colSize, std::string &str);
		int countCharacter(std::string &text);
	
	public:
		void MakeBox(int width, int height, int boxPos_x, int boxPos_y, std::string str, int strPos_x = CENTER, int strPos_y = CENTER );
		void MakeBox(int width, int height, int boxPos_x, int boxPos_y, std::vector <std::string> &strs, int strPos_x = CENTER, int strPos_y = CENTER);
		void MakeTable(std::vector <std::string> *textBuffer, int currentLine);
		
};





#endif