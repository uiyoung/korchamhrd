﻿//Gotoxy.cpp
#include "UI.h"
#ifndef GOTOXY_H
#define GOTOXY_H

class Gotoxy{
	private:
		int x,y;
	public:
		Gotoxy() : x(0),y(0) {}
		
		void Setxy(int x,int y){
			printf("\033[%d;%df", y, x);
	    	fflush(stdout);
		}
};
#endif
