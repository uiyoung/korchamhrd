#ifndef PUBLIC_FUNCTIONS_H
#define PUBLIC_FUNCTIONS_H


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>

namespace publicfunctions{
	
int kbhit();
void gotoxy(int x, int y);
int getch();
void inputLine(std::string str, int num);
}

#endif
